# 寶寶生活記錄專業版（Baby Tracker）- 第一階段：Core Data 管理器

## Core Data Stack 實現

以下是 Core Data 管理器的實現，用於處理數據的持久化存儲和檢索。

```swift
import CoreData
import Combine

/// Core Data 管理器，負責處理所有 Core Data 相關操作
class CoreDataManager {
    
    // MARK: - Singleton
    
    /// 共享實例
    static let shared = CoreDataManager()
    
    // MARK: - Core Data Stack
    
    /// 持久化容器
    private lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "BabyTracker")
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                // 處理錯誤情況
                fatalError("無法加載 Core Data 存儲: \(error), \(error.userInfo)")
            }
        }
        
        // 啟用自動合併策略
        container.viewContext.automaticallyMergesChangesFromParent = true
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        
        return container
    }()
    
    /// 主要視圖上下文
    var viewContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    /// 創建後台上下文
    func createBackgroundContext() -> NSManagedObjectContext {
        return persistentContainer.newBackgroundContext()
    }
    
    // MARK: - CRUD Operations
    
    /// 保存視圖上下文中的更改
    func saveContext() {
        let context = viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nsError = error as NSError
                print("無法保存上下文: \(nsError), \(nsError.userInfo)")
            }
        }
    }
    
    /// 在後台上下文中執行操作
    func performBackgroundTask(_ block: @escaping (NSManagedObjectContext) -> Void) {
        let context = createBackgroundContext()
        context.perform {
            block(context)
            
            if context.hasChanges {
                do {
                    try context.save()
                } catch {
                    let nsError = error as NSError
                    print("無法保存後台上下文: \(nsError), \(nsError.userInfo)")
                }
            }
        }
    }
    
    /// 獲取實體的所有對象
    func fetchAll<T: NSManagedObject>(_ entityType: T.Type, sortDescriptors: [NSSortDescriptor]? = nil, predicate: NSPredicate? = nil) -> [T] {
        let request = NSFetchRequest<T>(entityName: String(describing: entityType))
        request.sortDescriptors = sortDescriptors
        request.predicate = predicate
        
        do {
            return try viewContext.fetch(request)
        } catch {
            print("獲取數據失敗: \(error)")
            return []
        }
    }
    
    /// 獲取實體的對象數量
    func count<T: NSManagedObject>(_ entityType: T.Type, predicate: NSPredicate? = nil) -> Int {
        let request = NSFetchRequest<T>(entityName: String(describing: entityType))
        request.predicate = predicate
        
        do {
            return try viewContext.count(for: request)
        } catch {
            print("計數失敗: \(error)")
            return 0
        }
    }
    
    /// 刪除對象
    func delete(_ object: NSManagedObject) {
        viewContext.delete(object)
        saveContext()
    }
    
    /// 刪除多個對象
    func deleteMultiple(_ objects: [NSManagedObject]) {
        for object in objects {
            viewContext.delete(object)
        }
        saveContext()
    }
    
    /// 刪除實體的所有對象
    func deleteAll<T: NSManagedObject>(_ entityType: T.Type) {
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: String(describing: entityType))
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        
        do {
            try viewContext.execute(deleteRequest)
            saveContext()
        } catch {
            print("刪除所有數據失敗: \(error)")
        }
    }
}

// MARK: - 實體擴展

/// Baby 實體擴展
extension Baby {
    /// 創建新的 Baby 實例
    static func create(name: String, birthDate: Date, gender: String, in context: NSManagedObjectContext) -> Baby {
        let baby = Baby(context: context)
        baby.id = UUID()
        baby.name = name
        baby.birthDate = birthDate
        baby.gender = gender
        baby.createdAt = Date()
        baby.updatedAt = Date()
        return baby
    }
}

/// SleepRecord 實體擴展
extension SleepRecord {
    /// 創建新的 SleepRecord 實例
    static func create(baby: Baby, startTime: Date, in context: NSManagedObjectContext) -> SleepRecord {
        let sleepRecord = SleepRecord(context: context)
        sleepRecord.id = UUID()
        sleepRecord.baby = baby
        sleepRecord.startTime = startTime
        sleepRecord.createdAt = Date()
        sleepRecord.updatedAt = Date()
        return sleepRecord
    }
    
    /// 結束睡眠記錄
    func end(at endTime: Date, quality: Int16? = nil, notes: String? = nil) {
        self.endTime = endTime
        self.quality = quality ?? 0
        self.notes = notes
        
        // 計算持續時間（分鐘）
        if let start = self.startTime {
            self.duration = endTime.timeIntervalSince(start) / 60
        }
        
        self.updatedAt = Date()
    }
}

/// EnvironmentFactor 實體擴展
extension EnvironmentFactor {
    /// 創建新的 EnvironmentFactor 實例
    static func create(sleepRecord: SleepRecord, type: String, value: String, in context: NSManagedObjectContext) -> EnvironmentFactor {
        let factor = EnvironmentFactor(context: context)
        factor.id = UUID()
        factor.sleepRecord = sleepRecord
        factor.type = type
        factor.value = value
        factor.timestamp = Date()
        return factor
    }
}

/// SleepInterruption 實體擴展
extension SleepInterruption {
    /// 創建新的 SleepInterruption 實例
    static func create(sleepRecord: SleepRecord, startTime: Date, endTime: Date, reason: String? = nil, in context: NSManagedObjectContext) -> SleepInterruption {
        let interruption = SleepInterruption(context: context)
        interruption.id = UUID()
        interruption.sleepRecord = sleepRecord
        interruption.startTime = startTime
        interruption.endTime = endTime
        interruption.reason = reason
        
        // 計算持續時間（分鐘）
        interruption.duration = endTime.timeIntervalSince(startTime) / 60
        
        // 更新睡眠記錄的中斷統計
        sleepRecord.interruptionCount += 1
        sleepRecord.totalInterruptionTime += interruption.duration
        
        return interruption
    }
}
```

## 數據存取層（Repositories）

以下是數據存取層的實現，用於提供對 Core Data 實體的訪問。

### BabyRepository

```swift
import CoreData
import Combine

/// 寶寶數據存取層
class BabyRepository {
    
    private let coreDataManager: CoreDataManager
    
    init(coreDataManager: CoreDataManager = .shared) {
        self.coreDataManager = coreDataManager
    }
    
    /// 獲取所有寶寶
    func getAllBabies() -> [Baby] {
        let sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        return coreDataManager.fetchAll(Baby.self, sortDescriptors: sortDescriptors)
    }
    
    /// 根據 ID 獲取寶寶
    func getBaby(byId id: UUID) -> Baby? {
        let predicate = NSPredicate(format: "id == %@", id as CVarArg)
        let babies = coreDataManager.fetchAll(Baby.self, predicate: predicate)
        return babies.first
    }
    
    /// 創建新寶寶
    func createBaby(name: String, birthDate: Date, gender: String) -> Baby {
        let baby = Baby.create(name: name, birthDate: birthDate, gender: gender, in: coreDataManager.viewContext)
        coreDataManager.saveContext()
        return baby
    }
    
    /// 更新寶寶信息
    func updateBaby(baby: Baby, name: String? = nil, birthDate: Date? = nil, gender: String? = nil, developmentStage: String? = nil, notes: String? = nil) {
        if let name = name {
            baby.name = name
        }
        
        if let birthDate = birthDate {
            baby.birthDate = birthDate
        }
        
        if let gender = gender {
            baby.gender = gender
        }
        
        if let developmentStage = developmentStage {
            baby.developmentStage = developmentStage
        }
        
        if let notes = notes {
            baby.notes = notes
        }
        
        baby.updatedAt = Date()
        coreDataManager.saveContext()
    }
    
    /// 刪除寶寶
    func deleteBaby(_ baby: Baby) {
        coreDataManager.delete(baby)
    }
    
    /// 獲取寶寶數量
    func getBabyCount() -> Int {
        return coreDataManager.count(Baby.self)
    }
}
```

### SleepRepository

```swift
import CoreData
import Combine

/// 睡眠記錄數據存取層
class SleepRepository {
    
    private let coreDataManager: CoreDataManager
    
    init(coreDataManager: CoreDataManager = .shared) {
        self.coreDataManager = coreDataManager
    }
    
    /// 獲取寶寶的所有睡眠記錄
    func getSleepRecords(forBaby baby: Baby, startDate: Date? = nil, endDate: Date? = nil) -> [SleepRecord] {
        var predicates = [NSPredicate(format: "baby == %@", baby)]
        
        if let startDate = startDate {
            predicates.append(NSPredicate(format: "startTime >= %@", startDate as NSDate))
        }
        
        if let endDate = endDate {
            predicates.append(NSPredicate(format: "startTime <= %@", endDate as NSDate))
        }
        
        let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: predicates)
        let sortDescriptors = [NSSortDescriptor(key: "startTime", ascending: false)]
        
        return coreDataManager.fetchAll(SleepRecord.self, sortDescriptors: sortDescriptors, predicate: predicate)
    }
    
    /// 獲取當前進行中的睡眠記錄
    func getOngoingSleepRecord(forBaby baby: Baby) -> SleepRecord? {
        let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            NSPredicate(format: "baby == %@", baby),
            NSPredicate(format: "endTime == nil")
        ])
        
        let records = coreDataManager.fetchAll(SleepRecord.self, predicate: predicate)
        return records.first
    }
    
    /// 創建新的睡眠記錄
    func createSleepRecord(forBaby baby: Baby, startTime: Date) -> SleepRecord {
        let sleepRecord = SleepRecord.create(baby: baby, startTime: startTime, in: coreDataManager.viewContext)
        coreDataManager.saveContext()
        return sleepRecord
    }
    
    /// 結束睡眠記錄
    func endSleepRecord(_ sleepRecord: SleepRecord, endTime: Date, quality: Int16? = nil, notes: String? = nil) {
        sleepRecord.end(at: endTime, quality: quality, notes: notes)
        coreDataManager.saveContext()
    }
    
    /// 添加環境因素
    func addEnvironmentFactor(toSleepRecord sleepRecord: SleepRecord, type: String, value: String) -> EnvironmentFactor {
        let factor = EnvironmentFactor.create(sleepRecord: sleepRecord, type: type, value: value, in: coreDataManager.viewContext)
        coreDataManager.saveContext()
        return factor
    }
    
    /// 添加睡眠中斷
    func addSleepInterruption(toSleepRecord sleepRecord: SleepRecord, startTime: Date, endTime: Date, reason: String? = nil) -> SleepInterruption {
        let interruption = SleepInterruption.create(sleepRecord: sleepRecord, startTime: startTime, endTime: endTime, reason: reason, in: coreDataManager.viewContext)
        coreDataManager.saveContext()
        return interruption
    }
    
    /// 刪除睡眠記錄
    func deleteSleepRecord(_ sleepRecord: SleepRecord) {
        coreDataManager.delete(sleepRecord)
    }
    
    /// 獲取睡眠統計數據
    func getSleepStatistics(forBaby baby: Baby, startDate: Date, endDate: Date) -> (totalSleep: Double, averageQuality: Double, interruptionCount: Int) {
        let records = getSleepRecords(forBaby: baby, startDate: startDate, endDate: endDate)
        
        // 只考慮已完成的睡眠記錄
        let completedRecords = records.filter { $0.endTime != nil && $0.duration > 0 }
        
        let totalSleep = completedRecords.reduce(0) { $0 + ($1.duration ?? 0) }
        
        let qualityRecords = completedRecords.filter { $0.quality > 0 }
        let averageQuality = qualityRecords.isEmpty ? 0 : qualityRecords.reduce(0) { $0 + Double($1.quality) } / Double(qualityRecords.count)
        
        let interruptionCount = completedRecords.reduce(0) { $0 + Int($1.interruptionCount) }
        
        return (totalSleep, averageQuality, interruptionCount)
    }
}
```

## 領域層（Domain Layer）

以下是領域層的實現，包含業務邏輯和用例。

### SleepUseCases

```swift
import Foundation
import Combine

/// 睡眠相關用例
class SleepUseCases {
    
    private let sleepRepository: SleepRepository
    private let babyRepository: BabyRepository
    
    init(sleepRepository: SleepRepository = SleepRepository(), babyRepository: BabyRepository = BabyRepository()) {
        self.sleepRepository = sleepRepository
        self.babyRepository = babyRepository
    }
    
    /// 開始睡眠記錄
    func startSleepRecord(forBabyId babyId: UUID, startTime: Date = Date()) -> SleepRecord? {
        guard let baby = babyRepository.getBaby(byId: babyId) else {
            print("找不到指定的寶寶")
            return nil
        }
        
        // 檢查是否已有進行中的睡眠記錄
        if let ongoingRecord = sleepRepository.getOngoingSleepRecord(forBaby: baby) {
            print("已有進行中的睡眠記錄，請先結束該記錄")
            return ongoingRecord
        }
        
        return sleepRepository.createSleepRecord(forBaby: baby, startTime: startTime)
    }
    
    /// 結束睡眠記錄
    func endSleepRecord(recordId: UUID, endTime: Date = Date(), quality: Int? = nil, notes: String? = nil) -> Bool {
        let predicate = NSPredicate(format: "id == %@", recordId as CVarArg)
        let records = CoreDataManager.shared.fetchAll(SleepRecord.self, predicate: predicate)
        
        guard let record = records.first else {
            print("找不到指定的睡眠記錄")
            return false
        }
        
        sleepRepository.endSleepRecord(record, endTime: endTime, quality: quality != nil ? Int16(quality!) : nil, notes: notes)
        return true
    }
    
    /// 添加環境因素
    func addEnvironmentFactor(toSleepRecordId recordId: UUID, type: String, value: String) -> Bool {
        let predicate = NSPredicate(format: "id == %@", recordId as CVarArg)
        let records = CoreDataManager.shared.fetchAll(SleepRecord.self, predicate: predicate)
        
        guard let record = records.first else {
            print("找不到指定的睡眠記錄")
            return false
        }
        
        _ = sleepRepository.addEnvironmentFactor(toSleepRecord: record, type: type, value: value)
        return true
    }
    
    /// 記錄睡眠中斷
    func recordSleepInterruption(forSleepRecordId recordId: UUID, startTime: Date, endTime: Date, reason: String? = nil) -> Bool {
        let predicate = NSPredicate(format: "id == %@", recordId as CVarArg)
        let records = CoreDataManager.shared.fetchAll(SleepRecord.self, predicate: predicate)
        
        guard let record = records.first else {
            print("找不到指定的睡眠記錄")
            return false
        }
        
        _ = sleepRepository.addSleepInterruption(toSleepRecord: record, startTime: startTime, endTime: endTime, reason: reason)
        return true
    }
    
    /// 獲取寶寶的睡眠記錄
    func getSleepRecords(forBabyId babyId: UUID, days: Int = 7) -> [SleepRecord] {
        guard let baby = babyRepository.getBaby(byId: babyId) else {
            print("找不到指定的寶寶")
            return []
        }
        
        let endDate = Date()
        let startDate = Calendar.current.date(byAdding: .day, value: -days, to: endDate)!
        
        return sleepRepository.getSleepRecords(forBaby: baby, startDate: startDate, endDate: endDate)
    }
    
    /// 獲取寶寶的睡眠統計數據
    func getSleepStatistics(forBabyId babyId: UUID, days: Int = 7) -> (totalSleep: Double, averageQuality: Double, interruptionCount: Int)? {
        guard let baby = babyRepository.getBaby(byId: babyId) else {
            print("找不到指定的寶寶")
            return nil
        }
        
        let endDate = Date()
        let startDate = Calendar.current.date(byAdding: .day, value: -days, to: endDate)!
        
        return sleepRepository.getSleepStatistics(forBaby: baby, startDate: startDate, endDate: endDate)
    }
    
    /// 檢查是否有進行中的睡眠記錄
    func hasOngoingSleepRecord(forBabyId babyId: UUID) -> SleepRecord? {
        guard let baby = babyRepository.getBaby(byId: babyId) else {
            print("找不到指定的寶寶")
            return nil
        }
        
        return sleepRepository.getOngoingSleepRecord(forBaby: baby)
    }
}
```

## 表現層（Presentation Layer）

以下是表現層的 ViewModel 實現，用於連接 UI 和業務邏輯。

### SleepViewModel

```swift
import Foundation
import Combine

/// 睡眠記錄視圖模型
class SleepViewModel: ObservableObject {
    
    // MARK: - Published Properties
    
    /// 當前寶寶的睡眠記錄
    @Published var sleepRecords: [SleepRecord] = []
    
    /// 進行中的睡眠記錄
    @Published var ongoingSleepRecord: SleepRecord?
    
    /// 睡眠統計數據
    @Published var sleepStatistics: (totalSleep: Double, averageQuality: Double, interruptionCount: Int)?
    
    /// 加載狀態
    @Published var isLoading = false
    
    /// 錯誤信息
    @Published var errorMessage: String?
    
    // MARK: - Private Properties
    
    private let sleepUseCases: SleepUseCases
    private var cancellables = Set<AnyCancellable>()
    private var currentBabyId: UUID?
    
    // MARK: - Initialization
    
    init(sleepUseCases: SleepUseCases = SleepUseCases()) {
        self.sleepUseCases = sleepUseCases
    }
    
    // MARK: - Public Methods
    
    /// 加載寶寶的睡眠記錄
    func loadSleepRecords(forBabyId babyId: UUID, days: Int = 7) {
        isLoading = true
        errorMessage = nil
        currentBabyId = babyId
        
        // 檢查進行中的睡眠記錄
        ongoingSleepRecord = sleepUseCases.hasOngoingSleepRecord(forBabyId: babyId)
        
        // 獲取睡眠記錄
        sleepRecords = sleepUseCases.getSleepRecords(forBabyId: babyId, days: days)
        
        // 獲取睡眠統計數據
        sleepStatistics = sleepUseCases.getSleepStatistics(forBabyId: babyId, days: days)
        
        isLoading = false
    }
    
    /// 開始睡眠記錄
    func startSleepRecord(startTime: Date = Date()) {
        guard let babyId = currentBabyId else {
            errorMessage = "未選擇寶寶"
            return
        }
        
        if ongoingSleepRecord != nil {
            errorMessage = "已有進行中的睡眠記錄"
            return
        }
        
        ongoingSleepRecord = sleepUseCases.startSleepRecord(forBabyId: babyId, startTime: startTime)
        
        // 重新加載記錄以更新列表
        if let babyId = currentBabyId {
            loadSleepRecords(forBabyId: babyId)
        }
    }
    
    /// 結束睡眠記錄
    func endSleepRecord(quality: Int? = nil, notes: String? = nil) {
        guard let record = ongoingSleepRecord, let recordId = record.id else {
            errorMessage = "沒有進行中的睡眠記錄"
            return
        }
        
        let success = sleepUseCases.endSleepRecord(recordId: recordId, quality: quality, notes: notes)
        
        if success {
            ongoingSleepRecord = nil
            
            // 重新加載記錄以更新列表
            if let babyId = currentBabyId {
                loadSleepRecords(forBabyId: babyId)
            }
        } else {
            errorMessage = "結束睡眠記錄失敗"
        }
    }
    
    /// 添加環境因素
    func addEnvironmentFactor(type: String, value: String) {
        guard let record = ongoingSleepRecord, let recordId = record.id else {
            errorMessage = "沒有進行中的睡眠記錄"
            return
        }
        
        let success = sleepUseCases.addEnvironmentFactor(toSleepRecordId: recordId, type: type, value: value)
        
        if !success {
            errorMessage = "添加環境因素失敗"
        }
    }
    
    /// 記錄睡眠中斷
    func recordInterruption(startTime: Date, endTime: Date, reason: String? = nil) {
        guard let record = ongoingSleepRecord, let recordId = record.id else {
            errorMessage = "沒有進行中的睡眠記錄"
            return
        }
        
        let success = sleepUseCases.recordSleepInterruption(forSleepRecordId: recordId, startTime: startTime, endTime: endTime, reason: reason)
        
        if !success {
            errorMessage = "記錄睡眠中斷失敗"
        }
    }
    
    /// 格式化睡眠時長
    func formatSleepDuration(_ minutes: Double?) -> String {
        guard let minutes = minutes else { return "N/A" }
        
        let hours = Int(minutes) / 60
        let mins = Int(minutes) % 60
        
        if hours > 0 {
            return "\(hours)小時 \(mins)分鐘"
        } else {
            return "\(mins)分鐘"
        }
    }
    
    /// 格式化睡眠質量
    func formatSleepQuality(_ quality: Int16) -> String {
        switch quality {
        case 1: return "很差"
        case 2: return "較差"
        case 3: return "一般"
        case 4: return "良好"
        case 5: return "優秀"
        default: return "未評分"
        }
    }
}
```

## 測試代碼

以下是基本的測試代碼，用於驗證 Core Data 模型和業務邏輯。

```swift
import XCTest
@testable import BabyTracker

class SleepRecordTests: XCTestCase {
    
    var coreDataManager: CoreDataManager!
    var babyRepository: BabyRepository!
    var sleepRepository: SleepRepository!
    var sleepUseCases: SleepUseCases!
    
    override func setUp() {
        super.setUp()
        
        // 使用內存存儲進行測試
        coreDataManager = TestCoreDataManager()
        babyRepository = BabyRepository(coreDataManager: coreDataManager)
        sleepRepository = SleepRepository(coreDataManager: coreDataManager)
        sleepUseCases = SleepUseCases(sleepRepository: sleepRepository, babyRepository: babyRepository)
    }
    
    override func tearDown() {
        coreDataManager = nil
        babyRepository = nil
        sleepRepository = nil
        sleepUseCases = nil
        super.tearDown()
    }
    
    func testCreateBaby() {
        // 創建測試寶寶
        let baby = babyRepository.createBaby(name: "測試寶寶", birthDate: Date(), gender: "male")
        
        // 驗證寶寶是否創建成功
        XCTAssertNotNil(baby)
        XCTAssertEqual(baby.name, "測試寶寶")
        XCTAssertEqual(baby.gender, "male")
        
        // 驗證寶寶數量
        let count = babyRepository.getBabyCount()
        XCTAssertEqual(count, 1)
    }
    
    func testSleepRecordLifecycle() {
        // 創建測試寶寶
        let baby = babyRepository.createBaby(name: "測試寶寶", birthDate: Date(), gender: "male")
        
        // 開始睡眠記錄
        let startTime = Date().addingTimeInterval(-3600) // 1小時前
        let sleepRecord = sleepRepository.createSleepRecord(forBaby: baby, startTime: startTime)
        
        // 驗證睡眠記錄是否創建成功
        XCTAssertNotNil(sleepRecord)
        XCTAssertEqual(sleepRecord.baby, baby)
        XCTAssertEqual(sleepRecord.startTime, startTime)
        XCTAssertNil(sleepRecord.endTime)
        
        // 添加環境因素
        let factor = sleepRepository.addEnvironmentFactor(toSleepRecord: sleepRecord, type: "light", value: "dim")
        XCTAssertNotNil(factor)
        XCTAssertEqual(factor.type, "light")
        XCTAssertEqual(factor.value, "dim")
        
        // 記錄睡眠中斷
        let interruptionStart = startTime.addingTimeInterval(1800) // 開始後30分鐘
        let interruptionEnd = interruptionStart.addingTimeInterval(600) // 中斷10分鐘
        let interruption = sleepRepository.addSleepInterruption(toSleepRecord: sleepRecord, startTime: interruptionStart, endTime: interruptionEnd, reason: "哭鬧")
        
        XCTAssertNotNil(interruption)
        XCTAssertEqual(interruption.reason, "哭鬧")
        XCTAssertEqual(interruption.duration, 10) // 10分鐘
        XCTAssertEqual(sleepRecord.interruptionCount, 1)
        XCTAssertEqual(sleepRecord.totalInterruptionTime, 10)
        
        // 結束睡眠記錄
        let endTime = Date()
        sleepRepository.endSleepRecord(sleepRecord, endTime: endTime, quality: 4, notes: "睡得不錯")
        
        // 驗證睡眠記錄是否正確結束
        XCTAssertEqual(sleepRecord.endTime, endTime)
        XCTAssertEqual(sleepRecord.quality, 4)
        XCTAssertEqual(sleepRecord.notes, "睡得不錯")
        
        // 驗證持續時間計算是否正確（約60分鐘）
        XCTAssertNotNil(sleepRecord.duration)
        XCTAssertEqual(round(sleepRecord.duration! / 60) * 60, 3600, accuracy: 60)
        
        // 獲取睡眠記錄
        let records = sleepRepository.getSleepRecords(forBaby: baby)
        XCTAssertEqual(records.count, 1)
        XCTAssertEqual(records.first, sleepRecord)
        
        // 獲取睡眠統計
        let stats = sleepRepository.getSleepStatistics(forBaby: baby, startDate: startTime.addingTimeInterval(-3600), endDate: endTime.addingTimeInterval(3600))
        XCTAssertEqual(stats.totalSleep, sleepRecord.duration)
        XCTAssertEqual(stats.averageQuality, 4)
        XCTAssertEqual(stats.interruptionCount, 1)
    }
    
    func testSleepUseCases() {
        // 創建測試寶寶
        let baby = babyRepository.createBaby(name: "測試寶寶", birthDate: Date(), gender: "male")
        guard let babyId = baby.id else {
            XCTFail("寶寶ID為空")
            return
        }
        
        // 開始睡眠記錄
        let record = sleepUseCases.startSleepRecord(forBabyId: babyId)
        XCTAssertNotNil(record)
        
        // 檢查進行中的記錄
        let ongoing = sleepUseCases.hasOngoingSleepRecord(forBabyId: babyId)
        XCTAssertNotNil(ongoing)
        XCTAssertEqual(ongoing, record)
        
        // 添加環境因素
        guard let recordId = record?.id else {
            XCTFail("記錄ID為空")
            return
        }
        
        let factorAdded = sleepUseCases.addEnvironmentFactor(toSleepRecordId: recordId, type: "temperature", value: "warm")
        XCTAssertTrue(factorAdded)
        
        // 記錄中斷
        let interruptionStart = Date().addingTimeInterval(-600) // 10分鐘前
        let interruptionEnd = Date().addingTimeInterval(-300) // 5分鐘前
        let interruptionAdded = sleepUseCases.recordSleepInterruption(forSleepRecordId: recordId, startTime: interruptionStart, endTime: interruptionEnd, reason: "換尿布")
        XCTAssertTrue(interruptionAdded)
        
        // 結束記錄
        let ended = sleepUseCases.endSleepRecord(recordId: recordId, quality: 5, notes: "睡得很好")
        XCTAssertTrue(ended)
        
        // 獲取記錄
        let records = sleepUseCases.getSleepRecords(forBabyId: babyId)
        XCTAssertEqual(records.count, 1)
        
        // 獲取統計
        let stats = sleepUseCases.getSleepStatistics(forBabyId: babyId)
        XCTAssertNotNil(stats)
        XCTAssertEqual(stats?.averageQuality, 5)
        XCTAssertEqual(stats?.interruptionCount, 1)
    }
}

/// 用於測試的 Core Data 管理器
class TestCoreDataManager: CoreDataManager {
    
    override init() {
        super.init()
    }
    
    override var persistentContainer: NSPersistentContainer {
        let container = NSPersistentContainer(name: "BabyTracker")
        
        // 使用內存存儲進行測試
        let description = NSPersistentStoreDescription()
        description.type = NSInMemoryStoreType
        container.persistentStoreDescriptions = [description]
        
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("無法加載測試 Core Data 存儲: \(error), \(error.userInfo)")
            }
        }
        
        container.viewContext.automaticallyMergesChangesFromParent = true
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        
        return container
    }
}
```

## 第一階段實現總結

在第一階段，我們已經實現了以下核心功能：

1. **專案基礎架構**：
   - 建立了清晰的 MVVM 架構
   - 設計了模塊化的目錄結構
   - 定義了代碼規範和設計模式

2. **數據模型與本地存儲**：
   - 設計了完整的 Core Data 數據模型
   - 實現了 Core Data 管理器
   - 創建了數據存取層（Repositories）

3. **基本的睡眠記錄功能**：
   - 實現了睡眠記錄的創建、更新和刪除
   - 支持環境因素記錄
   - 支持睡眠中斷記錄
   - 提供基本的睡眠統計功能

這些實現為後續階段的開發奠定了堅實的基礎。在下一階段，我們將專注於用戶界面和基礎體驗的開發。
