# 寶寶生活記錄專業版（Baby Tracker）- 第二階段：用戶界面與基礎體驗

## 1. 用戶界面設計概述

在第二階段，我們將專注於實現應用的用戶界面和基礎體驗，包括主頁/儀表板界面、睡眠記錄流程與界面，以及基本的數據視覺化功能。設計將遵循溫馨親子風格，並特別考慮新手父母在疲勞狀態下的使用便利性。

### 1.1 設計原則

- **簡潔直觀**：界面元素簡化，減少認知負擔
- **大按鈕設計**：便於單手操作和疲勞狀態下使用
- **溫馨色調**：採用柔和、舒適的色彩方案
- **一致性**：保持視覺和交互模式的一致
- **即時反饋**：提供清晰的操作反饋
- **夜間友好**：特別優化夜間使用體驗

### 1.2 色彩方案

```swift
// 主色調
static let primaryColor = Color(hex: "6B8EAE") // 溫和天藍色
static let secondaryColor = Color(hex: "F0C8D0") // 柔和粉色
static let accentColor = Color(hex: "A7D7C9") // 薄荷綠

// 功能色彩
static let sleepColor = Color(hex: "8B9EB7") // 寧靜藍
static let feedingColor = Color(hex: "F3B391") // 溫暖橙
static let diaperColor = Color(hex: "D6A2E8") // 溫和紫

// 狀態色彩
static let successColor = Color(hex: "7FC8A9") // 柔和綠
static let warningColor = Color(hex: "FFD384") // 溫和黃
static let errorColor = Color(hex: "F5A7A7") // 柔和紅
static let disabledColor = Color(hex: "D1D1D6") // 柔和灰

// 背景色彩
static let backgroundColor = Color(hex: "FFFFFF") // 純白
static let secondaryBackgroundColor = Color(hex: "F8F9FA") // 淺灰白
static let darkBackgroundColor = Color(hex: "2C3E50") // 深藍灰（夜間模式）
```

### 1.3 排版系統

```swift
// 字體大小
enum FontSize {
    static let largeTitle: CGFloat = 24
    static let title: CGFloat = 20
    static let subtitle: CGFloat = 17
    static let body: CGFloat = 15
    static let caption: CGFloat = 13
    static let small: CGFloat = 11
}

// 字重
enum FontWeight {
    case regular
    case medium
    case semibold
    
    var uiFont: UIFont.Weight {
        switch self {
        case .regular: return .regular
        case .medium: return .medium
        case .semibold: return .semibold
        }
    }
}

// 文本樣式
struct TextStyle {
    let size: CGFloat
    let weight: FontWeight
    let color: Color
    
    static let largeTitle = TextStyle(size: FontSize.largeTitle, weight: .semibold, color: .primary)
    static let title = TextStyle(size: FontSize.title, weight: .semibold, color: .primary)
    static let subtitle = TextStyle(size: FontSize.subtitle, weight: .medium, color: .primary)
    static let body = TextStyle(size: FontSize.body, weight: .regular, color: .primary)
    static let caption = TextStyle(size: FontSize.caption, weight: .regular, color: .secondary)
    static let small = TextStyle(size: FontSize.small, weight: .regular, color: .secondary)
}
```

## 2. 主頁/儀表板界面

### 2.1 主頁設計

主頁是用戶最常訪問的界面，設計為卡片式布局，提供寶寶當前狀態、最近活動和快速操作。

```swift
struct HomeView: View {
    @ObservedObject var viewModel: HomeViewModel
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    // 寶寶選擇器
                    babySelector
                    
                    // 當前狀態卡片
                    currentStatusCard
                    
                    // 睡眠記錄按鈕
                    sleepRecordButton
                    
                    // 今日睡眠摘要
                    todaySleepSummaryCard
                    
                    // 最近活動時間線
                    recentActivitiesTimeline
                    
                    // 智能建議卡片（預留）
                    recommendationCard
                }
                .padding()
            }
            .background(colorScheme == .dark ? Color.darkBackgroundColor : Color.secondaryBackgroundColor)
            .navigationTitle("主頁")
            .navigationBarItems(trailing: settingsButton)
        }
    }
    
    // 寶寶選擇器
    private var babySelector: some View {
        HStack {
            if let currentBaby = viewModel.currentBaby {
                Image(uiImage: currentBaby.photo ?? UIImage(named: "baby_placeholder")!)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 40, height: 40)
                    .clipShape(Circle())
                
                Text(currentBaby.name)
                    .font(.system(size: FontSize.subtitle, weight: .medium))
                
                Spacer()
                
                Button(action: {
                    viewModel.showBabySelector = true
                }) {
                    Image(systemName: "chevron.down.circle.fill")
                        .foregroundColor(.accentColor)
                }
            } else {
                Button(action: {
                    viewModel.showAddBaby = true
                }) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("添加寶寶")
                    }
                    .foregroundColor(.accentColor)
                }
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
        .sheet(isPresented: $viewModel.showBabySelector) {
            BabySelectorView(viewModel: viewModel.babySelectorViewModel)
        }
        .sheet(isPresented: $viewModel.showAddBaby) {
            AddBabyView(viewModel: viewModel.addBabyViewModel)
        }
    }
    
    // 當前狀態卡片
    private var currentStatusCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("當前狀態")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            HStack(spacing: 20) {
                statusItem(
                    icon: "moon.fill",
                    color: .sleepColor,
                    title: "睡眠",
                    value: viewModel.isSleeping ? "睡眠中" : "清醒"
                )
                
                statusItem(
                    icon: "clock.fill",
                    color: .primaryColor,
                    title: "上次睡眠",
                    value: viewModel.lastSleepTime
                )
                
                statusItem(
                    icon: "bolt.fill",
                    color: .accentColor,
                    title: "睡眠質量",
                    value: viewModel.lastSleepQuality
                )
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 狀態項目
    private func statusItem(icon: String, color: Color, title: String, value: String) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 24))
                .foregroundColor(color)
            
            Text(title)
                .font(.system(size: FontSize.caption))
                .foregroundColor(.secondary)
            
            Text(value)
                .font(.system(size: FontSize.body, weight: .medium))
                .foregroundColor(.primary)
        }
        .frame(maxWidth: .infinity)
    }
    
    // 睡眠記錄按鈕
    private var sleepRecordButton: some View {
        Button(action: {
            if viewModel.isSleeping {
                viewModel.endSleep()
            } else {
                viewModel.startSleep()
            }
        }) {
            HStack {
                Image(systemName: viewModel.isSleeping ? "stop.circle.fill" : "play.circle.fill")
                    .font(.system(size: 24))
                
                Text(viewModel.isSleeping ? "結束睡眠" : "開始睡眠")
                    .font(.system(size: FontSize.subtitle, weight: .medium))
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(viewModel.isSleeping ? Color.errorColor : Color.sleepColor)
            .foregroundColor(.white)
            .cornerRadius(12)
            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        }
        .disabled(viewModel.currentBaby == nil)
        .opacity(viewModel.currentBaby == nil ? 0.5 : 1)
    }
    
    // 今日睡眠摘要卡片
    private var todaySleepSummaryCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("今日睡眠")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            HStack(spacing: 20) {
                summaryItem(
                    title: "總時長",
                    value: viewModel.todayTotalSleepTime,
                    icon: "hourglass",
                    color: .sleepColor
                )
                
                summaryItem(
                    title: "次數",
                    value: viewModel.todaySleepCount,
                    icon: "number",
                    color: .primaryColor
                )
                
                summaryItem(
                    title: "平均質量",
                    value: viewModel.todayAverageSleepQuality,
                    icon: "star.fill",
                    color: .accentColor
                )
            }
            
            // 簡單的睡眠時間分布圖
            sleepDistributionChart
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 摘要項目
    private func summaryItem(title: String, value: String, icon: String, color: Color) -> some View {
        VStack(spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(color)
                
                Text(title)
                    .font(.system(size: FontSize.caption))
                    .foregroundColor(.secondary)
            }
            
            Text(value)
                .font(.system(size: FontSize.body, weight: .medium))
                .foregroundColor(.primary)
        }
        .frame(maxWidth: .infinity)
    }
    
    // 睡眠分布圖
    private var sleepDistributionChart: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("睡眠分布")
                .font(.system(size: FontSize.caption))
                .foregroundColor(.secondary)
            
            GeometryReader { geometry in
                HStack(alignment: .bottom, spacing: 2) {
                    ForEach(0..<24, id: \.self) { hour in
                        VStack(spacing: 4) {
                            RoundedRectangle(cornerRadius: 2)
                                .fill(viewModel.sleepHours.contains(hour) ? Color.sleepColor : Color.clear)
                                .frame(height: viewModel.sleepHours.contains(hour) ? 20 : 0)
                            
                            if hour % 6 == 0 {
                                Text("\(hour)")
                                    .font(.system(size: 8))
                                    .foregroundColor(.secondary)
                            } else {
                                Spacer()
                                    .frame(height: 10)
                            }
                        }
                        .frame(width: (geometry.size.width - 48) / 24)
                    }
                }
                .frame(height: 40)
            }
            .frame(height: 40)
        }
    }
    
    // 最近活動時間線
    private var recentActivitiesTimeline: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("最近活動")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            if viewModel.recentActivities.isEmpty {
                HStack {
                    Spacer()
                    Text("暫無活動記錄")
                        .font(.system(size: FontSize.body))
                        .foregroundColor(.secondary)
                        .padding()
                    Spacer()
                }
            } else {
                ForEach(viewModel.recentActivities) { activity in
                    activityItem(activity: activity)
                }
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 活動項目
    private func activityItem(activity: ActivityViewModel) -> some View {
        HStack(spacing: 12) {
            // 活動類型圖標
            Image(systemName: activity.icon)
                .font(.system(size: 16))
                .foregroundColor(.white)
                .frame(width: 32, height: 32)
                .background(activity.color)
                .cornerRadius(8)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(activity.title)
                    .font(.system(size: FontSize.body, weight: .medium))
                
                Text(activity.timeDescription)
                    .font(.system(size: FontSize.caption))
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            // 活動詳情按鈕
            Button(action: {
                viewModel.showActivityDetail(activity: activity)
            }) {
                Image(systemName: "chevron.right")
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 8)
    }
    
    // 智能建議卡片（預留）
    private var recommendationCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("智能建議")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            HStack {
                Image(systemName: "lightbulb.fill")
                    .foregroundColor(.warningColor)
                
                Text("根據寶寶的睡眠模式，建議在晚上7:30-8:00之間安排入睡")
                    .font(.system(size: FontSize.body))
                    .foregroundColor(.primary)
            }
            .padding()
            .background(Color.warningColor.opacity(0.1))
            .cornerRadius(8)
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 設置按鈕
    private var settingsButton: some View {
        Button(action: {
            viewModel.showSettings = true
        }) {
            Image(systemName: "gear")
                .foregroundColor(.primary)
        }
        .sheet(isPresented: $viewModel.showSettings) {
            SettingsView(viewModel: viewModel.settingsViewModel)
        }
    }
}
```

### 2.2 主頁視圖模型

```swift
class HomeViewModel: ObservableObject {
    // 發布屬性
    @Published var currentBaby: BabyViewModel?
    @Published var isSleeping: Bool = false
    @Published var lastSleepTime: String = "3小時前"
    @Published var lastSleepQuality: String = "良好"
    @Published var todayTotalSleepTime: String = "5小時30分"
    @Published var todaySleepCount: String = "3次"
    @Published var todayAverageSleepQuality: String = "4.0"
    @Published var sleepHours: [Int] = [0, 1, 2, 9, 10, 13, 14, 20, 21, 22, 23] // 示例數據
    @Published var recentActivities: [ActivityViewModel] = []
    
    // 導航狀態
    @Published var showBabySelector: Bool = false
    @Published var showAddBaby: Bool = false
    @Published var showSettings: Bool = false
    
    // 依賴
    private let babyRepository: BabyRepositoryProtocol
    private let sleepRepository: SleepRepositoryProtocol
    private let sleepUseCases: SleepUseCases
    
    // 子視圖模型
    lazy var babySelectorViewModel = BabySelectorViewModel(babyRepository: babyRepository, onSelect: { [weak self] baby in
        self?.selectBaby(baby: baby)
    })
    
    lazy var addBabyViewModel = AddBabyViewModel(babyRepository: babyRepository, onAdd: { [weak self] baby in
        self?.selectBaby(baby: baby)
    })
    
    lazy var settingsViewModel = SettingsViewModel()
    
    // 初始化
    init(babyRepository: BabyRepositoryProtocol, sleepRepository: SleepRepositoryProtocol, sleepUseCases: SleepUseCases) {
        self.babyRepository = babyRepository
        self.sleepRepository = sleepRepository
        self.sleepUseCases = sleepUseCases
        
        loadInitialData()
    }
    
    // 加載初始數據
    private func loadInitialData() {
        // 獲取所有寶寶
        let babies = babyRepository.getAllBabies()
        
        // 如果有寶寶，選擇第一個
        if let firstBaby = babies.first {
            selectBaby(baby: firstBaby)
        }
    }
    
    // 選擇寶寶
    func selectBaby(baby: Baby) {
        currentBaby = BabyViewModel(baby: baby)
        loadBabyData()
    }
    
    // 加載寶寶數據
    private func loadBabyData() {
        guard let babyId = currentBaby?.id else { return }
        
        // 檢查是否有進行中的睡眠
        if let ongoingSleep = sleepUseCases.hasOngoingSleepRecord(forBabyId: babyId) {
            isSleeping = true
        } else {
            isSleeping = false
        }
        
        // 獲取最近的睡眠記錄
        let sleepRecords = sleepUseCases.getSleepRecords(forBabyId: babyId, days: 1)
        
        // 更新睡眠統計
        if let stats = sleepUseCases.getSleepStatistics(forBabyId: babyId, days: 1) {
            todayTotalSleepTime = formatDuration(minutes: stats.totalSleep)
            todaySleepCount = "\(sleepRecords.count)次"
            todayAverageSleepQuality = String(format: "%.1f", stats.averageQuality)
        }
        
        // 更新最近活動
        updateRecentActivities(babyId: babyId)
    }
    
    // 更新最近活動
    private func updateRecentActivities(babyId: UUID) {
        // 這裡將從數據庫獲取最近活動
        // 示例數據
        recentActivities = [
            ActivityViewModel(
                id: UUID(),
                type: .sleep,
                title: "睡眠",
                timeDescription: "今天 09:30 - 11:00",
                icon: "moon.fill",
                color: .sleepColor
            ),
            ActivityViewModel(
                id: UUID(),
                type: .feeding,
                title: "餵食",
                timeDescription: "今天 08:45 - 09:15",
                icon: "drop.fill",
                color: .feedingColor
            ),
            ActivityViewModel(
                id: UUID(),
                type: .diaper,
                title: "換尿布",
                timeDescription: "今天 08:30",
                icon: "heart.fill",
                color: .diaperColor
            )
        ]
    }
    
    // 開始睡眠
    func startSleep() {
        guard let babyId = currentBaby?.id else { return }
        
        _ = sleepUseCases.startSleepRecord(forBabyId: babyId)
        isSleeping = true
    }
    
    // 結束睡眠
    func endSleep() {
        guard let babyId = currentBaby?.id else { return }
        
        if let ongoingSleep = sleepUseCases.hasOngoingSleepRecord(forBabyId: babyId),
           let recordId = ongoingSleep.id {
            _ = sleepUseCases.endSleepRecord(recordId: recordId)
            isSleeping = false
            
            // 重新加載數據
            loadBabyData()
        }
    }
    
    // 顯示活動詳情
    func showActivityDetail(activity: ActivityViewModel) {
        // 導航到活動詳情頁面
        print("Show activity detail: \(activity.id)")
    }
    
    // 格式化持續時間
    private func formatDuration(minutes: Double) -> String {
        let hours = Int(minutes) / 60
        let mins = Int(minutes) % 60
        
        if hours > 0 {
            return "\(hours)小時\(mins > 0 ? " \(mins)分" : "")"
        } else {
            return "\(mins)分鐘"
        }
    }
}
```

## 3. 睡眠記錄流程與界面

### 3.1 睡眠記錄流程

睡眠記錄流程包括開始睡眠、記錄中斷、結束睡眠三個主要步驟。

```swift
struct SleepRecordView: View {
    @ObservedObject var viewModel: SleepRecordViewModel
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 睡眠狀態卡片
                    sleepStatusCard
                    
                    // 睡眠計時器（如果正在進行中）
                    if viewModel.isRecording {
                        sleepTimerCard
                    }
                    
                    // 開始/結束睡眠表單
                    if viewModel.isRecording {
                        endSleepForm
                    } else {
                        startSleepForm
                    }
                    
                    // 睡眠中斷記錄（如果正在進行中）
                    if viewModel.isRecording {
                        sleepInterruptionSection
                    }
                    
                    // 環境因素記錄
                    environmentFactorsSection
                    
                    // 操作按鈕
                    actionButton
                }
                .padding()
            }
            .background(Color.secondaryBackgroundColor)
            .navigationTitle(viewModel.isRecording ? "記錄睡眠" : "開始睡眠")
            .navigationBarItems(leading: cancelButton)
        }
        .preferredColorScheme(viewModel.isNightMode ? .dark : .none)
    }
    
    // 睡眠狀態卡片
    private var sleepStatusCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "moon.fill")
                    .foregroundColor(.sleepColor)
                
                Text(viewModel.isRecording ? "睡眠進行中" : "新睡眠記錄")
                    .font(.system(size: FontSize.subtitle, weight: .semibold))
                
                Spacer()
                
                // 夜間模式切換
                Button(action: {
                    viewModel.toggleNightMode()
                }) {
                    Image(systemName: viewModel.isNightMode ? "sun.max.fill" : "moon.fill")
                        .foregroundColor(viewModel.isNightMode ? .yellow : .sleepColor)
                }
            }
            
            if let babyName = viewModel.babyName {
                Text("寶寶：\(babyName)")
                    .font(.system(size: FontSize.body))
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 睡眠計時器
    private var sleepTimerCard: some View {
        VStack(spacing: 12) {
            Text(viewModel.formattedDuration)
                .font(.system(size: 48, weight: .semibold))
                .foregroundColor(.sleepColor)
            
            Text("開始時間：\(viewModel.formattedStartTime)")
                .font(.system(size: FontSize.body))
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 開始睡眠表單
    private var startSleepForm: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("開始睡眠")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            // 日期時間選擇器
            DatePicker(
                "開始時間",
                selection: $viewModel.startTime,
                displayedComponents: [.date, .hourAndMinute]
            )
            .datePickerStyle(CompactDatePickerStyle())
            
            // 前置活動選擇
            VStack(alignment: .leading, spacing: 8) {
                Text("前置活動")
                    .font(.system(size: FontSize.body, weight: .medium))
                
                HStack {
                    ForEach(viewModel.preActivities, id: \.self) { activity in
                        Button(action: {
                            viewModel.togglePreActivity(activity)
                        }) {
                            Text(activity)
                                .font(.system(size: FontSize.caption))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(viewModel.selectedPreActivities.contains(activity) ? Color.sleepColor : Color.disabledColor.opacity(0.3))
                                .foregroundColor(viewModel.selectedPreActivities.contains(activity) ? .white : .primary)
                                .cornerRadius(16)
                        }
                    }
                }
            }
            
            // 備註
            VStack(alignment: .leading, spacing: 8) {
                Text("備註")
                    .font(.system(size: FontSize.body, weight: .medium))
                
                TextField("添加備註...", text: $viewModel.notes)
                    .padding()
                    .background(Color.secondaryBackgroundColor)
                    .cornerRadius(8)
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 結束睡眠表單
    private var endSleepForm: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("結束睡眠")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            // 日期時間選擇器
            DatePicker(
                "結束時間",
                selection: $viewModel.endTime,
                displayedComponents: [.date, .hourAndMinute]
            )
            .datePickerStyle(CompactDatePickerStyle())
            
            // 睡眠質量評分
            VStack(alignment: .leading, spacing: 8) {
                Text("睡眠質量")
                    .font(.system(size: FontSize.body, weight: .medium))
                
                HStack {
                    ForEach(1...5, id: \.self) { rating in
                        Button(action: {
                            viewModel.sleepQuality = rating
                        }) {
                            Image(systemName: rating <= viewModel.sleepQuality ? "star.fill" : "star")
                                .font(.system(size: 24))
                                .foregroundColor(rating <= viewModel.sleepQuality ? .yellow : .disabledColor)
                        }
                    }
                }
            }
            
            // 備註
            VStack(alignment: .leading, spacing: 8) {
                Text("備註")
                    .font(.system(size: FontSize.body, weight: .medium))
                
                TextField("添加備註...", text: $viewModel.notes)
                    .padding()
                    .background(Color.secondaryBackgroundColor)
                    .cornerRadius(8)
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 睡眠中斷記錄
    private var sleepInterruptionSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("睡眠中斷")
                    .font(.system(size: FontSize.subtitle, weight: .semibold))
                
                Spacer()
                
                Button(action: {
                    viewModel.showAddInterruption = true
                }) {
                    Image(systemName: "plus.circle.fill")
                        .foregroundColor(.accentColor)
                }
            }
            
            if viewModel.interruptions.isEmpty {
                Text("無中斷記錄")
                    .font(.system(size: FontSize.body))
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            } else {
                ForEach(viewModel.interruptions) { interruption in
                    interruptionItem(interruption: interruption)
                }
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
        .sheet(isPresented: $viewModel.showAddInterruption) {
            AddInterruptionView(viewModel: viewModel.addInterruptionViewModel)
        }
    }
    
    // 中斷項目
    private func interruptionItem(interruption: InterruptionViewModel) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(interruption.reason)
                    .font(.system(size: FontSize.body, weight: .medium))
                
                Text("\(interruption.formattedStartTime) - \(interruption.formattedEndTime) (\(interruption.formattedDuration))")
                    .font(.system(size: FontSize.caption))
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button(action: {
                viewModel.removeInterruption(interruption)
            }) {
                Image(systemName: "trash")
                    .foregroundColor(.errorColor)
            }
        }
        .padding(.vertical, 8)
    }
    
    // 環境因素記錄
    private var environmentFactorsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("環境因素")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            // 光線
            environmentFactorRow(
                title: "光線",
                options: ["明亮", "昏暗", "黑暗"],
                selectedOption: $viewModel.lightCondition
            )
            
            // 噪音
            environmentFactorRow(
                title: "噪音",
                options: ["安靜", "輕微", "嘈雜"],
                selectedOption: $viewModel.noiseLevel
            )
            
            // 溫度
            environmentFactorRow(
                title: "溫度",
                options: ["涼爽", "適中", "溫暖"],
                selectedOption: $viewModel.temperature
            )
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 環境因素行
    private func environmentFactorRow(title: String, options: [String], selectedOption: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.system(size: FontSize.body, weight: .medium))
            
            HStack {
                ForEach(options, id: \.self) { option in
                    Button(action: {
                        selectedOption.wrappedValue = option
                    }) {
                        Text(option)
                            .font(.system(size: FontSize.caption))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(selectedOption.wrappedValue == option ? Color.accentColor : Color.disabledColor.opacity(0.3))
                            .foregroundColor(selectedOption.wrappedValue == option ? .white : .primary)
                            .cornerRadius(16)
                    }
                }
            }
        }
    }
    
    // 操作按鈕
    private var actionButton: some View {
        Button(action: {
            if viewModel.isRecording {
                viewModel.endSleepRecord()
            } else {
                viewModel.startSleepRecord()
            }
            presentationMode.wrappedValue.dismiss()
        }) {
            Text(viewModel.isRecording ? "結束記錄" : "開始記錄")
                .font(.system(size: FontSize.subtitle, weight: .medium))
                .frame(maxWidth: .infinity)
                .padding()
                .background(viewModel.isRecording ? Color.errorColor : Color.sleepColor)
                .foregroundColor(.white)
                .cornerRadius(12)
                .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        }
    }
    
    // 取消按鈕
    private var cancelButton: some View {
        Button(action: {
            presentationMode.wrappedValue.dismiss()
        }) {
            Text("取消")
                .foregroundColor(.primary)
        }
    }
}
```

### 3.2 睡眠記錄視圖模型

```swift
class SleepRecordViewModel: ObservableObject {
    // 發布屬性
    @Published var isRecording: Bool = false
    @Published var babyName: String?
    @Published var startTime: Date = Date()
    @Published var endTime: Date = Date()
    @Published var sleepQuality: Int = 3
    @Published var notes: String = ""
    @Published var lightCondition: String = "昏暗"
    @Published var noiseLevel: String = "安靜"
    @Published var temperature: String = "適中"
    @Published var isNightMode: Bool = false
    @Published var formattedDuration: String = "00:00:00"
    @Published var formattedStartTime: String = ""
    @Published var preActivities: [String] = ["餵食", "洗澡", "換尿布", "閱讀", "唱歌"]
    @Published var selectedPreActivities: [String] = []
    @Published var interruptions: [InterruptionViewModel] = []
    @Published var showAddInterruption: Bool = false
    
    // 依賴
    private let sleepUseCases: SleepUseCases
    private let babyId: UUID
    private var ongoingSleepId: UUID?
    private var timer: Timer?
    private var startDate: Date?
    
    // 子視圖模型
    lazy var addInterruptionViewModel = AddInterruptionViewModel { [weak self] interruption in
        self?.addInterruption(interruption)
    }
    
    // 初始化
    init(babyId: UUID, sleepUseCases: SleepUseCases) {
        self.babyId = babyId
        self.sleepUseCases = sleepUseCases
        
        loadBabyData()
        checkOngoingSleep()
        
        // 如果是晚上10點到早上6點，自動開啟夜間模式
        let hour = Calendar.current.component(.hour, from: Date())
        if hour >= 22 || hour < 6 {
            isNightMode = true
        }
    }
    
    deinit {
        timer?.invalidate()
    }
    
    // 加載寶寶數據
    private func loadBabyData() {
        // 獲取寶寶名稱
        let babyRepository = BabyRepository()
        if let baby = babyRepository.getBaby(byId: babyId) {
            babyName = baby.name
        }
    }
    
    // 檢查進行中的睡眠
    private func checkOngoingSleep() {
        if let ongoingSleep = sleepUseCases.hasOngoingSleepRecord(forBabyId: babyId) {
            isRecording = true
            ongoingSleepId = ongoingSleep.id
            startDate = ongoingSleep.startTime
            
            if let startDate = startDate {
                startTime = startDate
                formattedStartTime = formatDate(startDate)
                startTimer()
            }
            
            // 加載環境因素
            if let environmentFactors = ongoingSleep.environmentFactors?.allObjects as? [EnvironmentFactor] {
                for factor in environmentFactors {
                    if factor.type == "light" {
                        lightCondition = factor.value ?? "昏暗"
                    } else if factor.type == "noise" {
                        noiseLevel = factor.value ?? "安靜"
                    } else if factor.type == "temperature" {
                        temperature = factor.value ?? "適中"
                    }
                }
            }
            
            // 加載中斷記錄
            if let sleepInterruptions = ongoingSleep.sleepInterruptions?.allObjects as? [SleepInterruption] {
                interruptions = sleepInterruptions.map { interruption in
                    InterruptionViewModel(
                        id: interruption.id ?? UUID(),
                        startTime: interruption.startTime ?? Date(),
                        endTime: interruption.endTime ?? Date(),
                        reason: interruption.reason ?? "未知原因"
                    )
                }
            }
        }
    }
    
    // 開始計時器
    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.updateDuration()
        }
        updateDuration()
    }
    
    // 更新持續時間
    private func updateDuration() {
        guard let startDate = startDate else { return }
        
        let duration = Date().timeIntervalSince(startDate)
        let hours = Int(duration) / 3600
        let minutes = Int(duration) % 3600 / 60
        let seconds = Int(duration) % 60
        
        formattedDuration = String(format: "%02d:%02d:%02d", hours, minutes, seconds)
    }
    
    // 開始睡眠記錄
    func startSleepRecord() {
        let record = sleepUseCases.startSleepRecord(forBabyId: babyId, startTime: startTime)
        
        if let record = record, let recordId = record.id {
            ongoingSleepId = recordId
            
            // 添加環境因素
            _ = sleepUseCases.addEnvironmentFactor(toSleepRecordId: recordId, type: "light", value: lightCondition)
            _ = sleepUseCases.addEnvironmentFactor(toSleepRecordId: recordId, type: "noise", value: noiseLevel)
            _ = sleepUseCases.addEnvironmentFactor(toSleepRecordId: recordId, type: "temperature", value: temperature)
        }
    }
    
    // 結束睡眠記錄
    func endSleepRecord() {
        guard let recordId = ongoingSleepId else { return }
        
        _ = sleepUseCases.endSleepRecord(recordId: recordId, endTime: endTime, quality: sleepQuality, notes: notes.isEmpty ? nil : notes)
        
        timer?.invalidate()
        timer = nil
    }
    
    // 切換夜間模式
    func toggleNightMode() {
        isNightMode.toggle()
    }
    
    // 切換前置活動
    func togglePreActivity(_ activity: String) {
        if selectedPreActivities.contains(activity) {
            selectedPreActivities.removeAll { $0 == activity }
        } else {
            selectedPreActivities.append(activity)
        }
    }
    
    // 添加中斷
    func addInterruption(_ interruption: InterruptionViewModel) {
        guard let recordId = ongoingSleepId else { return }
        
        let success = sleepUseCases.recordSleepInterruption(
            forSleepRecordId: recordId,
            startTime: interruption.startTime,
            endTime: interruption.endTime,
            reason: interruption.reason
        )
        
        if success {
            interruptions.append(interruption)
        }
    }
    
    // 移除中斷
    func removeInterruption(_ interruption: InterruptionViewModel) {
        interruptions.removeAll { $0.id == interruption.id }
        // 注意：這裡需要實際從數據庫中刪除中斷記錄
    }
    
    // 格式化日期
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        return formatter.string(from: date)
    }
}
```

### 3.3 添加中斷視圖

```swift
struct AddInterruptionView: View {
    @ObservedObject var viewModel: AddInterruptionViewModel
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("中斷時間")) {
                    DatePicker("開始時間", selection: $viewModel.startTime, displayedComponents: [.date, .hourAndMinute])
                    DatePicker("結束時間", selection: $viewModel.endTime, displayedComponents: [.date, .hourAndMinute])
                }
                
                Section(header: Text("中斷原因")) {
                    Picker("常見原因", selection: $viewModel.selectedReason) {
                        ForEach(viewModel.commonReasons, id: \.self) { reason in
                            Text(reason).tag(reason)
                        }
                    }
                    
                    if viewModel.selectedReason == "其他" {
                        TextField("自定義原因", text: $viewModel.customReason)
                    }
                }
                
                Section {
                    Button(action: {
                        viewModel.saveInterruption()
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Text("保存")
                            .frame(maxWidth: .infinity)
                            .foregroundColor(.white)
                    }
                    .listRowBackground(Color.accentColor)
                    .disabled(!viewModel.isValid)
                }
            }
            .navigationTitle("添加中斷")
            .navigationBarItems(trailing: Button("取消") {
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
}

class AddInterruptionViewModel: ObservableObject {
    @Published var startTime: Date = Date().addingTimeInterval(-10 * 60) // 10分鐘前
    @Published var endTime: Date = Date()
    @Published var selectedReason: String = "哭鬧"
    @Published var customReason: String = ""
    
    let commonReasons = ["哭鬧", "餓了", "尿布濕了", "不舒服", "噪音", "其他"]
    
    private let onSave: (InterruptionViewModel) -> Void
    
    var isValid: Bool {
        if selectedReason == "其他" && customReason.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return false
        }
        
        return startTime < endTime
    }
    
    init(onSave: @escaping (InterruptionViewModel) -> Void) {
        self.onSave = onSave
    }
    
    func saveInterruption() {
        guard isValid else { return }
        
        let reason = selectedReason == "其他" ? customReason : selectedReason
        
        let interruption = InterruptionViewModel(
            id: UUID(),
            startTime: startTime,
            endTime: endTime,
            reason: reason
        )
        
        onSave(interruption)
    }
}

struct InterruptionViewModel: Identifiable {
    let id: UUID
    let startTime: Date
    let endTime: Date
    let reason: String
    
    var formattedStartTime: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: startTime)
    }
    
    var formattedEndTime: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: endTime)
    }
    
    var formattedDuration: String {
        let duration = endTime.timeIntervalSince(startTime) / 60
        return "\(Int(duration))分鐘"
    }
}
```

## 4. 數據視覺化功能

### 4.1 睡眠分析視圖

```swift
struct SleepAnalysisView: View {
    @ObservedObject var viewModel: SleepAnalysisViewModel
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 時間範圍選擇器
                    timeRangeSelector
                    
                    // 睡眠摘要卡片
                    sleepSummaryCard
                    
                    // 睡眠時長趨勢圖
                    sleepDurationTrendCard
                    
                    // 睡眠質量分布圖
                    sleepQualityDistributionCard
                    
                    // 睡眠時間分布圖
                    sleepTimeDistributionCard
                    
                    // 環境因素影響分析
                    environmentFactorsCard
                }
                .padding()
            }
            .background(Color.secondaryBackgroundColor)
            .navigationTitle("睡眠分析")
        }
    }
    
    // 時間範圍選擇器
    private var timeRangeSelector: some View {
        HStack {
            ForEach(viewModel.timeRanges, id: \.self) { range in
                Button(action: {
                    viewModel.selectedTimeRange = range
                    viewModel.loadData()
                }) {
                    Text(range)
                        .font(.system(size: FontSize.caption))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(viewModel.selectedTimeRange == range ? Color.primaryColor : Color.backgroundColor)
                        .foregroundColor(viewModel.selectedTimeRange == range ? .white : .primary)
                        .cornerRadius(16)
                }
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 睡眠摘要卡片
    private var sleepSummaryCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("睡眠摘要")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            HStack(spacing: 20) {
                summaryItem(
                    title: "總睡眠時間",
                    value: viewModel.totalSleepTime,
                    icon: "hourglass",
                    color: .sleepColor
                )
                
                summaryItem(
                    title: "平均每天",
                    value: viewModel.averageDailySleep,
                    icon: "calendar",
                    color: .primaryColor
                )
                
                summaryItem(
                    title: "平均質量",
                    value: viewModel.averageSleepQuality,
                    icon: "star.fill",
                    color: .accentColor
                )
            }
            
            HStack(spacing: 20) {
                summaryItem(
                    title: "記錄次數",
                    value: viewModel.totalSleepCount,
                    icon: "number",
                    color: .primaryColor
                )
                
                summaryItem(
                    title: "平均時長",
                    value: viewModel.averageSleepDuration,
                    icon: "clock",
                    color: .sleepColor
                )
                
                summaryItem(
                    title: "中斷次數",
                    value: viewModel.totalInterruptions,
                    icon: "exclamationmark.circle",
                    color: .errorColor
                )
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 摘要項目
    private func summaryItem(title: String, value: String, icon: String, color: Color) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 20))
                .foregroundColor(color)
            
            Text(title)
                .font(.system(size: FontSize.caption))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            
            Text(value)
                .font(.system(size: FontSize.body, weight: .medium))
                .foregroundColor(.primary)
        }
        .frame(maxWidth: .infinity)
    }
    
    // 睡眠時長趨勢圖
    private var sleepDurationTrendCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("睡眠時長趨勢")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            if viewModel.sleepDurationData.isEmpty {
                Text("暫無數據")
                    .font(.system(size: FontSize.body))
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            } else {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("小時")
                            .font(.system(size: FontSize.caption))
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text("日期")
                            .font(.system(size: FontSize.caption))
                            .foregroundColor(.secondary)
                    }
                    
                    GeometryReader { geometry in
                        ZStack {
                            // Y軸刻度
                            VStack(alignment: .leading, spacing: 0) {
                                ForEach(0...4, id: \.self) { i in
                                    Text("\(12 - i * 3)")
                                        .font(.system(size: 8))
                                        .foregroundColor(.secondary)
                                        .frame(width: 20, alignment: .trailing)
                                        .position(x: 10, y: CGFloat(i) * geometry.size.height / 4)
                                }
                            }
                            
                            // 網格線
                            Path { path in
                                // 水平線
                                for i in 0...4 {
                                    let y = CGFloat(i) * geometry.size.height / 4
                                    path.move(to: CGPoint(x: 20, y: y))
                                    path.addLine(to: CGPoint(x: geometry.size.width, y: y))
                                }
                            }
                            .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                            
                            // 數據線
                            Path { path in
                                let maxValue: CGFloat = 12 // 最大12小時
                                let width = geometry.size.width - 20
                                let height = geometry.size.height
                                
                                guard viewModel.sleepDurationData.count > 1 else { return }
                                
                                let step = width / CGFloat(viewModel.sleepDurationData.count - 1)
                                
                                var startPoint = true
                                
                                for (index, value) in viewModel.sleepDurationData.enumerated() {
                                    let x = 20 + CGFloat(index) * step
                                    let y = height - (CGFloat(value) / maxValue * height)
                                    
                                    if startPoint {
                                        path.move(to: CGPoint(x: x, y: y))
                                        startPoint = false
                                    } else {
                                        path.addLine(to: CGPoint(x: x, y: y))
                                    }
                                }
                            }
                            .stroke(Color.sleepColor, lineWidth: 2)
                            
                            // 數據點
                            ForEach(0..<viewModel.sleepDurationData.count, id: \.self) { index in
                                let maxValue: CGFloat = 12 // 最大12小時
                                let width = geometry.size.width - 20
                                let height = geometry.size.height
                                let step = width / CGFloat(viewModel.sleepDurationData.count - 1)
                                
                                let x = 20 + CGFloat(index) * step
                                let y = height - (CGFloat(viewModel.sleepDurationData[index]) / maxValue * height)
                                
                                Circle()
                                    .fill(Color.sleepColor)
                                    .frame(width: 6, height: 6)
                                    .position(x: x, y: y)
                            }
                            
                            // X軸日期標籤
                            HStack(spacing: 0) {
                                ForEach(0..<viewModel.dateLabels.count, id: \.self) { index in
                                    if index % 2 == 0 || viewModel.dateLabels.count <= 7 {
                                        Text(viewModel.dateLabels[index])
                                            .font(.system(size: 8))
                                            .foregroundColor(.secondary)
                                            .frame(width: width / CGFloat(viewModel.dateLabels.count))
                                    } else {
                                        Spacer()
                                            .frame(width: width / CGFloat(viewModel.dateLabels.count))
                                    }
                                }
                            }
                            .position(x: geometry.size.width / 2, y: geometry.size.height + 10)
                        }
                    }
                    .frame(height: 200)
                }
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 睡眠質量分布圖
    private var sleepQualityDistributionCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("睡眠質量分布")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            if viewModel.qualityDistribution.isEmpty {
                Text("暫無數據")
                    .font(.system(size: FontSize.body))
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            } else {
                HStack(alignment: .bottom, spacing: 8) {
                    ForEach(1...5, id: \.self) { quality in
                        VStack(spacing: 4) {
                            Text("\(viewModel.qualityDistribution[quality - 1])%")
                                .font(.system(size: FontSize.caption))
                                .foregroundColor(.secondary)
                            
                            RoundedRectangle(cornerRadius: 4)
                                .fill(qualityColor(quality))
                                .frame(height: CGFloat(viewModel.qualityDistribution[quality - 1]) * 2)
                            
                            Text("\(quality)星")
                                .font(.system(size: FontSize.caption))
                                .foregroundColor(.secondary)
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .padding(.vertical)
                
                // 質量說明
                VStack(alignment: .leading, spacing: 8) {
                    Text("質量說明")
                        .font(.system(size: FontSize.body, weight: .medium))
                    
                    HStack {
                        ForEach(1...5, id: \.self) { quality in
                            HStack(spacing: 4) {
                                Circle()
                                    .fill(qualityColor(quality))
                                    .frame(width: 8, height: 8)
                                
                                Text(qualityDescription(quality))
                                    .font(.system(size: FontSize.caption))
                                    .foregroundColor(.secondary)
                            }
                            .frame(maxWidth: .infinity)
                        }
                    }
                }
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 睡眠時間分布圖
    private var sleepTimeDistributionCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("睡眠時間分布")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            if viewModel.hourlyDistribution.isEmpty {
                Text("暫無數據")
                    .font(.system(size: FontSize.body))
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            } else {
                VStack(alignment: .leading, spacing: 8) {
                    Text("24小時分布")
                        .font(.system(size: FontSize.body, weight: .medium))
                    
                    GeometryReader { geometry in
                        HStack(alignment: .bottom, spacing: 1) {
                            ForEach(0..<24, id: \.self) { hour in
                                VStack(spacing: 4) {
                                    RoundedRectangle(cornerRadius: 2)
                                        .fill(Color.sleepColor.opacity(Double(viewModel.hourlyDistribution[hour]) / 100.0))
                                        .frame(height: 100)
                                    
                                    if hour % 6 == 0 {
                                        Text("\(hour)")
                                            .font(.system(size: 8))
                                            .foregroundColor(.secondary)
                                    } else {
                                        Spacer()
                                            .frame(height: 10)
                                    }
                                }
                            }
                        }
                    }
                    .frame(height: 120)
                    
                    HStack {
                        Text("凌晨")
                            .font(.system(size: FontSize.caption))
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text("上午")
                            .font(.system(size: FontSize.caption))
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text("下午")
                            .font(.system(size: FontSize.caption))
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text("晚上")
                            .font(.system(size: FontSize.caption))
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 環境因素影響分析
    private var environmentFactorsCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("環境因素影響")
                .font(.system(size: FontSize.subtitle, weight: .semibold))
            
            if viewModel.environmentFactors.isEmpty {
                Text("暫無數據")
                    .font(.system(size: FontSize.body))
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            } else {
                ForEach(viewModel.environmentFactors, id: \.factor) { item in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(item.factor)
                            .font(.system(size: FontSize.body, weight: .medium))
                        
                        HStack {
                            ForEach(item.values, id: \.value) { value in
                                VStack(spacing: 4) {
                                    Text(value.quality)
                                        .font(.system(size: FontSize.caption))
                                        .foregroundColor(.secondary)
                                    
                                    Text(value.value)
                                        .font(.system(size: FontSize.body))
                                        .foregroundColor(.primary)
                                    
                                    Text("\(value.percentage)%")
                                        .font(.system(size: FontSize.caption))
                                        .foregroundColor(.secondary)
                                }
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.secondaryBackgroundColor)
                                .cornerRadius(8)
                                .frame(maxWidth: .infinity)
                            }
                        }
                    }
                    .padding(.vertical, 8)
                    
                    if viewModel.environmentFactors.last?.factor != item.factor {
                        Divider()
                    }
                }
            }
        }
        .padding()
        .background(Color.backgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
    }
    
    // 質量顏色
    private func qualityColor(_ quality: Int) -> Color {
        switch quality {
        case 1: return .errorColor
        case 2: return .warningColor.opacity(0.7)
        case 3: return .warningColor
        case 4: return .successColor.opacity(0.7)
        case 5: return .successColor
        default: return .gray
        }
    }
    
    // 質量描述
    private func qualityDescription(_ quality: Int) -> String {
        switch quality {
        case 1: return "很差"
        case 2: return "較差"
        case 3: return "一般"
        case 4: return "良好"
        case 5: return "優秀"
        default: return ""
        }
    }
}
```

### 4.2 睡眠分析視圖模型

```swift
class SleepAnalysisViewModel: ObservableObject {
    // 發布屬性
    @Published var selectedTimeRange: String = "7天"
    @Published var timeRanges: [String] = ["3天", "7天", "14天", "30天", "全部"]
    
    // 睡眠摘要數據
    @Published var totalSleepTime: String = "0小時"
    @Published var averageDailySleep: String = "0小時"
    @Published var averageSleepQuality: String = "0.0"
    @Published var totalSleepCount: String = "0次"
    @Published var averageSleepDuration: String = "0分鐘"
    @Published var totalInterruptions: String = "0次"
    
    // 睡眠時長趨勢數據
    @Published var sleepDurationData: [Double] = []
    @Published var dateLabels: [String] = []
    
    // 睡眠質量分布數據
    @Published var qualityDistribution: [Int] = [0, 0, 0, 0, 0] // 1-5星的百分比
    
    // 睡眠時間分布數據
    @Published var hourlyDistribution: [Int] = Array(repeating: 0, count: 24) // 0-23小時的百分比
    
    // 環境因素影響數據
    @Published var environmentFactors: [EnvironmentFactorItem] = []
    
    // 依賴
    private let sleepUseCases: SleepUseCases
    private let babyId: UUID
    
    // 初始化
    init(babyId: UUID, sleepUseCases: SleepUseCases) {
        self.babyId = babyId
        self.sleepUseCases = sleepUseCases
        
        loadData()
    }
    
    // 加載數據
    func loadData() {
        // 獲取時間範圍
        let days = getDaysFromTimeRange(selectedTimeRange)
        
        // 獲取睡眠記錄
        let sleepRecords = sleepUseCases.getSleepRecords(forBabyId: babyId, days: days)
        
        // 只考慮已完成的睡眠記錄
        let completedRecords = sleepRecords.filter { $0.endTime != nil && $0.duration != nil && $0.duration! > 0 }
        
        if completedRecords.isEmpty {
            resetData()
            return
        }
        
        // 計算睡眠摘要
        calculateSleepSummary(completedRecords: completedRecords, days: days)
        
        // 計算睡眠時長趨勢
        calculateSleepDurationTrend(completedRecords: completedRecords)
        
        // 計算睡眠質量分布
        calculateQualityDistribution(completedRecords: completedRecords)
        
        // 計算睡眠時間分布
        calculateHourlyDistribution(completedRecords: completedRecords)
        
        // 計算環境因素影響
        calculateEnvironmentFactors(completedRecords: completedRecords)
    }
    
    // 重置數據
    private func resetData() {
        totalSleepTime = "0小時"
        averageDailySleep = "0小時"
        averageSleepQuality = "0.0"
        totalSleepCount = "0次"
        averageSleepDuration = "0分鐘"
        totalInterruptions = "0次"
        sleepDurationData = []
        dateLabels = []
        qualityDistribution = [0, 0, 0, 0, 0]
        hourlyDistribution = Array(repeating: 0, count: 24)
        environmentFactors = []
    }
    
    // 從時間範圍獲取天數
    private func getDaysFromTimeRange(_ range: String) -> Int {
        switch range {
        case "3天": return 3
        case "7天": return 7
        case "14天": return 14
        case "30天": return 30
        case "全部": return 365 // 假設最多一年
        default: return 7
        }
    }
    
    // 計算睡眠摘要
    private func calculateSleepSummary(completedRecords: [SleepRecord], days: Int) {
        // 總睡眠時間（分鐘）
        let totalMinutes = completedRecords.reduce(0) { $0 + ($1.duration ?? 0) }
        
        // 總睡眠時間（小時）
        let totalHours = totalMinutes / 60
        totalSleepTime = formatHours(totalHours)
        
        // 平均每天睡眠時間（小時）
        let avgDailyHours = totalHours / Double(min(days, max(1, Calendar.current.dateComponents([.day], from: completedRecords.last?.startTime ?? Date(), to: Date()).day ?? 1)))
        averageDailySleep = formatHours(avgDailyHours)
        
        // 睡眠記錄次數
        totalSleepCount = "\(completedRecords.count)次"
        
        // 平均每次睡眠時長
        let avgDuration = totalMinutes / Double(completedRecords.count)
        averageSleepDuration = formatMinutes(avgDuration)
        
        // 平均睡眠質量
        let qualityRecords = completedRecords.filter { $0.quality > 0 }
        if !qualityRecords.isEmpty {
            let avgQuality = qualityRecords.reduce(0) { $0 + Double($1.quality) } / Double(qualityRecords.count)
            averageSleepQuality = String(format: "%.1f", avgQuality)
        } else {
            averageSleepQuality = "N/A"
        }
        
        // 總中斷次數
        let interruptions = completedRecords.reduce(0) { $0 + Int($1.interruptionCount) }
        totalInterruptions = "\(interruptions)次"
    }
    
    // 計算睡眠時長趨勢
    private func calculateSleepDurationTrend(completedRecords: [SleepRecord]) {
        // 按日期分組
        let calendar = Calendar.current
        var dailyRecords: [Date: [SleepRecord]] = [:]
        
        for record in completedRecords {
            guard let startTime = record.startTime else { continue }
            
            let dateComponents = calendar.dateComponents([.year, .month, .day], from: startTime)
            if let date = calendar.date(from: dateComponents) {
                if dailyRecords[date] == nil {
                    dailyRecords[date] = []
                }
                dailyRecords[date]?.append(record)
            }
        }
        
        // 排序日期
        let sortedDates = dailyRecords.keys.sorted()
        
        // 計算每日睡眠時長
        sleepDurationData = []
        dateLabels = []
        
        for date in sortedDates {
            if let records = dailyRecords[date] {
                let totalMinutes = records.reduce(0) { $0 + ($1.duration ?? 0) }
                let totalHours = totalMinutes / 60
                sleepDurationData.append(totalHours)
                
                let formatter = DateFormatter()
                formatter.dateFormat = "MM/dd"
                dateLabels.append(formatter.string(from: date))
            }
        }
    }
    
    // 計算睡眠質量分布
    private func calculateQualityDistribution(completedRecords: [SleepRecord]) {
        // 初始化計數
        var counts = [0, 0, 0, 0, 0]
        
        // 統計各質量等級的記錄數
        for record in completedRecords {
            if record.quality > 0 && record.quality <= 5 {
                counts[Int(record.quality) - 1] += 1
            }
        }
        
        // 計算百分比
        let total = counts.reduce(0, +)
        if total > 0 {
            qualityDistribution = counts.map { Int(Double($0) / Double(total) * 100) }
        } else {
            qualityDistribution = [0, 0, 0, 0, 0]
        }
    }
    
    // 計算睡眠時間分布
    private func calculateHourlyDistribution(completedRecords: [SleepRecord]) {
        // 初始化小時計數
        var hourCounts = Array(repeating: 0, count: 24)
        
        // 統計各小時的睡眠時間
        for record in completedRecords {
            guard let startTime = record.startTime, let endTime = record.endTime else { continue }
            
            let calendar = Calendar.current
            let duration = endTime.timeIntervalSince(startTime)
            let intervalMinutes = 15 // 每15分鐘檢查一次
            
            var currentTime = startTime
            while currentTime < endTime {
                let hour = calendar.component(.hour, from: currentTime)
                hourCounts[hour] += 1
                currentTime = currentTime.addingTimeInterval(Double(intervalMinutes * 60))
            }
        }
        
        // 計算百分比
        let maxCount = hourCounts.max() ?? 1
        hourlyDistribution = hourCounts.map { Int(Double($0) / Double(maxCount) * 100) }
    }
    
    // 計算環境因素影響
    private func calculateEnvironmentFactors(completedRecords: [SleepRecord]) {
        // 初始化環境因素數據
        var lightData: [String: (count: Int, totalQuality: Int)] = [:]
        var noiseData: [String: (count: Int, totalQuality: Int)] = [:]
        var temperatureData: [String: (count: Int, totalQuality: Int)] = [:]
        
        // 統計各環境因素的睡眠質量
        for record in completedRecords {
            guard record.quality > 0, let factors = record.environmentFactors?.allObjects as? [EnvironmentFactor] else { continue }
            
            for factor in factors {
                guard let type = factor.type, let value = factor.value else { continue }
                
                switch type {
                case "light":
                    if lightData[value] == nil {
                        lightData[value] = (0, 0)
                    }
                    lightData[value]!.count += 1
                    lightData[value]!.totalQuality += Int(record.quality)
                    
                case "noise":
                    if noiseData[value] == nil {
                        noiseData[value] = (0, 0)
                    }
                    noiseData[value]!.count += 1
                    noiseData[value]!.totalQuality += Int(record.quality)
                    
                case "temperature":
                    if temperatureData[value] == nil {
                        temperatureData[value] = (0, 0)
                    }
                    temperatureData[value]!.count += 1
                    temperatureData[value]!.totalQuality += Int(record.quality)
                    
                default:
                    break
                }
            }
        }
        
        // 計算各環境因素的平均質量和百分比
        environmentFactors = []
        
        if !lightData.isEmpty {
            let totalCount = lightData.values.reduce(0) { $0 + $1.count }
            let values = lightData.map { (key, value) in
                EnvironmentFactorValue(
                    value: key,
                    quality: String(format: "%.1f", Double(value.totalQuality) / Double(value.count)),
                    percentage: Int(Double(value.count) / Double(totalCount) * 100)
                )
            }.sorted { $0.percentage > $1.percentage }
            
            environmentFactors.append(EnvironmentFactorItem(factor: "光線", values: values))
        }
        
        if !noiseData.isEmpty {
            let totalCount = noiseData.values.reduce(0) { $0 + $1.count }
            let values = noiseData.map { (key, value) in
                EnvironmentFactorValue(
                    value: key,
                    quality: String(format: "%.1f", Double(value.totalQuality) / Double(value.count)),
                    percentage: Int(Double(value.count) / Double(totalCount) * 100)
                )
            }.sorted { $0.percentage > $1.percentage }
            
            environmentFactors.append(EnvironmentFactorItem(factor: "噪音", values: values))
        }
        
        if !temperatureData.isEmpty {
            let totalCount = temperatureData.values.reduce(0) { $0 + $1.count }
            let values = temperatureData.map { (key, value) in
                EnvironmentFactorValue(
                    value: key,
                    quality: String(format: "%.1f", Double(value.totalQuality) / Double(value.count)),
                    percentage: Int(Double(value.count) / Double(totalCount) * 100)
                )
            }.sorted { $0.percentage > $1.percentage }
            
            environmentFactors.append(EnvironmentFactorItem(factor: "溫度", values: values))
        }
    }
    
    // 格式化小時
    private func formatHours(_ hours: Double) -> String {
        if hours < 1 {
            return "\(Int(hours * 60))分鐘"
        } else {
            let h = Int(hours)
            let m = Int((hours - Double(h)) * 60)
            if m > 0 {
                return "\(h)小時\(m)分鐘"
            } else {
                return "\(h)小時"
            }
        }
    }
    
    // 格式化分鐘
    private func formatMinutes(_ minutes: Double) -> String {
        if minutes >= 60 {
            let hours = Int(minutes / 60)
            let mins = Int(minutes) % 60
            if mins > 0 {
                return "\(hours)小時\(mins)分鐘"
            } else {
                return "\(hours)小時"
            }
        } else {
            return "\(Int(minutes))分鐘"
        }
    }
}

// 環境因素項目
struct EnvironmentFactorItem {
    let factor: String
    let values: [EnvironmentFactorValue]
}

// 環境因素值
struct EnvironmentFactorValue {
    let value: String
    let quality: String
    let percentage: Int
}
```

## 5. 共用組件

### 5.1 顏色擴展

```swift
import SwiftUI

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }

        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
    
    // 預定義顏色
    static let primaryColor = Color(hex: "6B8EAE")
    static let secondaryColor = Color(hex: "F0C8D0")
    static let accentColor = Color(hex: "A7D7C9")
    static let sleepColor = Color(hex: "8B9EB7")
    static let feedingColor = Color(hex: "F3B391")
    static let diaperColor = Color(hex: "D6A2E8")
    static let successColor = Color(hex: "7FC8A9")
    static let warningColor = Color(hex: "FFD384")
    static let errorColor = Color(hex: "F5A7A7")
    static let disabledColor = Color(hex: "D1D1D6")
    static let backgroundColor = Color(hex: "FFFFFF")
    static let secondaryBackgroundColor = Color(hex: "F8F9FA")
    static let darkBackgroundColor = Color(hex: "2C3E50")
}
```

### 5.2 活動視圖模型

```swift
import SwiftUI

enum ActivityType {
    case sleep
    case feeding
    case diaper
    case bath
    case play
    case custom
}

struct ActivityViewModel: Identifiable {
    let id: UUID
    let type: ActivityType
    let title: String
    let timeDescription: String
    let icon: String
    let color: Color
}
```

### 5.3 寶寶視圖模型

```swift
import UIKit

struct BabyViewModel: Identifiable {
    let id: UUID
    let name: String
    let birthDate: Date
    let gender: String
    let photo: UIImage?
    let developmentStage: String?
    
    init(baby: Baby) {
        self.id = baby.id ?? UUID()
        self.name = baby.name ?? "未命名寶寶"
        self.birthDate = baby.birthDate ?? Date()
        self.gender = baby.gender ?? "未知"
        
        if let photoData = baby.photoData {
            self.photo = UIImage(data: photoData)
        } else {
            self.photo = UIImage(named: "baby_placeholder")
        }
        
        self.developmentStage = baby.developmentStage
    }
    
    var age: String {
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.year, .month, .day], from: birthDate, to: Date())
        
        if let years = ageComponents.year, years > 0 {
            if let months = ageComponents.month, months > 0 {
                return "\(years)歲\(months)個月"
            } else {
                return "\(years)歲"
            }
        } else if let months = ageComponents.month, months > 0 {
            if let days = ageComponents.day, days > 0 {
                return "\(months)個月\(days)天"
            } else {
                return "\(months)個月"
            }
        } else if let days = ageComponents.day {
            return "\(days)天"
        } else {
            return "新生兒"
        }
    }
}
```

## 6. 第二階段實現總結

在第二階段，我們已經實現了以下核心功能：

1. **主頁/儀表板界面**：
   - 設計了溫馨親子風格的主頁
   - 實現了寶寶狀態顯示、睡眠記錄按鈕和活動時間線
   - 提供了睡眠摘要和簡單的數據可視化

2. **睡眠記錄流程與界面**：
   - 實現了完整的睡眠記錄流程（開始、中斷、結束）
   - 設計了環境因素記錄功能
   - 提供了夜間模式支持

3. **數據視覺化功能**：
   - 實現了睡眠時長趨勢圖
   - 設計了睡眠質量分布圖
   - 提供了睡眠時間分布圖和環境因素影響分析

4. **共用組件**：
   - 設計了統一的色彩方案和排版系統
   - 實現了可重用的視圖組件
   - 提供了數據模型轉換和格式化功能

這些實現為用戶提供了直觀、易用的界面，使他們能夠輕鬆記錄和分析寶寶的睡眠情況。界面設計特別考慮了新手父母的使用場景，如疲勞狀態下的操作便利性和夜間使用的舒適度。

在下一階段，我們將專注於本地AI分析功能的開發，進一步提升應用的智能化水平。
