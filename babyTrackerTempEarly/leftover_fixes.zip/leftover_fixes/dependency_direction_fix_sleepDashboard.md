# 寶寶生活記錄專業版（Baby Tracker）- SleepDashboardViewModel 依賴方向修正

## 1. 問題描述

在整合驗證過程中，發現 SleepDashboardViewModel 仍然直接依賴 SleepRepository，而不是通過 UseCase 層訪問數據。這違反了我們在第一階段建立的架構原則，可能導致以下問題：

1. 架構不一致，增加維護難度
2. 依賴方向混亂，降低代碼可讀性
3. 單元測試困難，無法有效模擬依賴
4. 功能擴展受限，難以添加新的業務邏輯
5. 與其他模塊集成困難，特別是第三階段的 AI 分析功能

## 2. 修正方案

### 2.1 創建 UseCase

首先，創建 GetSleepDashboardDataUseCase 來封裝獲取儀表板數據的業務邏輯：

```swift
// GetSleepDashboardDataUseCase.swift

class GetSleepDashboardDataUseCase {
    private let sleepRepository: SleepRepository
    private let babyRepository: BabyRepository
    
    init(sleepRepository: SleepRepository, babyRepository: BabyRepository) {
        self.sleepRepository = sleepRepository
        self.babyRepository = babyRepository
    }
    
    func execute(babyId: UUID, timeRange: TimeRange, completion: @escaping (Result<SleepDashboardData, Error>) -> Void) {
        // 獲取寶寶信息
        babyRepository.getBaby(id: babyId) { [weak self] babyResult in
            guard let self = self else { return }
            
            switch babyResult {
            case .success(let baby):
                // 獲取睡眠記錄
                self.sleepRepository.getSleepRecords(babyId: babyId, timeRange: timeRange) { sleepRecordsResult in
                    switch sleepRecordsResult {
                    case .success(let sleepRecords):
                        // 處理數據
                        let dashboardData = self.processDashboardData(baby: baby, sleepRecords: sleepRecords, timeRange: timeRange)
                        completion(.success(dashboardData))
                    case .failure(let error):
                        completion(.failure(error))
                    }
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    private func processDashboardData(baby: Baby, sleepRecords: [SleepRecord], timeRange: TimeRange) -> SleepDashboardData {
        // 計算睡眠統計數據
        let totalSleepDuration = calculateTotalSleepDuration(sleepRecords)
        let averageSleepDuration = calculateAverageSleepDuration(sleepRecords)
        let sleepQualityDistribution = calculateSleepQualityDistribution(sleepRecords)
        let sleepTimeDistribution = calculateSleepTimeDistribution(sleepRecords)
        let environmentFactorsImpact = calculateEnvironmentFactorsImpact(sleepRecords)
        
        return SleepDashboardData(
            baby: baby,
            timeRange: timeRange,
            totalSleepDuration: totalSleepDuration,
            averageSleepDuration: averageSleepDuration,
            sleepQualityDistribution: sleepQualityDistribution,
            sleepTimeDistribution: sleepTimeDistribution,
            environmentFactorsImpact: environmentFactorsImpact,
            sleepRecords: sleepRecords
        )
    }
    
    private func calculateTotalSleepDuration(_ sleepRecords: [SleepRecord]) -> TimeInterval {
        return sleepRecords.reduce(0) { total, record in
            guard let endTime = record.endTime else { return total }
            return total + endTime.timeIntervalSince(record.startTime)
        }
    }
    
    private func calculateAverageSleepDuration(_ sleepRecords: [SleepRecord]) -> TimeInterval {
        let completedRecords = sleepRecords.filter { $0.endTime != nil }
        guard !completedRecords.isEmpty else { return 0 }
        
        let totalDuration = calculateTotalSleepDuration(completedRecords)
        return totalDuration / Double(completedRecords.count)
    }
    
    private func calculateSleepQualityDistribution(_ sleepRecords: [SleepRecord]) -> [Int: Int] {
        var distribution: [Int: Int] = [:]
        
        for record in sleepRecords {
            let quality = record.quality
            distribution[quality] = (distribution[quality] ?? 0) + 1
        }
        
        return distribution
    }
    
    private func calculateSleepTimeDistribution(_ sleepRecords: [SleepRecord]) -> [Int: TimeInterval] {
        var distribution: [Int: TimeInterval] = [:]
        
        for record in sleepRecords {
            guard let endTime = record.endTime else { continue }
            
            let calendar = Calendar.current
            let hour = calendar.component(.hour, from: record.startTime)
            let duration = endTime.timeIntervalSince(record.startTime)
            
            distribution[hour] = (distribution[hour] ?? 0) + duration
        }
        
        return distribution
    }
    
    private func calculateEnvironmentFactorsImpact(_ sleepRecords: [SleepRecord]) -> [EnvironmentFactorType: [Int: Double]] {
        var impact: [EnvironmentFactorType: [Int: Double]] = [:]
        
        for record in sleepRecords {
            guard let factors = record.environmentFactors else { continue }
            
            for factor in factors {
                if impact[factor.type] == nil {
                    impact[factor.type] = [:]
                }
                
                let quality = record.quality
                let count = impact[factor.type]?[factor.value] ?? 0
                impact[factor.type]?[factor.value] = count + Double(quality)
            }
        }
        
        // 計算平均質量
        for (type, values) in impact {
            for (value, qualitySum) in values {
                let count = sleepRecords.filter { record in
                    guard let factors = record.environmentFactors else { return false }
                    return factors.contains { $0.type == type && $0.value == value }
                }.count
                
                if count > 0 {
                    impact[type]?[value] = qualitySum / Double(count)
                }
            }
        }
        
        return impact
    }
}

// SleepDashboardData.swift

struct SleepDashboardData {
    let baby: Baby
    let timeRange: TimeRange
    let totalSleepDuration: TimeInterval
    let averageSleepDuration: TimeInterval
    let sleepQualityDistribution: [Int: Int]
    let sleepTimeDistribution: [Int: TimeInterval]
    let environmentFactorsImpact: [EnvironmentFactorType: [Int: Double]]
    let sleepRecords: [SleepRecord]
}

// TimeRange.swift

enum TimeRange {
    case day
    case week
    case month
    case custom(from: Date, to: Date)
    
    var title: String {
        switch self {
        case .day:
            return "今日"
        case .week:
            return "本週"
        case .month:
            return "本月"
        case .custom(let from, let to):
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM/dd"
            return "\(dateFormatter.string(from: from)) - \(dateFormatter.string(from: to))"
        }
    }
    
    var dateRange: (from: Date, to: Date) {
        let calendar = Calendar.current
        let now = Date()
        
        switch self {
        case .day:
            let startOfDay = calendar.startOfDay(for: now)
            let endOfDay = calendar.date(byAdding: .day, value: 1, to: startOfDay)!
            return (startOfDay, endOfDay)
        case .week:
            let startOfWeek = calendar.date(from: calendar.dateComponents([.yearForWeekOfYear, .weekOfYear], from: now))!
            let endOfWeek = calendar.date(byAdding: .weekOfYear, value: 1, to: startOfWeek)!
            return (startOfWeek, endOfWeek)
        case .month:
            let components = calendar.dateComponents([.year, .month], from: now)
            let startOfMonth = calendar.date(from: components)!
            let endOfMonth = calendar.date(byAdding: .month, value: 1, to: startOfMonth)!
            return (startOfMonth, endOfMonth)
        case .custom(let from, let to):
            return (from, to)
        }
    }
}
```

### 2.2 修改 SleepDashboardViewModel

接下來，修改 SleepDashboardViewModel 使用新的 UseCase：

```swift
// SleepDashboardViewModel.swift

class SleepDashboardViewModel: ObservableObject {
    // 輸出數據
    @Published var isLoading: Bool = false
    @Published var selectedTimeRange: TimeRange = .day
    @Published var totalSleepDuration: TimeInterval = 0
    @Published var averageSleepDuration: TimeInterval = 0
    @Published var sleepQualityDistribution: [Int: Int] = [:]
    @Published var sleepTimeDistribution: [Int: TimeInterval] = [:]
    @Published var environmentFactorsImpact: [EnvironmentFactorType: [Int: Double]] = [:]
    @Published var sleepRecords: [SleepRecord] = []
    
    // 依賴
    private let getSleepDashboardDataUseCase: GetSleepDashboardDataUseCase
    private let errorHandler: ErrorHandlingService
    private let babyId: UUID
    
    // 初始化
    init(babyId: UUID, 
         getSleepDashboardDataUseCase: GetSleepDashboardDataUseCase,
         errorHandler: ErrorHandlingService) {
        self.babyId = babyId
        self.getSleepDashboardDataUseCase = getSleepDashboardDataUseCase
        self.errorHandler = errorHandler
        
        loadData()
    }
    
    // 加載數據
    func loadData() {
        isLoading = true
        
        getSleepDashboardDataUseCase.execute(babyId: babyId, timeRange: selectedTimeRange) { [weak self] result in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isLoading = false
                
                self.errorHandler.handleResult(result) { dashboardData in
                    self.totalSleepDuration = dashboardData.totalSleepDuration
                    self.averageSleepDuration = dashboardData.averageSleepDuration
                    self.sleepQualityDistribution = dashboardData.sleepQualityDistribution
                    self.sleepTimeDistribution = dashboardData.sleepTimeDistribution
                    self.environmentFactorsImpact = dashboardData.environmentFactorsImpact
                    self.sleepRecords = dashboardData.sleepRecords
                }
            }
        }
    }
    
    // 更改時間範圍
    func changeTimeRange(_ timeRange: TimeRange) {
        selectedTimeRange = timeRange
        loadData()
    }
    
    // 格式化總睡眠時間
    var formattedTotalSleepDuration: String {
        formatDuration(totalSleepDuration)
    }
    
    // 格式化平均睡眠時間
    var formattedAverageSleepDuration: String {
        formatDuration(averageSleepDuration)
    }
    
    // 格式化時間
    private func formatDuration(_ duration: TimeInterval) -> String {
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60
        
        if hours > 0 {
            return String(format: "%d小時%02d分鐘", hours, minutes)
        } else {
            return String(format: "%d分鐘", minutes)
        }
    }
    
    // 獲取睡眠質量分布數據
    var sleepQualityChartData: [SleepQualityChartDataPoint] {
        var data: [SleepQualityChartDataPoint] = []
        
        for quality in 1...10 {
            let count = sleepQualityDistribution[quality] ?? 0
            data.append(SleepQualityChartDataPoint(quality: quality, count: count))
        }
        
        return data
    }
    
    // 獲取睡眠時間分布數據
    var sleepTimeChartData: [SleepTimeChartDataPoint] {
        var data: [SleepTimeChartDataPoint] = []
        
        for hour in 0..<24 {
            let duration = sleepTimeDistribution[hour] ?? 0
            data.append(SleepTimeChartDataPoint(hour: hour, duration: duration))
        }
        
        return data
    }
    
    // 獲取環境因素影響數據
    func environmentFactorImpactChartData(for type: EnvironmentFactorType) -> [EnvironmentFactorImpactChartDataPoint] {
        var data: [EnvironmentFactorImpactChartDataPoint] = []
        
        if let impact = environmentFactorsImpact[type] {
            for value in 0...10 {
                let quality = impact[value] ?? 0
                data.append(EnvironmentFactorImpactChartDataPoint(value: value, quality: quality))
            }
        }
        
        return data
    }
}

// 圖表數據結構
struct SleepQualityChartDataPoint: Identifiable {
    let id = UUID()
    let quality: Int
    let count: Int
}

struct SleepTimeChartDataPoint: Identifiable {
    let id = UUID()
    let hour: Int
    let duration: TimeInterval
}

struct EnvironmentFactorImpactChartDataPoint: Identifiable {
    let id = UUID()
    let value: Int
    let quality: Double
}
```

### 2.3 更新依賴注入

最後，更新 DependencyContainer 以提供新的 UseCase：

```swift
// DependencyContainer.swift

class DependencyContainer {
    // 存儲庫
    lazy var babyRepository: BabyRepository = CoreDataBabyRepository(coreDataManager: coreDataManager)
    lazy var sleepRepository: SleepRepository = CoreDataSleepRepository(coreDataManager: coreDataManager)
    lazy var feedingRepository: FeedingRepository = CoreDataFeedingRepository(coreDataManager: coreDataManager)
    lazy var diaperRepository: DiaperRepository = CoreDataDiaperRepository(coreDataManager: coreDataManager)
    lazy var growthRepository: GrowthRepository = CoreDataGrowthRepository(coreDataManager: coreDataManager)
    lazy var milestoneRepository: MilestoneRepository = CoreDataMilestoneRepository(coreDataManager: coreDataManager)
    lazy var activityRepository: ActivityRepository = CoreDataActivityRepository(coreDataManager: coreDataManager)
    
    // 核心服務
    lazy var coreDataManager: CoreDataManager = CoreDataManager()
    lazy var errorHandlingService: ErrorHandlingService = ErrorHandlingService()
    
    // 用例
    lazy var getBabyUseCase: GetBabyUseCase = GetBabyUseCase(babyRepository: babyRepository)
    lazy var saveBabyUseCase: SaveBabyUseCase = SaveBabyUseCase(babyRepository: babyRepository)
    lazy var deleteBabyUseCase: DeleteBabyUseCase = DeleteBabyUseCase(babyRepository: babyRepository)
    
    lazy var getSleepRecordsUseCase: GetSleepRecordsUseCase = GetSleepRecordsUseCase(sleepRepository: sleepRepository)
    lazy var saveSleepRecordUseCase: SaveSleepRecordUseCase = SaveSleepRecordUseCase(sleepRepository: sleepRepository)
    lazy var deleteSleepRecordUseCase: DeleteSleepRecordUseCase = DeleteSleepRecordUseCase(sleepRepository: sleepRepository)
    
    // 新增的 UseCase
    lazy var getSleepDashboardDataUseCase: GetSleepDashboardDataUseCase = GetSleepDashboardDataUseCase(
        sleepRepository: sleepRepository,
        babyRepository: babyRepository
    )
    
    // 其他 UseCase...
    
    // 視圖模型工廠
    func makeBabyViewModel(baby: Baby? = nil) -> BabyViewModel {
        if let baby = baby {
            return BabyViewModel(
                baby: baby,
                saveBabyUseCase: saveBabyUseCase,
                errorHandler: errorHandlingService
            )
        } else {
            return BabyViewModel(
                saveBabyUseCase: saveBabyUseCase,
                errorHandler: errorHandlingService
            )
        }
    }
    
    func makeSleepRecordViewModel(record: SleepRecord? = nil, babyId: UUID? = nil) -> SleepRecordViewModel {
        if let record = record {
            return SleepRecordViewModel(
                record: record,
                saveSleepRecordUseCase: saveSleepRecordUseCase,
                errorHandler: errorHandlingService
            )
        } else if let babyId = babyId {
            return SleepRecordViewModel(
                babyId: babyId,
                saveSleepRecordUseCase: saveSleepRecordUseCase,
                errorHandler: errorHandlingService
            )
        } else {
            fatalError("Either record or babyId must be provided")
        }
    }
    
    // 新增的視圖模型工廠方法
    func makeSleepDashboardViewModel(babyId: UUID) -> SleepDashboardViewModel {
        return SleepDashboardViewModel(
            babyId: babyId,
            getSleepDashboardDataUseCase: getSleepDashboardDataUseCase,
            errorHandler: errorHandlingService
        )
    }
    
    // 其他視圖模型工廠方法...
}
```

### 2.4 更新 UI 實現

更新 SleepDashboardView 使用新的視圖模型：

```swift
// SleepDashboardView.swift

struct SleepDashboardView: View {
    @ObservedObject var viewModel: SleepDashboardViewModel
    @EnvironmentObject var dependencyContainer: DependencyContainer
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // 時間範圍選擇器
                TimeRangeSelector(
                    selectedTimeRange: $viewModel.selectedTimeRange,
                    onTimeRangeChanged: { viewModel.changeTimeRange($0) }
                )
                
                // 睡眠總覽卡片
                SleepOverviewCard(
                    totalSleepDuration: viewModel.formattedTotalSleepDuration,
                    averageSleepDuration: viewModel.formattedAverageSleepDuration
                )
                
                // 睡眠質量分布圖
                SleepQualityChart(data: viewModel.sleepQualityChartData)
                
                // 睡眠時間分布圖
                SleepTimeChart(data: viewModel.sleepTimeChartData)
                
                // 環境因素影響分析
                EnvironmentFactorsImpactSection(viewModel: viewModel)
                
                // 睡眠記錄列表
                SleepRecordsList(records: viewModel.sleepRecords)
            }
            .padding()
        }
        .navigationTitle("睡眠儀表板")
        .overlay(
            Group {
                if viewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle())
                        .scaleEffect(1.5)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color.black.opacity(0.1))
                }
            }
        )
    }
}

// 其他視圖組件...
```

## 3. 測試計劃

為確保修正的正確性，需要進行以下測試：

### 3.1 單元測試

```swift
// GetSleepDashboardDataUseCaseTests.swift

class GetSleepDashboardDataUseCaseTests: XCTestCase {
    var sleepRepository: MockSleepRepository!
    var babyRepository: MockBabyRepository!
    var useCase: GetSleepDashboardDataUseCase!
    
    override func setUp() {
        super.setUp()
        sleepRepository = MockSleepRepository()
        babyRepository = MockBabyRepository()
        useCase = GetSleepDashboardDataUseCase(sleepRepository: sleepRepository, babyRepository: babyRepository)
    }
    
    func testExecute_Success() {
        // 準備測試數據
        let babyId = UUID()
        let baby = Baby(id: babyId, name: "Test Baby", birthDate: Date(), gender: .male, avatarUrl: nil, notes: "", createdAt: Date(), updatedAt: Date())
        
        let sleepRecord1 = SleepRecord(id: UUID(), babyId: babyId, startTime: Date(), endTime: Date().addingTimeInterval(3600), quality: 8, notes: "", interruptions: nil, environmentFactors: nil, createdAt: Date(), updatedAt: Date())
        
        let sleepRecord2 = SleepRecord(id: UUID(), babyId: babyId, startTime: Date().addingTimeInterval(-7200), endTime: Date().addingTimeInterval(-3600), quality: 6, notes: "", interruptions: nil, environmentFactors: nil, createdAt: Date(), updatedAt: Date())
        
        // 設置 Mock 返回值
        babyRepository.getBabyResult = .success(baby)
        sleepRepository.getSleepRecordsResult = .success([sleepRecord1, sleepRecord2])
        
        // 執行測試
        let expectation = self.expectation(description: "Execute completed")
        
        useCase.execute(babyId: babyId, timeRange: .day) { result in
            switch result {
            case .success(let data):
                // 驗證結果
                XCTAssertEqual(data.baby.id, babyId)
                XCTAssertEqual(data.sleepRecords.count, 2)
                XCTAssertEqual(data.totalSleepDuration, 7200) // 3600 + 3600
                XCTAssertEqual(data.averageSleepDuration, 3600) // (3600 + 3600) / 2
                
                // 驗證睡眠質量分布
                XCTAssertEqual(data.sleepQualityDistribution[8], 1)
                XCTAssertEqual(data.sleepQualityDistribution[6], 1)
                
                expectation.fulfill()
            case .failure:
                XCTFail("Should not fail")
            }
        }
        
        waitForExpectations(timeout: 1, handler: nil)
    }
    
    func testExecute_BabyFailure() {
        // 準備測試數據
        let babyId = UUID()
        let error = NSError(domain: "test", code: 1, userInfo: nil)
        
        // 設置 Mock 返回值
        babyRepository.getBabyResult = .failure(error)
        
        // 執行測試
        let expectation = self.expectation(description: "Execute completed")
        
        useCase.execute(babyId: babyId, timeRange: .day) { result in
            switch result {
            case .success:
                XCTFail("Should fail")
            case .failure:
                expectation.fulfill()
            }
        }
        
        waitForExpectations(timeout: 1, handler: nil)
    }
    
    func testExecute_SleepRecordsFailure() {
        // 準備測試數據
        let babyId = UUID()
        let baby = Baby(id: babyId, name: "Test Baby", birthDate: Date(), gender: .male, avatarUrl: nil, notes: "", createdAt: Date(), updatedAt: Date())
        let error = NSError(domain: "test", code: 1, userInfo: nil)
        
        // 設置 Mock 返回值
        babyRepository.getBabyResult = .success(baby)
        sleepRepository.getSleepRecordsResult = .failure(error)
        
        // 執行測試
        let expectation = self.expectation(description: "Execute completed")
        
        useCase.execute(babyId: babyId, timeRange: .day) { result in
            switch result {
            case .success:
                XCTFail("Should fail")
            case .failure:
                expectation.fulfill()
            }
        }
        
        waitForExpectations(timeout: 1, handler: nil)
    }
}

// SleepDashboardViewModelTests.swift

class SleepDashboardViewModelTests: XCTestCase {
    var getSleepDashboardDataUseCase: MockGetSleepDashboardDataUseCase!
    var errorHandler: ErrorHandlingService!
    var viewModel: SleepDashboardViewModel!
    
    override func setUp() {
        super.setUp()
        getSleepDashboardDataUseCase = MockGetSleepDashboardDataUseCase()
        errorHandler = ErrorHandlingService()
        viewModel = SleepDashboardViewModel(
            babyId: UUID(),
            getSleepDashboardDataUseCase: getSleepDashboardDataUseCase,
            errorHandler: errorHandler
        )
    }
    
    func testLoadData_Success() {
        // 準備測試數據
        let baby = Baby(id: UUID(), name: "Test Baby", birthDate: Date(), gender: .male, avatarUrl: nil, notes: "", createdAt: Date(), updatedAt: Date())
        
        let dashboardData = SleepDashboardData(
            baby: baby,
            timeRange: .day,
            totalSleepDuration: 7200,
            averageSleepDuration: 3600,
            sleepQualityDistribution: [8: 1, 6: 1],
            sleepTimeDistribution: [10: 3600, 12: 3600],
            environmentFactorsImpact: [:],
            sleepRecords: []
        )
        
        // 設置 Mock 返回值
        getSleepDashboardDataUseCase.executeResult = .success(dashboardData)
        
        // 執行測試
        viewModel.loadData()
        
        // 驗證結果
        XCTAssertEqual(viewModel.totalSleepDuration, 7200)
        XCTAssertEqual(viewModel.averageSleepDuration, 3600)
        XCTAssertEqual(viewModel.sleepQualityDistribution[8], 1)
        XCTAssertEqual(viewModel.sleepQualityDistribution[6], 1)
        XCTAssertEqual(viewModel.sleepTimeDistribution[10], 3600)
        XCTAssertEqual(viewModel.sleepTimeDistribution[12], 3600)
        XCTAssertEqual(viewModel.formattedTotalSleepDuration, "2小時00分鐘")
        XCTAssertEqual(viewModel.formattedAverageSleepDuration, "1小時00分鐘")
    }
    
    func testLoadData_Failure() {
        // 準備測試數據
        let error = NSError(domain: "test", code: 1, userInfo: nil)
        
        // 設置 Mock 返回值
        getSleepDashboardDataUseCase.executeResult = .failure(error)
        
        // 執行測試
        viewModel.loadData()
        
        // 驗證結果
        XCTAssertEqual(viewModel.totalSleepDuration, 0)
        XCTAssertEqual(viewModel.averageSleepDuration, 0)
        XCTAssertTrue(viewModel.sleepQualityDistribution.isEmpty)
        XCTAssertTrue(viewModel.sleepTimeDistribution.isEmpty)
        XCTAssertTrue(viewModel.environmentFactorsImpact.isEmpty)
        XCTAssertTrue(viewModel.sleepRecords.isEmpty)
    }
    
    func testChangeTimeRange() {
        // 準備測試數據
        let baby = Baby(id: UUID(), name: "Test Baby", birthDate: Date(), gender: .male, avatarUrl: nil, notes: "", createdAt: Date(), updatedAt: Date())
        
        let dashboardData = SleepDashboardData(
            baby: baby,
            timeRange: .week,
            totalSleepDuration: 7200,
            averageSleepDuration: 3600,
            sleepQualityDistribution: [8: 1, 6: 1],
            sleepTimeDistribution: [10: 3600, 12: 3600],
            environmentFactorsImpact: [:],
            sleepRecords: []
        )
        
        // 設置 Mock 返回值
        getSleepDashboardDataUseCase.executeResult = .success(dashboardData)
        
        // 執行測試
        viewModel.changeTimeRange(.week)
        
        // 驗證結果
        XCTAssertEqual(viewModel.selectedTimeRange, .week)
        XCTAssertEqual(getSleepDashboardDataUseCase.lastTimeRange, .week)
    }
}

// Mock 類

class MockSleepRepository: SleepRepository {
    var getSleepRecordsResult: Result<[SleepRecord], Error> = .success([])
    
    func getSleepRecords(babyId: UUID, timeRange: TimeRange, completion: @escaping (Result<[SleepRecord], Error>) -> Void) {
        completion(getSleepRecordsResult)
    }
    
    // 其他方法實現...
}

class MockBabyRepository: BabyRepository {
    var getBabyResult: Result<Baby, Error> = .success(Baby(id: UUID(), name: "Test Baby", birthDate: Date(), gender: .male, avatarUrl: nil, notes: "", createdAt: Date(), updatedAt: Date()))
    
    func getBaby(id: UUID, completion: @escaping (Result<Baby, Error>) -> Void) {
        completion(getBabyResult)
    }
    
    // 其他方法實現...
}

class MockGetSleepDashboardDataUseCase: GetSleepDashboardDataUseCase {
    var executeResult: Result<SleepDashboardData, Error> = .success(SleepDashboardData(
        baby: Baby(id: UUID(), name: "Test Baby", birthDate: Date(), gender: .male, avatarUrl: nil, notes: "", createdAt: Date(), updatedAt: Date()),
        timeRange: .day,
        totalSleepDuration: 0,
        averageSleepDuration: 0,
        sleepQualityDistribution: [:],
        sleepTimeDistribution: [:],
        environmentFactorsImpact: [:],
        sleepRecords: []
    ))
    
    var lastBabyId: UUID?
    var lastTimeRange: TimeRange?
    
    override func execute(babyId: UUID, timeRange: TimeRange, completion: @escaping (Result<SleepDashboardData, Error>) -> Void) {
        lastBabyId = babyId
        lastTimeRange = timeRange
        completion(executeResult)
    }
}
```

### 3.2 集成測試

```swift
// SleepDashboardIntegrationTests.swift

class SleepDashboardIntegrationTests: XCTestCase {
    var coreDataManager: CoreDataManager!
    var sleepRepository: SleepRepository!
    var babyRepository: BabyRepository!
    var getSleepDashboardDataUseCase: GetSleepDashboardDataUseCase!
    var viewModel: SleepDashboardViewModel!
    
    override func setUp() {
        super.setUp()
        
        // 使用內存存儲的 Core Data
        coreDataManager = CoreDataManager(inMemory: true)
        
        // 創建真實的存儲庫
        sleepRepository = CoreDataSleepRepository(coreDataManager: coreDataManager)
        babyRepository = CoreDataBabyRepository(coreDataManager: coreDataManager)
        
        // 創建真實的 UseCase
        getSleepDashboardDataUseCase = GetSleepDashboardDataUseCase(
            sleepRepository: sleepRepository,
            babyRepository: babyRepository
        )
        
        // 創建測試數據
        createTestData()
        
        // 創建視圖模型
        viewModel = SleepDashboardViewModel(
            babyId: testBabyId,
            getSleepDashboardDataUseCase: getSleepDashboardDataUseCase,
            errorHandler: ErrorHandlingService()
        )
    }
    
    var testBabyId: UUID!
    
    func createTestData() {
        // 創建寶寶
        let baby = Baby(
            id: UUID(),
            name: "Test Baby",
            birthDate: Date(),
            gender: .male,
            avatarUrl: nil,
            notes: "",
            createdAt: Date(),
            updatedAt: Date()
        )
        
        let expectation = self.expectation(description: "Save baby")
        
        babyRepository.saveBaby(baby) { result in
            switch result {
            case .success(let savedBaby):
                self.testBabyId = savedBaby.id
                expectation.fulfill()
            case .failure:
                XCTFail("Failed to save baby")
            }
        }
        
        waitForExpectations(timeout: 1, handler: nil)
        
        // 創建睡眠記錄
        let now = Date()
        let calendar = Calendar.current
        let startOfDay = calendar.startOfDay(for: now)
        
        let sleepRecord1 = SleepRecord(
            id: UUID(),
            babyId: testBabyId,
            startTime: calendar.date(byAdding: .hour, value: -8, to: startOfDay)!,
            endTime: calendar.date(byAdding: .hour, value: -6, to: startOfDay)!,
            quality: 8,
            notes: "",
            interruptions: nil,
            environmentFactors: [
                EnvironmentFactor(
                    id: UUID(),
                    sleepRecordId: UUID(),
                    type: .light,
                    value: 2
                )
            ],
            createdAt: Date(),
            updatedAt: Date()
        )
        
        let sleepRecord2 = SleepRecord(
            id: UUID(),
            babyId: testBabyId,
            startTime: calendar.date(byAdding: .hour, value: 12, to: startOfDay)!,
            endTime: calendar.date(byAdding: .hour, value: 14, to: startOfDay)!,
            quality: 6,
            notes: "",
            interruptions: nil,
            environmentFactors: [
                EnvironmentFactor(
                    id: UUID(),
                    sleepRecordId: UUID(),
                    type: .noise,
                    value: 7
                )
            ],
            createdAt: Date(),
            updatedAt: Date()
        )
        
        let expectation2 = self.expectation(description: "Save sleep records")
        expectation2.expectedFulfillmentCount = 2
        
        sleepRepository.saveSleepRecord(sleepRecord1) { _ in
            expectation2.fulfill()
        }
        
        sleepRepository.saveSleepRecord(sleepRecord2) { _ in
            expectation2.fulfill()
        }
        
        waitForExpectations(timeout: 1, handler: nil)
    }
    
    func testLoadData() {
        // 執行測試
        let expectation = self.expectation(description: "Load data")
        
        // 重置視圖模型狀態
        viewModel.totalSleepDuration = 0
        viewModel.averageSleepDuration = 0
        viewModel.sleepQualityDistribution = [:]
        viewModel.sleepTimeDistribution = [:]
        viewModel.environmentFactorsImpact = [:]
        viewModel.sleepRecords = []
        
        // 加載數據
        viewModel.loadData()
        
        // 使用延遲檢查結果，因為視圖模型的更新是異步的
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            // 驗證結果
            XCTAssertEqual(self.viewModel.sleepRecords.count, 2)
            XCTAssertEqual(self.viewModel.totalSleepDuration, 14400) // 2小時 + 2小時
            XCTAssertEqual(self.viewModel.averageSleepDuration, 7200) // (2小時 + 2小時) / 2
            
            // 驗證睡眠質量分布
            XCTAssertEqual(self.viewModel.sleepQualityDistribution[8], 1)
            XCTAssertEqual(self.viewModel.sleepQualityDistribution[6], 1)
            
            // 驗證睡眠時間分布
            let calendar = Calendar.current
            let startOfDay = calendar.startOfDay(for: Date())
            
            let hour1 = calendar.component(.hour, from: calendar.date(byAdding: .hour, value: -8, to: startOfDay)!)
            let hour2 = calendar.component(.hour, from: calendar.date(byAdding: .hour, value: 12, to: startOfDay)!)
            
            XCTAssertEqual(self.viewModel.sleepTimeDistribution[hour1], 7200) // 2小時
            XCTAssertEqual(self.viewModel.sleepTimeDistribution[hour2], 7200) // 2小時
            
            // 驗證環境因素影響
            XCTAssertEqual(self.viewModel.environmentFactorsImpact[.light]?[2], 8.0)
            XCTAssertEqual(self.viewModel.environmentFactorsImpact[.noise]?[7], 6.0)
            
            expectation.fulfill()
        }
        
        waitForExpectations(timeout: 1, handler: nil)
    }
    
    func testChangeTimeRange() {
        // 執行測試
        let expectation = self.expectation(description: "Change time range")
        
        // 更改時間範圍
        viewModel.changeTimeRange(.week)
        
        // 使用延遲檢查結果，因為視圖模型的更新是異步的
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            // 驗證結果
            XCTAssertEqual(self.viewModel.selectedTimeRange, .week)
            XCTAssertEqual(self.viewModel.sleepRecords.count, 2) // 仍然應該有兩條記錄，因為它們都在本週內
            
            expectation.fulfill()
        }
        
        waitForExpectations(timeout: 1, handler: nil)
    }
}
```

### 3.3 UI 測試

```swift
// SleepDashboardUITests.swift

class SleepDashboardUITests: XCTestCase {
    var app: XCUIApplication!
    
    override func setUp() {
        super.setUp()
        continueAfterFailure = false
        app = XCUIApplication()
        app.launchArguments = ["UI_TESTING"]
        app.launch()
        
        // 導航到睡眠儀表板
        navigateToSleepDashboard()
    }
    
    func navigateToSleepDashboard() {
        // 假設我們有一個導航到睡眠儀表板的路徑
        app.tabBars.buttons["睡眠"].tap()
        app.buttons["儀表板"].tap()
    }
    
    func testTimeRangeSelection() {
        // 驗證默認時間範圍是"今日"
        XCTAssertTrue(app.buttons["今日"].exists)
        
        // 切換到"本週"
        app.buttons["本週"].tap()
        
        // 驗證加載指示器出現然後消失
        XCTAssertTrue(app.activityIndicators.firstMatch.waitForExistence(timeout: 1))
        XCTAssertFalse(app.activityIndicators.firstMatch.waitForExistence(timeout: 3))
        
        // 驗證時間範圍已更改
        XCTAssertTrue(app.staticTexts["本週睡眠統計"].exists)
    }
    
    func testSleepQualityChart() {
        // 驗證睡眠質量圖表存在
        XCTAssertTrue(app.otherElements["SleepQualityChart"].waitForExistence(timeout: 2))
        
        // 驗證圖表標題
        XCTAssertTrue(app.staticTexts["睡眠質量分布"].exists)
    }
    
    func testSleepTimeChart() {
        // 驗證睡眠時間圖表存在
        XCTAssertTrue(app.otherElements["SleepTimeChart"].waitForExistence(timeout: 2))
        
        // 驗證圖表標題
        XCTAssertTrue(app.staticTexts["睡眠時間分布"].exists)
    }
    
    func testEnvironmentFactorsImpact() {
        // 驗證環境因素影響部分存在
        XCTAssertTrue(app.staticTexts["環境因素影響"].exists)
        
        // 驗證光線因素存在
        XCTAssertTrue(app.buttons["光線"].exists)
        
        // 點擊光線因素
        app.buttons["光線"].tap()
        
        // 驗證光線影響圖表出現
        XCTAssertTrue(app.otherElements["EnvironmentFactorImpactChart"].waitForExistence(timeout: 2))
    }
    
    func testSleepRecordsList() {
        // 驗證睡眠記錄列表存在
        XCTAssertTrue(app.staticTexts["睡眠記錄"].exists)
        
        // 驗證至少有一條睡眠記錄
        XCTAssertTrue(app.cells.firstMatch.waitForExistence(timeout: 2))
        
        // 點擊第一條記錄
        app.cells.firstMatch.tap()
        
        // 驗證詳情頁面出現
        XCTAssertTrue(app.navigationBars["睡眠記錄詳情"].waitForExistence(timeout: 2))
    }
}
```

## 4. 修正實施

### 4.1 實施步驟

1. 創建 GetSleepDashboardDataUseCase 類
2. 修改 SleepDashboardViewModel 使用新的 UseCase
3. 更新 DependencyContainer 提供新的 UseCase
4. 更新 UI 實現
5. 編寫單元測試、集成測試和 UI 測試
6. 運行測試並修復問題
7. 進行代碼審查

### 4.2 實施時間表

| 步驟 | 預計時間 |
|-----|---------|
| 創建 GetSleepDashboardDataUseCase | 2 小時 |
| 修改 SleepDashboardViewModel | 1 小時 |
| 更新 DependencyContainer | 0.5 小時 |
| 更新 UI 實現 | 0.5 小時 |
| 編寫測試 | 3 小時 |
| 運行測試和修復問題 | 2 小時 |
| 代碼審查 | 1 小時 |
| **總計** | **10 小時** |

## 5. 風險與緩解措施

| 風險 | 可能性 | 影響 | 緩解措施 |
|-----|-------|------|---------|
| 修改可能引入新的錯誤 | 中 | 高 | 全面的測試覆蓋，包括單元測試、集成測試和 UI 測試 |
| 性能可能受到影響 | 低 | 中 | 性能測試，確保修改不會顯著影響性能 |
| 與其他模塊的集成問題 | 中 | 高 | 全面的集成測試，確保與其他模塊的兼容性 |
| 用戶體驗可能受到影響 | 低 | 高 | UI 測試，確保用戶體驗不受影響 |
| 修改可能導致數據不一致 | 低 | 高 | 數據一致性測試，確保數據的完整性和一致性 |

## 6. 總結

本修正方案解決了 SleepDashboardViewModel 直接依賴 SleepRepository 的問題，通過引入 GetSleepDashboardDataUseCase 確保了依賴方向的一致性。修正後的架構更加清晰，職責分離更加明確，為第三階段的 AI 分析功能開發奠定了堅實的基礎。

修正方案包括：

1. 創建 GetSleepDashboardDataUseCase 封裝業務邏輯
2. 修改 SleepDashboardViewModel 使用新的 UseCase
3. 更新 DependencyContainer 提供新的 UseCase
4. 更新 UI 實現
5. 編寫全面的測試

通過這些修改，我們確保了架構的一致性，提高了代碼的可維護性和可測試性，為未來的功能擴展提供了更好的支持。
