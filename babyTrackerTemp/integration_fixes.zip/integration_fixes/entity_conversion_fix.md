# 寶寶生活記錄專業版（Baby Tracker）- 添加實體轉換方法

## 1. 問題描述

在第一階段與第二階段整合性驗證中，發現部分ViewModel缺少完整的實體轉換方法，特別是從ViewModel轉換回領域實體（Domain Entity）的方法。這種不完整的轉換機制會導致以下問題：

1. 數據流不完整，無法保證視圖層數據能正確回寫到數據層
2. 編輯功能受限，因為無法將修改後的ViewModel數據轉換回實體進行保存
3. 代碼重複，每個需要轉換的地方都需要手動映射屬性
4. 數據一致性風險，手動映射容易遺漏屬性或映射錯誤
5. 第三階段AI分析功能可能無法獲取完整的用戶修改數據

## 2. 修正方案

### 2.1 定義通用的實體轉換協議

首先，定義一個通用的實體轉換協議，所有ViewModel都應實現該協議：

```swift
// EntityConvertible.swift

protocol EntityConvertible {
    associatedtype Entity
    
    // 從實體創建ViewModel
    init(entity: Entity, dependencies: Any...)
    
    // 將ViewModel轉換為實體
    func toEntity() -> Entity
}
```

### 2.2 為BabyViewModel添加實體轉換方法

```swift
// BabyViewModel.swift

class BabyViewModel: ObservableObject, Identifiable, EntityConvertible {
    typealias Entity = Baby
    
    let id: UUID
    @Published var name: String
    @Published var birthDate: Date
    @Published var gender: Gender
    @Published var avatarUrl: URL?
    @Published var notes: String
    let createdAt: Date
    @Published var updatedAt: Date
    
    @Published var isLoading: Bool = false
    
    private let saveBabyUseCase: SaveBabyUseCase
    private let errorHandler: ErrorHandlingService
    
    // 從實體創建ViewModel
    init(baby: Baby, saveBabyUseCase: SaveBabyUseCase, errorHandler: ErrorHandlingService) {
        self.id = baby.id
        self.name = baby.name
        self.birthDate = baby.birthDate
        self.gender = baby.gender
        self.avatarUrl = baby.avatarUrl
        self.notes = baby.notes
        self.createdAt = baby.createdAt
        self.updatedAt = baby.updatedAt
        self.saveBabyUseCase = saveBabyUseCase
        self.errorHandler = errorHandler
    }
    
    // 創建新寶寶
    init(id: UUID = UUID(),
         name: String = "",
         birthDate: Date = Date(),
         gender: Gender = .unknown,
         avatarUrl: URL? = nil,
         notes: String = "",
         saveBabyUseCase: SaveBabyUseCase,
         errorHandler: ErrorHandlingService) {
        self.id = id
        self.name = name
        self.birthDate = birthDate
        self.gender = gender
        self.avatarUrl = avatarUrl
        self.notes = notes
        self.createdAt = Date()
        self.updatedAt = Date()
        self.saveBabyUseCase = saveBabyUseCase
        self.errorHandler = errorHandler
    }
    
    // 將ViewModel轉換為實體
    func toEntity() -> Baby {
        return Baby(
            id: id,
            name: name,
            birthDate: birthDate,
            gender: gender,
            avatarUrl: avatarUrl,
            notes: notes,
            createdAt: createdAt,
            updatedAt: Date()
        )
    }
    
    // 保存寶寶
    func saveBaby(completion: @escaping () -> Void) {
        isLoading = true
        
        let baby = toEntity()
        
        saveBabyUseCase.execute(baby: baby) { [weak self] result in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isLoading = false
                
                self.errorHandler.handleResult(result) { _ in
                    self.updatedAt = Date()
                    completion()
                }
            }
        }
    }
    
    // 獲取寶寶年齡
    var age: String {
        let now = Date()
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.year, .month, .day], from: birthDate, to: now)
        
        if let years = ageComponents.year, years > 0 {
            if let months = ageComponents.month, months > 0 {
                return "\(years)歲\(months)個月"
            } else {
                return "\(years)歲"
            }
        } else if let months = ageComponents.month, months > 0 {
            if let days = ageComponents.day, days > 0 {
                return "\(months)個月\(days)天"
            } else {
                return "\(months)個月"
            }
        } else if let days = ageComponents.day {
            return "\(days)天"
        } else {
            return "新生兒"
        }
    }
}
```

### 2.3 為SleepRecordViewModel添加實體轉換方法

```swift
// SleepRecordViewModel.swift

class SleepRecordViewModel: ObservableObject, Identifiable, EntityConvertible {
    typealias Entity = SleepRecord
    
    let id: UUID
    let babyId: UUID
    @Published var startTime: Date
    @Published var endTime: Date?
    @Published var quality: Int
    @Published var notes: String
    @Published var interruptions: [SleepInterruptionViewModel] = []
    @Published var environmentFactors: [EnvironmentFactorViewModel] = []
    let createdAt: Date
    @Published var updatedAt: Date
    
    @Published var isLoading: Bool = false
    
    private let saveSleepRecordUseCase: SaveSleepRecordUseCase
    private let errorHandler: ErrorHandlingService
    
    // 從實體創建ViewModel
    init(record: SleepRecord, saveSleepRecordUseCase: SaveSleepRecordUseCase, errorHandler: ErrorHandlingService) {
        self.id = record.id
        self.babyId = record.babyId
        self.startTime = record.startTime
        self.endTime = record.endTime
        self.quality = record.quality
        self.notes = record.notes
        self.createdAt = record.createdAt
        self.updatedAt = record.updatedAt
        self.saveSleepRecordUseCase = saveSleepRecordUseCase
        self.errorHandler = errorHandler
        
        // 轉換中斷記錄
        if let interruptions = record.interruptions {
            self.interruptions = interruptions.map { interruption in
                SleepInterruptionViewModel(interruption: interruption)
            }
        }
        
        // 轉換環境因素
        if let environmentFactors = record.environmentFactors {
            self.environmentFactors = environmentFactors.map { factor in
                EnvironmentFactorViewModel(factor: factor)
            }
        }
    }
    
    // 創建新睡眠記錄
    init(id: UUID = UUID(),
         babyId: UUID,
         startTime: Date = Date(),
         endTime: Date? = nil,
         quality: Int = 5,
         notes: String = "",
         saveSleepRecordUseCase: SaveSleepRecordUseCase,
         errorHandler: ErrorHandlingService) {
        self.id = id
        self.babyId = babyId
        self.startTime = startTime
        self.endTime = endTime
        self.quality = quality
        self.notes = notes
        self.createdAt = Date()
        self.updatedAt = Date()
        self.saveSleepRecordUseCase = saveSleepRecordUseCase
        self.errorHandler = errorHandler
    }
    
    // 將ViewModel轉換為實體
    func toEntity() -> SleepRecord {
        return SleepRecord(
            id: id,
            babyId: babyId,
            startTime: startTime,
            endTime: endTime,
            quality: quality,
            notes: notes,
            interruptions: interruptions.map { $0.toEntity() },
            environmentFactors: environmentFactors.map { $0.toEntity() },
            createdAt: createdAt,
            updatedAt: Date()
        )
    }
    
    // 保存睡眠記錄
    func saveSleepRecord(completion: @escaping () -> Void) {
        isLoading = true
        
        let sleepRecord = toEntity()
        
        saveSleepRecordUseCase.execute(sleepRecord: sleepRecord) { [weak self] result in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isLoading = false
                
                self.errorHandler.handleResult(result) { _ in
                    self.updatedAt = Date()
                    completion()
                }
            }
        }
    }
    
    // 開始睡眠
    func startSleep() {
        startTime = Date()
        endTime = nil
    }
    
    // 結束睡眠
    func endSleep() {
        endTime = Date()
    }
    
    // 添加中斷
    func addInterruption(reason: String, startTime: Date, endTime: Date? = nil) {
        let interruption = SleepInterruptionViewModel(
            sleepRecordId: id,
            reason: reason,
            startTime: startTime,
            endTime: endTime
        )
        interruptions.append(interruption)
    }
    
    // 添加環境因素
    func addEnvironmentFactor(type: EnvironmentFactorType, value: Int) {
        let factor = EnvironmentFactorViewModel(
            sleepRecordId: id,
            type: type,
            value: value
        )
        environmentFactors.append(factor)
    }
    
    // 獲取睡眠持續時間
    var duration: TimeInterval? {
        guard let endTime = endTime else { return nil }
        return endTime.timeIntervalSince(startTime)
    }
    
    // 格式化的持續時間
    var formattedDuration: String {
        guard let duration = duration else { return "進行中" }
        
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60
        
        if hours > 0 {
            return String(format: "%d小時%02d分鐘", hours, minutes)
        } else {
            return String(format: "%d分鐘", minutes)
        }
    }
}
```

### 2.4 為SleepInterruptionViewModel添加實體轉換方法

```swift
// SleepInterruptionViewModel.swift

class SleepInterruptionViewModel: Identifiable, EntityConvertible {
    typealias Entity = SleepInterruption
    
    let id: UUID
    let sleepRecordId: UUID
    var reason: String
    var startTime: Date
    var endTime: Date?
    
    // 從實體創建ViewModel
    init(interruption: SleepInterruption) {
        self.id = interruption.id
        self.sleepRecordId = interruption.sleepRecordId
        self.reason = interruption.reason
        self.startTime = interruption.startTime
        self.endTime = interruption.endTime
    }
    
    // 創建新中斷記錄
    init(id: UUID = UUID(),
         sleepRecordId: UUID,
         reason: String,
         startTime: Date = Date(),
         endTime: Date? = nil) {
        self.id = id
        self.sleepRecordId = sleepRecordId
        self.reason = reason
        self.startTime = startTime
        self.endTime = endTime
    }
    
    // 將ViewModel轉換為實體
    func toEntity() -> SleepInterruption {
        return SleepInterruption(
            id: id,
            sleepRecordId: sleepRecordId,
            reason: reason,
            startTime: startTime,
            endTime: endTime
        )
    }
    
    // 獲取中斷持續時間
    var duration: TimeInterval? {
        guard let endTime = endTime else { return nil }
        return endTime.timeIntervalSince(startTime)
    }
    
    // 格式化的持續時間
    var formattedDuration: String {
        guard let duration = duration else { return "進行中" }
        
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        
        return String(format: "%d分%02d秒", minutes, seconds)
    }
}
```

### 2.5 為EnvironmentFactorViewModel添加實體轉換方法

```swift
// EnvironmentFactorViewModel.swift

class EnvironmentFactorViewModel: Identifiable, EntityConvertible {
    typealias Entity = EnvironmentFactor
    
    let id: UUID
    let sleepRecordId: UUID
    var type: EnvironmentFactorType
    var value: Int
    
    // 從實體創建ViewModel
    init(factor: EnvironmentFactor) {
        self.id = factor.id
        self.sleepRecordId = factor.sleepRecordId
        self.type = factor.type
        self.value = factor.value
    }
    
    // 創建新環境因素
    init(id: UUID = UUID(),
         sleepRecordId: UUID,
         type: EnvironmentFactorType,
         value: Int) {
        self.id = id
        self.sleepRecordId = sleepRecordId
        self.type = type
        self.value = value
    }
    
    // 將ViewModel轉換為實體
    func toEntity() -> EnvironmentFactor {
        return EnvironmentFactor(
            id: id,
            sleepRecordId: sleepRecordId,
            type: type,
            value: value
        )
    }
    
    // 獲取環境因素的本地化名稱
    var typeLocalizedName: String {
        switch type {
        case .light:
            return "光線"
        case .noise:
            return "噪音"
        case .temperature:
            return "溫度"
        case .humidity:
            return "濕度"
        }
    }
    
    // 獲取環境因素的圖標名稱
    var typeIconName: String {
        switch type {
        case .light:
            return "sun.max"
        case .noise:
            return "speaker.wave.3"
        case .temperature:
            return "thermometer"
        case .humidity:
            return "humidity"
        }
    }
    
    // 獲取環境因素的值描述
    var valueDescription: String {
        switch type {
        case .light:
            return lightValueDescription
        case .noise:
            return noiseValueDescription
        case .temperature:
            return temperatureValueDescription
        case .humidity:
            return humidityValueDescription
        }
    }
    
    // 光線值描述
    private var lightValueDescription: String {
        switch value {
        case 0...2:
            return "非常暗"
        case 3...4:
            return "較暗"
        case 5...6:
            return "適中"
        case 7...8:
            return "較亮"
        default:
            return "非常亮"
        }
    }
    
    // 噪音值描述
    private var noiseValueDescription: String {
        switch value {
        case 0...2:
            return "非常安靜"
        case 3...4:
            return "較安靜"
        case 5...6:
            return "適中"
        case 7...8:
            return "較吵"
        default:
            return "非常吵"
        }
    }
    
    // 溫度值描述
    private var temperatureValueDescription: String {
        switch value {
        case 0...2:
            return "非常冷"
        case 3...4:
            return "較冷"
        case 5...6:
            return "適中"
        case 7...8:
            return "較熱"
        default:
            return "非常熱"
        }
    }
    
    // 濕度值描述
    private var humidityValueDescription: String {
        switch value {
        case 0...2:
            return "非常乾燥"
        case 3...4:
            return "較乾燥"
        case 5...6:
            return "適中"
        case 7...8:
            return "較潮濕"
        default:
            return "非常潮濕"
        }
    }
}
```

### 2.6 為FeedingRecordViewModel添加實體轉換方法

```swift
// FeedingRecordViewModel.swift

enum FeedingType: String, CaseIterable {
    case breastfeeding = "breastfeeding"
    case bottleBreastMilk = "bottleBreastMilk"
    case formula = "formula"
    case solidFood = "solidFood"
}

class FeedingRecordViewModel: ObservableObject, Identifiable, EntityConvertible {
    typealias Entity = FeedingRecord
    
    let id: UUID
    let babyId: UUID
    @Published var type: FeedingType
    @Published var startTime: Date
    @Published var endTime: Date?
    @Published var amount: Double?
    @Published var unit: String?
    @Published var foodType: String?
    @Published var notes: String
    let createdAt: Date
    @Published var updatedAt: Date
    
    @Published var isLoading: Bool = false
    
    private let saveFeedingRecordUseCase: SaveFeedingRecordUseCase
    private let errorHandler: ErrorHandlingService
    
    // 從實體創建ViewModel
    init(record: FeedingRecord, saveFeedingRecordUseCase: SaveFeedingRecordUseCase, errorHandler: ErrorHandlingService) {
        self.id = record.id
        self.babyId = record.babyId
        self.type = FeedingType(rawValue: record.type) ?? .breastfeeding
        self.startTime = record.startTime
        self.endTime = record.endTime
        self.amount = record.amount
        self.unit = record.unit
        self.foodType = record.foodType
        self.notes = record.notes
        self.createdAt = record.createdAt
        self.updatedAt = record.updatedAt
        self.saveFeedingRecordUseCase = saveFeedingRecordUseCase
        self.errorHandler = errorHandler
    }
    
    // 創建新餵食記錄
    init(id: UUID = UUID(),
         babyId: UUID,
         type: FeedingType = .breastfeeding,
         startTime: Date = Date(),
         endTime: Date? = nil,
         amount: Double? = nil,
         unit: String? = nil,
         foodType: String? = nil,
         notes: String = "",
         saveFeedingRecordUseCase: SaveFeedingRecordUseCase,
         errorHandler: ErrorHandlingService) {
        self.id = id
        self.babyId = babyId
        self.type = type
        self.startTime = startTime
        self.endTime = endTime
        self.amount = amount
        self.unit = unit
        self.foodType = foodType
        self.notes = notes
        self.createdAt = Date()
        self.updatedAt = Date()
        self.saveFeedingRecordUseCase = saveFeedingRecordUseCase
        self.errorHandler = errorHandler
    }
    
    // 將ViewModel轉換為實體
    func toEntity() -> FeedingRecord {
        return FeedingRecord(
            id: id,
            babyId: babyId,
            type: type.rawValue,
            startTime: startTime,
            endTime: endTime,
            amount: amount,
            unit: unit,
            foodType: foodType,
            notes: notes,
            createdAt: createdAt,
            updatedAt: Date()
        )
    }
    
    // 保存餵食記錄
    func saveFeedingRecord(completion: @escaping () -> Void) {
        isLoading = true
        
        let feedingRecord = toEntity()
        
        saveFeedingRecordUseCase.execute(feedingRecord: feedingRecord) { [weak self] result in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isLoading = false
                
                self.errorHandler.handleResult(result) { _ in
                    self.updatedAt = Date()
                    completion()
                }
            }
        }
    }
    
    // 開始餵食
    func startFeeding() {
        startTime = Date()
        endTime = nil
    }
    
    // 結束餵食
    func endFeeding() {
        endTime = Date()
    }
    
    // 獲取餵食持續時間
    var duration: TimeInterval? {
        guard let endTime = endTime else { return nil }
        return endTime.timeIntervalSince(startTime)
    }
    
    // 格式化的持續時間
    var formattedDuration: String {
        guard let duration = duration else { return "進行中" }
        
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        
        return String(format: "%d分%02d秒", minutes, seconds)
    }
    
    // 獲取餵食類型的本地化名稱
    var typeLocalizedName: String {
        switch type {
        case .breastfeeding:
            return "母乳餵食"
        case .bottleBreastMilk:
            return "瓶餵母乳"
        case .formula:
            return "配方奶"
        case .solidFood:
            return "固體食物"
        }
    }
    
    // 獲取餵食類型的圖標名稱
    var typeIconName: String {
        switch type {
        case .breastfeeding:
            return "person.fill"
        case .bottleBreastMilk:
            return "drop.fill"
        case .formula:
            return "bottle.fill"
        case .solidFood:
            return "fork.knife"
        }
    }
}
```

### 2.7 為DiaperRecordViewModel添加實體轉換方法

```swift
// DiaperRecordViewModel.swift

enum DiaperType: String, CaseIterable {
    case wet = "wet"
    case dirty = "dirty"
    case mixed = "mixed"
    case dry = "dry"
}

class DiaperRecordViewModel: ObservableObject, Identifiable, EntityConvertible {
    typealias Entity = DiaperRecord
    
    let id: UUID
    let babyId: UUID
    @Published var type: DiaperType
    @Published var time: Date
    @Published var color: String?
    @Published var consistency: String?
    @Published var notes: String
    let createdAt: Date
    @Published var updatedAt: Date
    
    @Published var isLoading: Bool = false
    
    private let saveDiaperRecordUseCase: SaveDiaperRecordUseCase
    private let errorHandler: ErrorHandlingService
    
    // 從實體創建ViewModel
    init(record: DiaperRecord, saveDiaperRecordUseCase: SaveDiaperRecordUseCase, errorHandler: ErrorHandlingService) {
        self.id = record.id
        self.babyId = record.babyId
        self.type = DiaperType(rawValue: record.type) ?? .wet
        self.time = record.time
        self.color = record.color
        self.consistency = record.consistency
        self.notes = record.notes
        self.createdAt = record.createdAt
        self.updatedAt = record.updatedAt
        self.saveDiaperRecordUseCase = saveDiaperRecordUseCase
        self.errorHandler = errorHandler
    }
    
    // 創建新尿布記錄
    init(id: UUID = UUID(),
         babyId: UUID,
         type: DiaperType = .wet,
         time: Date = Date(),
         color: String? = nil,
         consistency: String? = nil,
         notes: String = "",
         saveDiaperRecordUseCase: SaveDiaperRecordUseCase,
         errorHandler: ErrorHandlingService) {
        self.id = id
        self.babyId = babyId
        self.type = type
        self.time = time
        self.color = color
        self.consistency = consistency
        self.notes = notes
        self.createdAt = Date()
        self.updatedAt = Date()
        self.saveDiaperRecordUseCase = saveDiaperRecordUseCase
        self.errorHandler = errorHandler
    }
    
    // 將ViewModel轉換為實體
    func toEntity() -> DiaperRecord {
        return DiaperRecord(
            id: id,
            babyId: babyId,
            type: type.rawValue,
            time: time,
            color: color,
            consistency: consistency,
            notes: notes,
            createdAt: createdAt,
            updatedAt: Date()
        )
    }
    
    // 保存尿布記錄
    func saveDiaperRecord(completion: @escaping () -> Void) {
        isLoading = true
        
        let diaperRecord = toEntity()
        
        saveDiaperRecordUseCase.execute(diaperRecord: diaperRecord) { [weak self] result in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isLoading = false
                
                self.errorHandler.handleResult(result) { _ in
                    self.updatedAt = Date()
                    completion()
                }
            }
        }
    }
    
    // 獲取尿布類型的本地化名稱
    var typeLocalizedName: String {
        switch type {
        case .wet:
            return "尿尿"
        case .dirty:
            return "便便"
        case .mixed:
            return "尿尿和便便"
        case .dry:
            return "乾爽"
        }
    }
    
    // 獲取尿布類型的圖標名稱
    var typeIconName: String {
        switch type {
        case .wet:
            return "drop.fill"
        case .dirty:
            return "star.fill"
        case .mixed:
            return "drop.fill.star.fill"
        case .dry:
            return "checkmark.circle.fill"
        }
    }
    
    // 獲取尿布類型的顏色
    var typeColor: Color {
        switch type {
        case .wet:
            return Color.blue
        case .dirty:
            return Color.brown
        case .mixed:
            return Color.purple
        case .dry:
            return Color.green
        }
    }
}
```

### 2.8 為GrowthRecordViewModel添加實體轉換方法

```swift
// GrowthRecordViewModel.swift

class GrowthRecordViewModel: ObservableObject, Identifiable, EntityConvertible {
    typealias Entity = GrowthRecord
    
    let id: UUID
    let babyId: UUID
    @Published var date: Date
    @Published var height: Double?
    @Published var weight: Double?
    @Published var headCircumference: Double?
    @Published var notes: String
    let createdAt: Date
    @Published var updatedAt: Date
    
    @Published var isLoading: Bool = false
    
    private let saveGrowthRecordUseCase: SaveGrowthRecordUseCase
    private let errorHandler: ErrorHandlingService
    
    // 從實體創建ViewModel
    init(record: GrowthRecord, saveGrowthRecordUseCase: SaveGrowthRecordUseCase, errorHandler: ErrorHandlingService) {
        self.id = record.id
        self.babyId = record.babyId
        self.date = record.date
        self.height = record.height
        self.weight = record.weight
        self.headCircumference = record.headCircumference
        self.notes = record.notes
        self.createdAt = record.createdAt
        self.updatedAt = record.updatedAt
        self.saveGrowthRecordUseCase = saveGrowthRecordUseCase
        self.errorHandler = errorHandler
    }
    
    // 創建新成長記錄
    init(id: UUID = UUID(),
         babyId: UUID,
         date: Date = Date(),
         height: Double? = nil,
         weight: Double? = nil,
         headCircumference: Double? = nil,
         notes: String = "",
         saveGrowthRecordUseCase: SaveGrowthRecordUseCase,
         errorHandler: ErrorHandlingService) {
        self.id = id
        self.babyId = babyId
        self.date = date
        self.height = height
        self.weight = weight
        self.headCircumference = headCircumference
        self.notes = notes
        self.createdAt = Date()
        self.updatedAt = Date()
        self.saveGrowthRecordUseCase = saveGrowthRecordUseCase
        self.errorHandler = errorHandler
    }
    
    // 將ViewModel轉換為實體
    func toEntity() -> GrowthRecord {
        return GrowthRecord(
            id: id,
            babyId: babyId,
            date: date,
            height: height,
            weight: weight,
            headCircumference: headCircumference,
            notes: notes,
            createdAt: createdAt,
            updatedAt: Date()
        )
    }
    
    // 保存成長記錄
    func saveGrowthRecord(completion: @escaping () -> Void) {
        isLoading = true
        
        let growthRecord = toEntity()
        
        saveGrowthRecordUseCase.execute(growthRecord: growthRecord) { [weak self] result in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isLoading = false
                
                self.errorHandler.handleResult(result) { _ in
                    self.updatedAt = Date()
                    completion()
                }
            }
        }
    }
    
    // 格式化的身高
    var formattedHeight: String {
        guard let height = height else { return "未記錄" }
        return String(format: "%.1f厘米", height)
    }
    
    // 格式化的體重
    var formattedWeight: String {
        guard let weight = weight else { return "未記錄" }
        return String(format: "%.2f公斤", weight)
    }
    
    // 格式化的頭圍
    var formattedHeadCircumference: String {
        guard let headCircumference = headCircumference else { return "未記錄" }
        return String(format: "%.1f厘米", headCircumference)
    }
}
```

### 2.9 為MilestoneViewModel添加實體轉換方法

```swift
// MilestoneViewModel.swift

class MilestoneViewModel: ObservableObject, Identifiable, EntityConvertible {
    typealias Entity = Milestone
    
    let id: UUID
    let babyId: UUID
    @Published var title: String
    @Published var date: Date
    @Published var category: String
    @Published var description: String
    @Published var photoUrl: URL?
    let createdAt: Date
    @Published var updatedAt: Date
    
    @Published var isLoading: Bool = false
    
    private let saveMilestoneUseCase: SaveMilestoneUseCase
    private let errorHandler: ErrorHandlingService
    
    // 從實體創建ViewModel
    init(milestone: Milestone, saveMilestoneUseCase: SaveMilestoneUseCase, errorHandler: ErrorHandlingService) {
        self.id = milestone.id
        self.babyId = milestone.babyId
        self.title = milestone.title
        self.date = milestone.date
        self.category = milestone.category
        self.description = milestone.description
        self.photoUrl = milestone.photoUrl
        self.createdAt = milestone.createdAt
        self.updatedAt = milestone.updatedAt
        self.saveMilestoneUseCase = saveMilestoneUseCase
        self.errorHandler = errorHandler
    }
    
    // 創建新里程碑
    init(id: UUID = UUID(),
         babyId: UUID,
         title: String = "",
         date: Date = Date(),
         category: String = "",
         description: String = "",
         photoUrl: URL? = nil,
         saveMilestoneUseCase: SaveMilestoneUseCase,
         errorHandler: ErrorHandlingService) {
        self.id = id
        self.babyId = babyId
        self.title = title
        self.date = date
        self.category = category
        self.description = description
        self.photoUrl = photoUrl
        self.createdAt = Date()
        self.updatedAt = Date()
        self.saveMilestoneUseCase = saveMilestoneUseCase
        self.errorHandler = errorHandler
    }
    
    // 將ViewModel轉換為實體
    func toEntity() -> Milestone {
        return Milestone(
            id: id,
            babyId: babyId,
            title: title,
            date: date,
            category: category,
            description: description,
            photoUrl: photoUrl,
            createdAt: createdAt,
            updatedAt: Date()
        )
    }
    
    // 保存里程碑
    func saveMilestone(completion: @escaping () -> Void) {
        isLoading = true
        
        let milestone = toEntity()
        
        saveMilestoneUseCase.execute(milestone: milestone) { [weak self] result in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isLoading = false
                
                self.errorHandler.handleResult(result) { _ in
                    self.updatedAt = Date()
                    completion()
                }
            }
        }
    }
    
    // 獲取里程碑的圖標名稱
    var categoryIconName: String {
        switch category.lowercased() {
        case "movement", "運動":
            return "figure.walk"
        case "language", "語言":
            return "text.bubble"
        case "social", "社交":
            return "person.2"
        case "cognitive", "認知":
            return "brain"
        default:
            return "star"
        }
    }
    
    // 獲取里程碑的顏色
    var categoryColor: Color {
        switch category.lowercased() {
        case "movement", "運動":
            return Color.green
        case "language", "語言":
            return Color.blue
        case "social", "社交":
            return Color.purple
        case "cognitive", "認知":
            return Color.orange
        default:
            return Color.pink
        }
    }
}
```

## 3. 具體修正實施

### 3.1 定義通用的實體轉換協議

首先，創建EntityConvertible.swift文件，定義通用的實體轉換協議：

```swift
// EntityConvertible.swift
// 完整實現見2.1節
```

### 3.2 為所有ViewModel添加實體轉換方法

接下來，為所有ViewModel添加實體轉換方法：

```swift
// BabyViewModel.swift
// 完整實現見2.2節

// SleepRecordViewModel.swift
// 完整實現見2.3節

// SleepInterruptionViewModel.swift
// 完整實現見2.4節

// EnvironmentFactorViewModel.swift
// 完整實現見2.5節

// FeedingRecordViewModel.swift
// 完整實現見2.6節

// DiaperRecordViewModel.swift
// 完整實現見2.7節

// GrowthRecordViewModel.swift
// 完整實現見2.8節

// MilestoneViewModel.swift
// 完整實現見2.9節
```

### 3.3 更新UseCase實現

確保所有UseCase正確使用實體：

```swift
// SaveBabyUseCase.swift

class SaveBabyUseCase {
    private let babyRepository: BabyRepository
    
    init(babyRepository: BabyRepository) {
        self.babyRepository = babyRepository
    }
    
    func execute(baby: Baby, completion: @escaping (Result<Baby, Error>) -> Void) {
        babyRepository.saveBaby(baby, completion: completion)
    }
}

// SaveSleepRecordUseCase.swift

class SaveSleepRecordUseCase {
    private let sleepRepository: SleepRepository
    
    init(sleepRepository: SleepRepository) {
        self.sleepRepository = sleepRepository
    }
    
    func execute(sleepRecord: SleepRecord, completion: @escaping (Result<SleepRecord, Error>) -> Void) {
        sleepRepository.saveSleepRecord(sleepRecord, completion: completion)
    }
}

// 其他UseCase類似修改...
```

### 3.4 更新UI實現

更新UI實現，使用ViewModel的toEntity方法：

```swift
// BabyEditView.swift

struct BabyEditView: View {
    @ObservedObject var viewModel: BabyViewModel
    @EnvironmentObject var errorHandler: ErrorHandlingService
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        Form {
            // 表單內容...
            
            Button(action: saveBaby) {
                if viewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle())
                } else {
                    Text("保存")
                        .frame(maxWidth: .infinity)
                        .foregroundColor(.white)
                }
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.blue)
            .cornerRadius(10)
            .disabled(viewModel.isLoading)
        }
        .navigationTitle(viewModel.name.isEmpty ? "新增寶寶" : "編輯寶寶")
        .handleErrors(with: errorHandler)
    }
    
    private func saveBaby() {
        viewModel.saveBaby {
            presentationMode.wrappedValue.dismiss()
        }
    }
}

// SleepRecordEditView.swift

struct SleepRecordEditView: View {
    @ObservedObject var viewModel: SleepRecordViewModel
    @EnvironmentObject var errorHandler: ErrorHandlingService
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        Form {
            // 表單內容...
            
            Button(action: saveSleepRecord) {
                if viewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle())
                } else {
                    Text("保存")
                        .frame(maxWidth: .infinity)
                        .foregroundColor(.white)
                }
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.blue)
            .cornerRadius(10)
            .disabled(viewModel.isLoading)
        }
        .navigationTitle("睡眠記錄")
        .handleErrors(with: errorHandler)
    }
    
    private func saveSleepRecord() {
        viewModel.saveSleepRecord {
            presentationMode.wrappedValue.dismiss()
        }
    }
}

// 其他UI視圖類似修改...
```

## 4. 測試計劃

為確保實體轉換方法的正確實現，需要進行以下測試：

1. **單元測試**：測試每個ViewModel的toEntity方法
2. **集成測試**：測試ViewModel與Repository和UseCase的交互
3. **UI測試**：測試編輯和保存功能

```swift
// EntityConversionTests.swift

class EntityConversionTests: XCTestCase {
    // 測試BabyViewModel的實體轉換
    func testBabyViewModelConversion() {
        // 創建測試數據
        let baby = Baby(
            id: UUID(),
            name: "Test Baby",
            birthDate: Date(),
            gender: .male,
            avatarUrl: URL(string: "https://example.com/avatar.jpg"),
            notes: "Test notes",
            createdAt: Date(),
            updatedAt: Date()
        )
        
        let mockSaveBabyUseCase = MockSaveBabyUseCase()
        let errorHandler = ErrorHandlingService()
        
        // 創建ViewModel
        let viewModel = BabyViewModel(
            baby: baby,
            saveBabyUseCase: mockSaveBabyUseCase,
            errorHandler: errorHandler
        )
        
        // 修改ViewModel屬性
        viewModel.name = "Updated Name"
        viewModel.notes = "Updated notes"
        
        // 轉換回實體
        let convertedBaby = viewModel.toEntity()
        
        // 驗證轉換結果
        XCTAssertEqual(convertedBaby.id, baby.id)
        XCTAssertEqual(convertedBaby.name, "Updated Name")
        XCTAssertEqual(convertedBaby.birthDate, baby.birthDate)
        XCTAssertEqual(convertedBaby.gender, baby.gender)
        XCTAssertEqual(convertedBaby.avatarUrl, baby.avatarUrl)
        XCTAssertEqual(convertedBaby.notes, "Updated notes")
        XCTAssertEqual(convertedBaby.createdAt, baby.createdAt)
    }
    
    // 測試SleepRecordViewModel的實體轉換
    func testSleepRecordViewModelConversion() {
        // 創建測試數據
        let sleepRecord = SleepRecord(
            id: UUID(),
            babyId: UUID(),
            startTime: Date(),
            endTime: Date().addingTimeInterval(3600),
            quality: 5,
            notes: "Test notes",
            interruptions: [
                SleepInterruption(
                    id: UUID(),
                    sleepRecordId: UUID(),
                    reason: "Test interruption",
                    startTime: Date(),
                    endTime: Date().addingTimeInterval(300)
                )
            ],
            environmentFactors: [
                EnvironmentFactor(
                    id: UUID(),
                    sleepRecordId: UUID(),
                    type: .light,
                    value: 5
                )
            ],
            createdAt: Date(),
            updatedAt: Date()
        )
        
        let mockSaveSleepRecordUseCase = MockSaveSleepRecordUseCase()
        let errorHandler = ErrorHandlingService()
        
        // 創建ViewModel
        let viewModel = SleepRecordViewModel(
            record: sleepRecord,
            saveSleepRecordUseCase: mockSaveSleepRecordUseCase,
            errorHandler: errorHandler
        )
        
        // 修改ViewModel屬性
        viewModel.quality = 4
        viewModel.notes = "Updated notes"
        
        // 添加新的中斷
        viewModel.addInterruption(
            reason: "New interruption",
            startTime: Date(),
            endTime: Date().addingTimeInterval(600)
        )
        
        // 添加新的環境因素
        viewModel.addEnvironmentFactor(type: .noise, value: 7)
        
        // 轉換回實體
        let convertedSleepRecord = viewModel.toEntity()
        
        // 驗證轉換結果
        XCTAssertEqual(convertedSleepRecord.id, sleepRecord.id)
        XCTAssertEqual(convertedSleepRecord.babyId, sleepRecord.babyId)
        XCTAssertEqual(convertedSleepRecord.startTime, sleepRecord.startTime)
        XCTAssertEqual(convertedSleepRecord.endTime, sleepRecord.endTime)
        XCTAssertEqual(convertedSleepRecord.quality, 4)
        XCTAssertEqual(convertedSleepRecord.notes, "Updated notes")
        XCTAssertEqual(convertedSleepRecord.interruptions?.count, 2)
        XCTAssertEqual(convertedSleepRecord.environmentFactors?.count, 2)
        XCTAssertEqual(convertedSleepRecord.createdAt, sleepRecord.createdAt)
    }
    
    // 其他ViewModel的測試...
}

// MockSaveBabyUseCase.swift

class MockSaveBabyUseCase: SaveBabyUseCase {
    var savedBaby: Baby?
    
    init() {
        super.init(babyRepository: MockBabyRepository())
    }
    
    override func execute(baby: Baby, completion: @escaping (Result<Baby, Error>) -> Void) {
        savedBaby = baby
        completion(.success(baby))
    }
}

// MockSaveSleepRecordUseCase.swift

class MockSaveSleepRecordUseCase: SaveSleepRecordUseCase {
    var savedSleepRecord: SleepRecord?
    
    init() {
        super.init(sleepRepository: MockSleepRepository())
    }
    
    override func execute(sleepRecord: SleepRecord, completion: @escaping (Result<SleepRecord, Error>) -> Void) {
        savedSleepRecord = sleepRecord
        completion(.success(sleepRecord))
    }
}

// 其他Mock類...
```

## 5. 總結

通過以上修正，我們解決了部分ViewModel缺少完整的實體轉換方法的問題。具體修正包括：

1. 定義通用的實體轉換協議（EntityConvertible）
2. 為所有ViewModel添加實體轉換方法（toEntity）
3. 確保所有UseCase正確使用實體
4. 更新UI實現，使用ViewModel的toEntity方法

這些修正確保了數據流的完整性，使視圖層數據能正確回寫到數據層。用戶現在可以編輯和保存各種記錄，而不會丟失數據或產生不一致。

完整的實體轉換方法為第三階段的AI分析功能奠定了堅實的基礎，因為AI分析需要基於完整的用戶修改數據才能產生準確的結果和建議。例如，AI可以分析用戶修改後的睡眠記錄，識別睡眠模式的變化，並提供更準確的建議。
