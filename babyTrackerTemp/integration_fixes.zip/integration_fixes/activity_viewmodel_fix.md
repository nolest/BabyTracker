# 寶寶生活記錄專業版（Baby Tracker）- 完善ActivityViewModel

## 1. 問題描述

在第一階段與第二階段整合性驗證中，發現第二階段的ActivityViewModel未完全映射第一階段定義的Activity實體的所有屬性，主要關注了睡眠相關活動，而忽略了其他類型的活動。這種不完整的映射會導致以下問題：

1. 無法完整展示和管理所有類型的活動
2. 數據模型與視圖模型之間存在不一致性
3. 第三階段AI分析功能可能無法獲取完整的活動數據
4. 用戶體驗受限，無法記錄和查看所有類型的活動

## 2. 修正方案

### 2.1 回顧Activity實體定義

首先，回顧第一階段定義的Activity實體：

```swift
// Activity.swift

enum ActivityType: String, Codable, CaseIterable {
    case sleep = "sleep"
    case feeding = "feeding"
    case diaper = "diaper"
    case bath = "bath"
    case play = "play"
    case medicine = "medicine"
    case growth = "growth"
    case milestone = "milestone"
    case other = "other"
}

struct Activity: Identifiable {
    let id: UUID
    let babyId: UUID
    let type: ActivityType
    let startTime: Date
    let endTime: Date?
    let duration: TimeInterval?
    let value: Double?
    let unit: String?
    let notes: String
    let createdAt: Date
    let updatedAt: Date
}
```

### 2.2 完善ActivityViewModel

接下來，完善ActivityViewModel，確保完全映射Activity實體的所有屬性：

```swift
// ActivityViewModel.swift

class ActivityViewModel: ObservableObject, Identifiable {
    let id: UUID
    let babyId: UUID
    @Published var type: ActivityType
    @Published var startTime: Date
    @Published var endTime: Date?
    @Published var duration: TimeInterval?
    @Published var value: Double?
    @Published var unit: String?
    @Published var notes: String
    let createdAt: Date
    let updatedAt: Date
    
    @Published var isLoading: Bool = false
    
    private let saveActivityUseCase: SaveActivityUseCase
    private let errorHandler: ErrorHandlingService
    
    // 初始化方法 - 從實體創建
    init(activity: Activity, saveActivityUseCase: SaveActivityUseCase, errorHandler: ErrorHandlingService) {
        self.id = activity.id
        self.babyId = activity.babyId
        self.type = activity.type
        self.startTime = activity.startTime
        self.endTime = activity.endTime
        self.duration = activity.duration
        self.value = activity.value
        self.unit = activity.unit
        self.notes = activity.notes
        self.createdAt = activity.createdAt
        self.updatedAt = activity.updatedAt
        self.saveActivityUseCase = saveActivityUseCase
        self.errorHandler = errorHandler
    }
    
    // 初始化方法 - 創建新活動
    init(id: UUID = UUID(),
         babyId: UUID,
         type: ActivityType = .sleep,
         startTime: Date = Date(),
         endTime: Date? = nil,
         duration: TimeInterval? = nil,
         value: Double? = nil,
         unit: String? = nil,
         notes: String = "",
         saveActivityUseCase: SaveActivityUseCase,
         errorHandler: ErrorHandlingService) {
        self.id = id
        self.babyId = babyId
        self.type = type
        self.startTime = startTime
        self.endTime = endTime
        self.duration = duration
        self.value = value
        self.unit = unit
        self.notes = notes
        self.createdAt = Date()
        self.updatedAt = Date()
        self.saveActivityUseCase = saveActivityUseCase
        self.errorHandler = errorHandler
    }
    
    // 保存活動
    func saveActivity(completion: @escaping () -> Void) {
        isLoading = true
        
        // 計算持續時間（如果有結束時間）
        let calculatedDuration: TimeInterval?
        if let endTime = endTime {
            calculatedDuration = endTime.timeIntervalSince(startTime)
        } else {
            calculatedDuration = duration
        }
        
        let activity = Activity(
            id: id,
            babyId: babyId,
            type: type,
            startTime: startTime,
            endTime: endTime,
            duration: calculatedDuration,
            value: value,
            unit: unit,
            notes: notes,
            createdAt: createdAt,
            updatedAt: Date()
        )
        
        saveActivityUseCase.execute(activity: activity) { [weak self] result in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isLoading = false
                
                self.errorHandler.handleResult(result) { _ in
                    completion()
                }
            }
        }
    }
    
    // 開始計時活動
    func startActivity() {
        startTime = Date()
        endTime = nil
        duration = nil
    }
    
    // 結束計時活動
    func endActivity() {
        endTime = Date()
        if let end = endTime {
            duration = end.timeIntervalSince(startTime)
        }
    }
    
    // 獲取格式化的持續時間
    var formattedDuration: String {
        guard let duration = self.duration ?? (endTime?.timeIntervalSince(startTime)) else {
            return "未完成"
        }
        
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60
        let seconds = Int(duration) % 60
        
        if hours > 0 {
            return String(format: "%d小時%02d分鐘", hours, minutes)
        } else if minutes > 0 {
            return String(format: "%d分鐘%02d秒", minutes, seconds)
        } else {
            return String(format: "%d秒", seconds)
        }
    }
    
    // 獲取活動類型的本地化名稱
    var typeLocalizedName: String {
        switch type {
        case .sleep:
            return "睡眠"
        case .feeding:
            return "餵食"
        case .diaper:
            return "換尿布"
        case .bath:
            return "洗澡"
        case .play:
            return "玩耍"
        case .medicine:
            return "用藥"
        case .growth:
            return "成長記錄"
        case .milestone:
            return "里程碑"
        case .other:
            return "其他"
        }
    }
    
    // 獲取活動類型的圖標名稱
    var typeIconName: String {
        switch type {
        case .sleep:
            return "moon.zzz"
        case .feeding:
            return "bottle"
        case .diaper:
            return "heart.text.square"
        case .bath:
            return "drop"
        case .play:
            return "gamecontroller"
        case .medicine:
            return "pills"
        case .growth:
            return "ruler"
        case .milestone:
            return "flag"
        case .other:
            return "square.and.pencil"
        }
    }
    
    // 獲取活動類型的顏色
    var typeColor: Color {
        switch type {
        case .sleep:
            return Color.blue
        case .feeding:
            return Color.green
        case .diaper:
            return Color.yellow
        case .bath:
            return Color.cyan
        case .play:
            return Color.orange
        case .medicine:
            return Color.red
        case .growth:
            return Color.purple
        case .milestone:
            return Color.pink
        case .other:
            return Color.gray
        }
    }
    
    // 將ViewModel轉換為領域實體
    func toDomain() -> Activity {
        return Activity(
            id: id,
            babyId: babyId,
            type: type,
            startTime: startTime,
            endTime: endTime,
            duration: duration ?? (endTime?.timeIntervalSince(startTime)),
            value: value,
            unit: unit,
            notes: notes,
            createdAt: createdAt,
            updatedAt: Date()
        )
    }
}
```

### 2.3 實現ActivityListViewModel

為了管理活動列表，實現ActivityListViewModel：

```swift
// ActivityListViewModel.swift

class ActivityListViewModel: ObservableObject {
    @Published var activities: [ActivityViewModel] = []
    @Published var isLoading: Bool = false
    @Published var selectedType: ActivityType?
    
    private let getActivitiesUseCase: GetActivitiesUseCase
    private let saveActivityUseCase: SaveActivityUseCase
    private let deleteActivityUseCase: DeleteActivityUseCase
    private let errorHandler: ErrorHandlingService
    
    init(getActivitiesUseCase: GetActivitiesUseCase,
         saveActivityUseCase: SaveActivityUseCase,
         deleteActivityUseCase: DeleteActivityUseCase,
         errorHandler: ErrorHandlingService) {
        self.getActivitiesUseCase = getActivitiesUseCase
        self.saveActivityUseCase = saveActivityUseCase
        self.deleteActivityUseCase = deleteActivityUseCase
        self.errorHandler = errorHandler
    }
    
    // 加載活動列表
    func loadActivities(babyId: UUID, type: ActivityType? = nil) {
        isLoading = true
        selectedType = type
        
        getActivitiesUseCase.execute(babyId: babyId, type: type) { [weak self] result in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isLoading = false
                
                self.errorHandler.handleResult(result) { activities in
                    self.activities = activities.map { activity in
                        ActivityViewModel(
                            activity: activity,
                            saveActivityUseCase: self.saveActivityUseCase,
                            errorHandler: self.errorHandler
                        )
                    }
                }
            }
        }
    }
    
    // 刪除活動
    func deleteActivity(id: UUID) {
        isLoading = true
        
        deleteActivityUseCase.execute(activityId: id) { [weak self] result in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isLoading = false
                
                self.errorHandler.handleResult(result) { _ in
                    // 從列表中移除已刪除的活動
                    self.activities.removeAll { $0.id == id }
                }
            }
        }
    }
    
    // 創建新活動ViewModel
    func createActivityViewModel(babyId: UUID, type: ActivityType) -> ActivityViewModel {
        return ActivityViewModel(
            babyId: babyId,
            type: type,
            saveActivityUseCase: saveActivityUseCase,
            errorHandler: errorHandler
        )
    }
    
    // 按日期分組的活動
    var activitiesByDate: [Date: [ActivityViewModel]] {
        let calendar = Calendar.current
        
        return Dictionary(grouping: activities) { activity in
            calendar.startOfDay(for: activity.startTime)
        }
    }
    
    // 排序後的日期
    var sortedDates: [Date] {
        return activitiesByDate.keys.sorted(by: >)
    }
}
```

### 2.4 實現ActivityRepository接口和實現

確保ActivityRepository接口完整，並實現所有方法：

```swift
// ActivityRepository.swift

protocol ActivityRepository {
    func getActivities(babyId: UUID, type: ActivityType?, completion: @escaping (Result<[Activity], Error>) -> Void)
    func getActivity(id: UUID, completion: @escaping (Result<Activity, Error>) -> Void)
    func saveActivity(activity: Activity, completion: @escaping (Result<Activity, Error>) -> Void)
    func deleteActivity(id: UUID, completion: @escaping (Result<Void, Error>) -> Void)
}

// ActivityRepositoryImpl.swift

class ActivityRepositoryImpl: ActivityRepository {
    private let coreDataManager: CoreDataManager
    
    init(coreDataManager: CoreDataManager) {
        self.coreDataManager = coreDataManager
    }
    
    func getActivities(babyId: UUID, type: ActivityType?, completion: @escaping (Result<[Activity], Error>) -> Void) {
        let context = coreDataManager.persistentContainer.viewContext
        
        let fetchRequest: NSFetchRequest<ActivityEntity> = ActivityEntity.fetchRequest()
        
        // 構建查詢條件
        var predicates: [NSPredicate] = [NSPredicate(format: "babyId == %@", babyId as CVarArg)]
        
        if let type = type {
            predicates.append(NSPredicate(format: "type == %@", type.rawValue))
        }
        
        fetchRequest.predicate = NSCompoundPredicate(andPredicateWithSubpredicates: predicates)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "startTime", ascending: false)]
        
        do {
            let activityEntities = try context.fetch(fetchRequest)
            let activities = activityEntities.map { $0.toDomain() }
            completion(.success(activities))
        } catch {
            let appError = AppError.dataError("無法獲取活動列表：\(error.localizedDescription)")
            completion(.failure(appError))
        }
    }
    
    func getActivity(id: UUID, completion: @escaping (Result<Activity, Error>) -> Void) {
        let context = coreDataManager.persistentContainer.viewContext
        
        let fetchRequest: NSFetchRequest<ActivityEntity> = ActivityEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        
        do {
            let results = try context.fetch(fetchRequest)
            
            if let activityEntity = results.first {
                let activity = activityEntity.toDomain()
                completion(.success(activity))
            } else {
                let appError = AppError.entityNotFound("找不到ID為\(id)的活動")
                completion(.failure(appError))
            }
        } catch {
            let appError = AppError.dataError("獲取活動時出錯：\(error.localizedDescription)")
            completion(.failure(appError))
        }
    }
    
    func saveActivity(activity: Activity, completion: @escaping (Result<Activity, Error>) -> Void) {
        let context = coreDataManager.persistentContainer.viewContext
        
        // 檢查是否存在相同ID的實體
        let fetchRequest: NSFetchRequest<ActivityEntity> = ActivityEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", activity.id as CVarArg)
        
        do {
            let results = try context.fetch(fetchRequest)
            let activityEntity: ActivityEntity
            
            if let existingEntity = results.first {
                // 更新現有實體
                activityEntity = existingEntity
            } else {
                // 創建新實體
                activityEntity = ActivityEntity(context: context)
                activityEntity.id = activity.id
                activityEntity.createdAt = activity.createdAt
            }
            
            // 設置實體屬性
            activityEntity.babyId = activity.babyId
            activityEntity.type = activity.type.rawValue
            activityEntity.startTime = activity.startTime
            activityEntity.endTime = activity.endTime
            activityEntity.duration = activity.duration ?? 0
            activityEntity.value = activity.value ?? 0
            activityEntity.unit = activity.unit
            activityEntity.notes = activity.notes
            activityEntity.updatedAt = Date()
            
            try context.save()
            
            let savedActivity = activityEntity.toDomain()
            completion(.success(savedActivity))
        } catch {
            let appError = AppError.dataError("保存活動時出錯：\(error.localizedDescription)")
            completion(.failure(appError))
        }
    }
    
    func deleteActivity(id: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
        let context = coreDataManager.persistentContainer.viewContext
        
        let fetchRequest: NSFetchRequest<ActivityEntity> = ActivityEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        
        do {
            let results = try context.fetch(fetchRequest)
            
            if let activityEntity = results.first {
                context.delete(activityEntity)
                try context.save()
                completion(.success(()))
            } else {
                let appError = AppError.entityNotFound("找不到ID為\(id)的活動")
                completion(.failure(appError))
            }
        } catch {
            let appError = AppError.dataError("刪除活動時出錯：\(error.localizedDescription)")
            completion(.failure(appError))
        }
    }
}

// ActivityEntity+Extension.swift

extension ActivityEntity {
    func toDomain() -> Activity {
        return Activity(
            id: id ?? UUID(),
            babyId: babyId ?? UUID(),
            type: ActivityType(rawValue: type ?? "") ?? .other,
            startTime: startTime ?? Date(),
            endTime: endTime,
            duration: duration > 0 ? duration : nil,
            value: value != 0 ? value : nil,
            unit: unit,
            notes: notes ?? "",
            createdAt: createdAt ?? Date(),
            updatedAt: updatedAt ?? Date()
        )
    }
}
```

### 2.5 實現ActivityUseCase

實現所有必要的ActivityUseCase：

```swift
// GetActivitiesUseCase.swift

class GetActivitiesUseCase {
    private let activityRepository: ActivityRepository
    
    init(activityRepository: ActivityRepository) {
        self.activityRepository = activityRepository
    }
    
    func execute(babyId: UUID, type: ActivityType? = nil, completion: @escaping (Result<[Activity], Error>) -> Void) {
        activityRepository.getActivities(babyId: babyId, type: type, completion: completion)
    }
}

// GetActivityUseCase.swift

class GetActivityUseCase {
    private let activityRepository: ActivityRepository
    
    init(activityRepository: ActivityRepository) {
        self.activityRepository = activityRepository
    }
    
    func execute(activityId: UUID, completion: @escaping (Result<Activity, Error>) -> Void) {
        activityRepository.getActivity(id: activityId, completion: completion)
    }
}

// SaveActivityUseCase.swift

class SaveActivityUseCase {
    private let activityRepository: ActivityRepository
    
    init(activityRepository: ActivityRepository) {
        self.activityRepository = activityRepository
    }
    
    func execute(activity: Activity, completion: @escaping (Result<Activity, Error>) -> Void) {
        activityRepository.saveActivity(activity: activity, completion: completion)
    }
}

// DeleteActivityUseCase.swift

class DeleteActivityUseCase {
    private let activityRepository: ActivityRepository
    
    init(activityRepository: ActivityRepository) {
        self.activityRepository = activityRepository
    }
    
    func execute(activityId: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
        activityRepository.deleteActivity(id: activityId, completion: completion)
    }
}
```

### 2.6 實現ActivityView

實現活動記錄和查看的UI：

```swift
// ActivityListView.swift

struct ActivityListView: View {
    @ObservedObject var viewModel: ActivityListViewModel
    @EnvironmentObject var errorHandler: ErrorHandlingService
    let babyId: UUID
    @State private var showingNewActivitySheet = false
    @State private var selectedActivityType: ActivityType = .sleep
    
    var body: some View {
        ZStack {
            if viewModel.isLoading && viewModel.activities.isEmpty {
                ProgressView("載入中...")
            } else if viewModel.activities.isEmpty {
                VStack(spacing: 16) {
                    Image(systemName: "doc.text")
                        .font(.system(size: 60))
                        .foregroundColor(.gray)
                    
                    Text("沒有活動記錄")
                        .font(.headline)
                        .foregroundColor(.gray)
                    
                    Button(action: {
                        showingNewActivitySheet = true
                    }) {
                        Text("添加活動")
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                }
            } else {
                List {
                    ForEach(viewModel.sortedDates, id: \.self) { date in
                        Section(header: Text(formatDate(date))) {
                            ForEach(viewModel.activitiesByDate[date] ?? []) { activityVM in
                                NavigationLink(destination: ActivityDetailView(viewModel: activityVM)) {
                                    ActivityRow(activity: activityVM)
                                }
                            }
                            .onDelete { indexSet in
                                deleteActivities(at: indexSet, for: date)
                            }
                        }
                    }
                }
                .listStyle(InsetGroupedListStyle())
                .refreshable {
                    viewModel.loadActivities(babyId: babyId, type: viewModel.selectedType)
                }
            }
        }
        .navigationTitle("活動記錄")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {
                    showingNewActivitySheet = true
                }) {
                    Image(systemName: "plus")
                }
            }
            
            ToolbarItem(placement: .navigationBarLeading) {
                Menu {
                    Button(action: {
                        viewModel.loadActivities(babyId: babyId)
                    }) {
                        Label("全部", systemImage: "list.bullet")
                    }
                    
                    Divider()
                    
                    ForEach(ActivityType.allCases, id: \.self) { type in
                        Button(action: {
                            viewModel.loadActivities(babyId: babyId, type: type)
                        }) {
                            Label(localizedActivityType(type), systemImage: iconForActivityType(type))
                        }
                    }
                } label: {
                    Image(systemName: "line.3.horizontal.decrease.circle")
                }
            }
        }
        .sheet(isPresented: $showingNewActivitySheet) {
            NavigationView {
                ActivityEditView(
                    viewModel: viewModel.createActivityViewModel(babyId: babyId, type: selectedActivityType),
                    isNewActivity: true
                )
                .navigationTitle("新增活動")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("取消") {
                            showingNewActivitySheet = false
                        }
                    }
                }
            }
        }
        .onAppear {
            viewModel.loadActivities(babyId: babyId)
        }
        .handleErrors(with: errorHandler)
    }
    
    private func deleteActivities(at offsets: IndexSet, for date: Date) {
        guard let activitiesForDate = viewModel.activitiesByDate[date] else { return }
        
        for index in offsets {
            let activity = activitiesForDate[index]
            viewModel.deleteActivity(id: activity.id)
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日"
        return formatter.string(from: date)
    }
    
    private func localizedActivityType(_ type: ActivityType) -> String {
        switch type {
        case .sleep: return "睡眠"
        case .feeding: return "餵食"
        case .diaper: return "換尿布"
        case .bath: return "洗澡"
        case .play: return "玩耍"
        case .medicine: return "用藥"
        case .growth: return "成長記錄"
        case .milestone: return "里程碑"
        case .other: return "其他"
        }
    }
    
    private func iconForActivityType(_ type: ActivityType) -> String {
        switch type {
        case .sleep: return "moon.zzz"
        case .feeding: return "bottle"
        case .diaper: return "heart.text.square"
        case .bath: return "drop"
        case .play: return "gamecontroller"
        case .medicine: return "pills"
        case .growth: return "ruler"
        case .milestone: return "flag"
        case .other: return "square.and.pencil"
        }
    }
}

// ActivityRow.swift

struct ActivityRow: View {
    let activity: ActivityViewModel
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: activity.typeIconName)
                .font(.system(size: 24))
                .foregroundColor(activity.typeColor)
                .frame(width: 40, height: 40)
                .background(activity.typeColor.opacity(0.1))
                .cornerRadius(8)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(activity.typeLocalizedName)
                    .font(.headline)
                
                HStack {
                    Text(formatTime(activity.startTime))
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    if activity.endTime != nil {
                        Text(" - ")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        Text(formatTime(activity.endTime!))
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                
                if !activity.notes.isEmpty {
                    Text(activity.notes)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
            }
            
            Spacer()
            
            if let value = activity.value, let unit = activity.unit {
                Text("\(String(format: "%.1f", value))\(unit)")
                    .font(.headline)
                    .foregroundColor(activity.typeColor)
            } else if activity.duration != nil || activity.endTime != nil {
                Text(activity.formattedDuration)
                    .font(.headline)
                    .foregroundColor(activity.typeColor)
            }
        }
        .padding(.vertical, 8)
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
}

// ActivityDetailView.swift

struct ActivityDetailView: View {
    @ObservedObject var viewModel: ActivityViewModel
    @EnvironmentObject var errorHandler: ErrorHandlingService
    @State private var showingEditSheet = false
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // 活動類型和時間
                HStack {
                    Image(systemName: viewModel.typeIconName)
                        .font(.system(size: 30))
                        .foregroundColor(.white)
                        .frame(width: 60, height: 60)
                        .background(viewModel.typeColor)
                        .cornerRadius(12)
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text(viewModel.typeLocalizedName)
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        Text(formatDateTime(viewModel.startTime))
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                }
                .padding()
                .background(Color(UIColor.secondarySystemBackground))
                .cornerRadius(12)
                
                // 持續時間
                if viewModel.duration != nil || viewModel.endTime != nil {
                    DetailRow(title: "持續時間", value: viewModel.formattedDuration)
                }
                
                // 結束時間
                if let endTime = viewModel.endTime {
                    DetailRow(title: "結束時間", value: formatDateTime(endTime))
                }
                
                // 數值和單位
                if let value = viewModel.value, let unit = viewModel.unit {
                    DetailRow(title: "數值", value: "\(String(format: "%.1f", value))\(unit)")
                }
                
                // 備註
                if !viewModel.notes.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("備註")
                            .font(.headline)
                            .foregroundColor(.secondary)
                        
                        Text(viewModel.notes)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(UIColor.secondarySystemBackground))
                            .cornerRadius(8)
                    }
                    .padding(.horizontal)
                }
                
                Spacer()
            }
            .padding()
        }
        .navigationTitle("活動詳情")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {
                    showingEditSheet = true
                }) {
                    Text("編輯")
                }
            }
        }
        .sheet(isPresented: $showingEditSheet) {
            NavigationView {
                ActivityEditView(viewModel: viewModel, isNewActivity: false)
                    .navigationTitle("編輯活動")
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) {
                            Button("取消") {
                                showingEditSheet = false
                            }
                        }
                    }
            }
        }
        .handleErrors(with: errorHandler)
    }
    
    private func formatDateTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm"
        return formatter.string(from: date)
    }
}

struct DetailRow: View {
    let title: String
    let value: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)
                .foregroundColor(.secondary)
            
            Text(value)
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color(UIColor.secondarySystemBackground))
                .cornerRadius(8)
        }
        .padding(.horizontal)
    }
}

// ActivityEditView.swift

struct ActivityEditView: View {
    @ObservedObject var viewModel: ActivityViewModel
    @EnvironmentObject var errorHandler: ErrorHandlingService
    @Environment(\.presentationMode) var presentationMode
    let isNewActivity: Bool
    
    @State private var showingTypeSelector = false
    @State private var showingStartTimePicker = false
    @State private var showingEndTimePicker = false
    
    var body: some View {
        Form {
            // 活動類型
            Section(header: Text("活動類型")) {
                HStack {
                    Image(systemName: viewModel.typeIconName)
                        .foregroundColor(viewModel.typeColor)
                    
                    Text(viewModel.typeLocalizedName)
                    
                    Spacer()
                    
                    Button(action: {
                        showingTypeSelector = true
                    }) {
                        Text("更改")
                            .foregroundColor(.blue)
                    }
                }
            }
            
            // 時間
            Section(header: Text("時間")) {
                HStack {
                    Text("開始時間")
                    Spacer()
                    Text(formatDateTime(viewModel.startTime))
                        .foregroundColor(.secondary)
                    Button(action: {
                        showingStartTimePicker = true
                    }) {
                        Image(systemName: "clock")
                            .foregroundColor(.blue)
                    }
                }
                
                HStack {
                    Text("結束時間")
                    Spacer()
                    if let endTime = viewModel.endTime {
                        Text(formatDateTime(endTime))
                            .foregroundColor(.secondary)
                    } else {
                        Text("未結束")
                            .foregroundColor(.secondary)
                    }
                    Button(action: {
                        if viewModel.endTime == nil {
                            viewModel.endActivity()
                        } else {
                            showingEndTimePicker = true
                        }
                    }) {
                        Image(systemName: viewModel.endTime == nil ? "stop.circle" : "clock")
                            .foregroundColor(.blue)
                    }
                }
                
                if viewModel.duration != nil || viewModel.endTime != nil {
                    HStack {
                        Text("持續時間")
                        Spacer()
                        Text(viewModel.formattedDuration)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            // 數值和單位
            Section(header: Text("數值 (可選)")) {
                HStack {
                    TextField("數值", value: $viewModel.value, format: .number)
                        .keyboardType(.decimalPad)
                    
                    TextField("單位", text: Binding(
                        get: { viewModel.unit ?? "" },
                        set: { viewModel.unit = $0.isEmpty ? nil : $0 }
                    ))
                }
            }
            
            // 備註
            Section(header: Text("備註 (可選)")) {
                TextEditor(text: $viewModel.notes)
                    .frame(minHeight: 100)
            }
            
            // 保存按鈕
            Section {
                Button(action: saveActivity) {
                    if viewModel.isLoading {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle())
                    } else {
                        Text("保存")
                            .frame(maxWidth: .infinity)
                            .foregroundColor(.white)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.blue)
                .cornerRadius(10)
                .disabled(viewModel.isLoading)
            }
        }
        .sheet(isPresented: $showingTypeSelector) {
            ActivityTypeSelector(selectedType: $viewModel.type)
        }
        .sheet(isPresented: $showingStartTimePicker) {
            DatePickerSheet(selectedDate: $viewModel.startTime, title: "選擇開始時間")
        }
        .sheet(isPresented: $showingEndTimePicker) {
            DatePickerSheet(selectedDate: Binding(
                get: { viewModel.endTime ?? Date() },
                set: { viewModel.endTime = $0 }
            ), title: "選擇結束時間")
        }
        .handleErrors(with: errorHandler)
    }
    
    private func saveActivity() {
        viewModel.saveActivity {
            presentationMode.wrappedValue.dismiss()
        }
    }
    
    private func formatDateTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日 HH:mm"
        return formatter.string(from: date)
    }
}

// ActivityTypeSelector.swift

struct ActivityTypeSelector: View {
    @Binding var selectedType: ActivityType
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            List {
                ForEach(ActivityType.allCases, id: \.self) { type in
                    Button(action: {
                        selectedType = type
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack {
                            Image(systemName: iconForActivityType(type))
                                .foregroundColor(colorForActivityType(type))
                                .frame(width: 30)
                            
                            Text(localizedActivityType(type))
                            
                            Spacer()
                            
                            if type == selectedType {
                                Image(systemName: "checkmark")
                                    .foregroundColor(.blue)
                            }
                        }
                    }
                    .foregroundColor(.primary)
                }
            }
            .navigationTitle("選擇活動類型")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("取消") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        }
    }
    
    private func localizedActivityType(_ type: ActivityType) -> String {
        switch type {
        case .sleep: return "睡眠"
        case .feeding: return "餵食"
        case .diaper: return "換尿布"
        case .bath: return "洗澡"
        case .play: return "玩耍"
        case .medicine: return "用藥"
        case .growth: return "成長記錄"
        case .milestone: return "里程碑"
        case .other: return "其他"
        }
    }
    
    private func iconForActivityType(_ type: ActivityType) -> String {
        switch type {
        case .sleep: return "moon.zzz"
        case .feeding: return "bottle"
        case .diaper: return "heart.text.square"
        case .bath: return "drop"
        case .play: return "gamecontroller"
        case .medicine: return "pills"
        case .growth: return "ruler"
        case .milestone: return "flag"
        case .other: return "square.and.pencil"
        }
    }
    
    private func colorForActivityType(_ type: ActivityType) -> Color {
        switch type {
        case .sleep: return Color.blue
        case .feeding: return Color.green
        case .diaper: return Color.yellow
        case .bath: return Color.cyan
        case .play: return Color.orange
        case .medicine: return Color.red
        case .growth: return Color.purple
        case .milestone: return Color.pink
        case .other: return Color.gray
        }
    }
}

// DatePickerSheet.swift

struct DatePickerSheet: View {
    @Binding var selectedDate: Date
    let title: String
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            VStack {
                DatePicker(
                    "",
                    selection: $selectedDate,
                    displayedComponents: [.date, .hourAndMinute]
                )
                .datePickerStyle(WheelDatePickerStyle())
                .labelsHidden()
                .padding()
                
                Spacer()
            }
            .navigationTitle(title)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("確定") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        }
    }
}
```

### 2.7 更新依賴注入

更新依賴注入容器，添加Activity相關的依賴：

```swift
// DependencyContainer.swift

class DependencyContainer {
    // 單例模式
    static let shared = DependencyContainer()
    
    // 核心服務
    private let coreDataManager = CoreDataManager.shared
    let errorHandler = ErrorHandlingService()
    
    // Repositories
    lazy var babyRepository: BabyRepository = {
        return BabyRepositoryImpl(coreDataManager: coreDataManager)
    }()
    
    lazy var sleepRepository: SleepRepository = {
        return SleepRepositoryImpl(coreDataManager: coreDataManager)
    }()
    
    lazy var activityRepository: ActivityRepository = {
        return ActivityRepositoryImpl(coreDataManager: coreDataManager)
    }()
    
    // 其他Repository...
    
    // UseCases
    lazy var getActivitiesUseCase: GetActivitiesUseCase = {
        return GetActivitiesUseCase(activityRepository: activityRepository)
    }()
    
    lazy var getActivityUseCase: GetActivityUseCase = {
        return GetActivityUseCase(activityRepository: activityRepository)
    }()
    
    lazy var saveActivityUseCase: SaveActivityUseCase = {
        return SaveActivityUseCase(activityRepository: activityRepository)
    }()
    
    lazy var deleteActivityUseCase: DeleteActivityUseCase = {
        return DeleteActivityUseCase(activityRepository: activityRepository)
    }()
    
    // 其他UseCase...
    
    // ViewModels
    func makeActivityListViewModel() -> ActivityListViewModel {
        return ActivityListViewModel(
            getActivitiesUseCase: getActivitiesUseCase,
            saveActivityUseCase: saveActivityUseCase,
            deleteActivityUseCase: deleteActivityUseCase,
            errorHandler: errorHandler
        )
    }
    
    func makeActivityViewModel(babyId: UUID, type: ActivityType = .sleep) -> ActivityViewModel {
        return ActivityViewModel(
            babyId: babyId,
            type: type,
            saveActivityUseCase: saveActivityUseCase,
            errorHandler: errorHandler
        )
    }
    
    func makeActivityViewModel(activity: Activity) -> ActivityViewModel {
        return ActivityViewModel(
            activity: activity,
            saveActivityUseCase: saveActivityUseCase,
            errorHandler: errorHandler
        )
    }
    
    // 其他ViewModel工廠方法...
}
```

### 2.8 更新主頁面

更新主頁面，添加活動記錄入口：

```swift
// HomeView.swift

struct HomeView: View {
    @ObservedObject var babySelectorViewModel: BabySelectorViewModel
    @ObservedObject var sleepDashboardViewModel: SleepDashboardViewModel
    @EnvironmentObject var errorHandler: ErrorHandlingService
    @EnvironmentObject var dependencyContainer: DependencyContainer
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 寶寶選擇器
                    BabySelectorView(viewModel: babySelectorViewModel)
                        .padding(.horizontal)
                    
                    if let selectedBabyId = babySelectorViewModel.selectedBabyId {
                        // 快速操作按鈕
                        QuickActionButtons(babyId: selectedBabyId)
                            .padding(.horizontal)
                        
                        // 睡眠儀表板
                        SleepDashboardView(viewModel: sleepDashboardViewModel, babyId: selectedBabyId)
                            .padding(.horizontal)
                        
                        // 活動記錄入口
                        NavigationLink(destination: ActivityListView(
                            viewModel: dependencyContainer.makeActivityListViewModel(),
                            babyId: selectedBabyId
                        )) {
                            HStack {
                                Image(systemName: "list.bullet.rectangle")
                                    .font(.system(size: 24))
                                    .foregroundColor(.blue)
                                
                                Text("活動記錄")
                                    .font(.headline)
                                
                                Spacer()
                                
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                            .padding()
                            .background(Color(UIColor.secondarySystemBackground))
                            .cornerRadius(12)
                            .padding(.horizontal)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                .padding(.vertical)
            }
            .navigationTitle("寶寶生活記錄")
            .onAppear {
                if let selectedBabyId = babySelectorViewModel.selectedBabyId {
                    sleepDashboardViewModel.loadRecentSleepRecords(babyId: selectedBabyId)
                }
            }
            .onChange(of: babySelectorViewModel.selectedBabyId) { newValue in
                if let babyId = newValue {
                    sleepDashboardViewModel.loadRecentSleepRecords(babyId: babyId)
                }
            }
            .handleErrors(with: errorHandler)
        }
    }
}

// QuickActionButtons.swift

struct QuickActionButtons: View {
    let babyId: UUID
    @EnvironmentObject var dependencyContainer: DependencyContainer
    @State private var showingSleepSheet = false
    @State private var showingFeedingSheet = false
    @State private var showingDiaperSheet = false
    
    var body: some View {
        HStack(spacing: 12) {
            QuickActionButton(
                title: "睡眠",
                iconName: "moon.zzz",
                color: .blue
            ) {
                showingSleepSheet = true
            }
            
            QuickActionButton(
                title: "餵食",
                iconName: "bottle",
                color: .green
            ) {
                showingFeedingSheet = true
            }
            
            QuickActionButton(
                title: "換尿布",
                iconName: "heart.text.square",
                color: .yellow
            ) {
                showingDiaperSheet = true
            }
        }
        .sheet(isPresented: $showingSleepSheet) {
            NavigationView {
                ActivityEditView(
                    viewModel: dependencyContainer.makeActivityViewModel(babyId: babyId, type: .sleep),
                    isNewActivity: true
                )
                .navigationTitle("記錄睡眠")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("取消") {
                            showingSleepSheet = false
                        }
                    }
                }
            }
        }
        .sheet(isPresented: $showingFeedingSheet) {
            NavigationView {
                ActivityEditView(
                    viewModel: dependencyContainer.makeActivityViewModel(babyId: babyId, type: .feeding),
                    isNewActivity: true
                )
                .navigationTitle("記錄餵食")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("取消") {
                            showingFeedingSheet = false
                        }
                    }
                }
            }
        }
        .sheet(isPresented: $showingDiaperSheet) {
            NavigationView {
                ActivityEditView(
                    viewModel: dependencyContainer.makeActivityViewModel(babyId: babyId, type: .diaper),
                    isNewActivity: true
                )
                .navigationTitle("記錄換尿布")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("取消") {
                            showingDiaperSheet = false
                        }
                    }
                }
            }
        }
    }
}

struct QuickActionButton: View {
    let title: String
    let iconName: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: iconName)
                    .font(.system(size: 24))
                    .foregroundColor(.white)
                    .frame(width: 50, height: 50)
                    .background(color)
                    .cornerRadius(25)
                
                Text(title)
                    .font(.caption)
                    .foregroundColor(.primary)
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(PlainButtonStyle())
    }
}
```

## 3. 具體修正實施

### 3.1 完善ActivityViewModel

首先，完善ActivityViewModel，確保完全映射Activity實體的所有屬性：

```swift
// ActivityViewModel.swift
// 完整實現見2.2節
```

### 3.2 實現ActivityListViewModel

實現ActivityListViewModel，用於管理活動列表：

```swift
// ActivityListViewModel.swift
// 完整實現見2.3節
```

### 3.3 實現ActivityRepository

確保ActivityRepository接口完整，並實現所有方法：

```swift
// ActivityRepository.swift 和 ActivityRepositoryImpl.swift
// 完整實現見2.4節
```

### 3.4 實現ActivityUseCase

實現所有必要的ActivityUseCase：

```swift
// GetActivitiesUseCase.swift, GetActivityUseCase.swift, SaveActivityUseCase.swift, DeleteActivityUseCase.swift
// 完整實現見2.5節
```

### 3.5 實現ActivityView

實現活動記錄和查看的UI：

```swift
// ActivityListView.swift, ActivityRow.swift, ActivityDetailView.swift, ActivityEditView.swift, ActivityTypeSelector.swift, DatePickerSheet.swift
// 完整實現見2.6節
```

### 3.6 更新依賴注入

更新依賴注入容器，添加Activity相關的依賴：

```swift
// DependencyContainer.swift
// 完整實現見2.7節
```

### 3.7 更新主頁面

更新主頁面，添加活動記錄入口：

```swift
// HomeView.swift 和 QuickActionButtons.swift
// 完整實現見2.8節
```

## 4. 測試計劃

為確保ActivityViewModel的完整性，需要進行以下測試：

1. **單元測試**：測試ActivityViewModel的所有屬性和方法
2. **集成測試**：測試ActivityViewModel與Repository和UseCase的交互
3. **UI測試**：測試活動記錄和查看的UI

```swift
// ActivityViewModelTests.swift

class ActivityViewModelTests: XCTestCase {
    var activityRepository: MockActivityRepository!
    var saveActivityUseCase: SaveActivityUseCase!
    var errorHandler: ErrorHandlingService!
    var viewModel: ActivityViewModel!
    
    override func setUp() {
        super.setUp()
        activityRepository = MockActivityRepository()
        saveActivityUseCase = SaveActivityUseCase(activityRepository: activityRepository)
        errorHandler = ErrorHandlingService()
        
        // 創建測試數據
        let activity = Activity(
            id: UUID(),
            babyId: UUID(),
            type: .sleep,
            startTime: Date(),
            endTime: Date().addingTimeInterval(3600),
            duration: 3600,
            value: nil,
            unit: nil,
            notes: "Test notes",
            createdAt: Date(),
            updatedAt: Date()
        )
        
        viewModel = ActivityViewModel(
            activity: activity,
            saveActivityUseCase: saveActivityUseCase,
            errorHandler: errorHandler
        )
    }
    
    // 測試初始化
    func testInitialization() {
        XCTAssertEqual(viewModel.type, .sleep)
        XCTAssertEqual(viewModel.notes, "Test notes")
        XCTAssertNotNil(viewModel.endTime)
        XCTAssertEqual(viewModel.duration, 3600)
    }
    
    // 測試開始活動
    func testStartActivity() {
        let originalStartTime = viewModel.startTime
        
        // 等待一小段時間，確保新的開始時間不同
        sleep(1)
        
        viewModel.startActivity()
        
        XCTAssertNotEqual(viewModel.startTime, originalStartTime)
        XCTAssertNil(viewModel.endTime)
        XCTAssertNil(viewModel.duration)
    }
    
    // 測試結束活動
    func testEndActivity() {
        viewModel.startActivity()
        
        // 等待一小段時間，確保持續時間不為零
        sleep(1)
        
        viewModel.endActivity()
        
        XCTAssertNotNil(viewModel.endTime)
        XCTAssertNotNil(viewModel.duration)
        XCTAssertGreaterThan(viewModel.duration ?? 0, 0)
    }
    
    // 測試格式化持續時間
    func testFormattedDuration() {
        // 測試小時和分鐘
        viewModel.duration = 3661 // 1小時1分鐘1秒
        XCTAssertEqual(viewModel.formattedDuration, "1小時01分鐘")
        
        // 測試分鐘和秒
        viewModel.duration = 61 // 1分鐘1秒
        XCTAssertEqual(viewModel.formattedDuration, "1分鐘01秒")
        
        // 測試只有秒
        viewModel.duration = 30 // 30秒
        XCTAssertEqual(viewModel.formattedDuration, "30秒")
        
        // 測試無持續時間
        viewModel.duration = nil
        viewModel.endTime = nil
        XCTAssertEqual(viewModel.formattedDuration, "未完成")
    }
    
    // 測試保存活動
    func testSaveActivity() {
        let expectation = self.expectation(description: "Save activity")
        
        viewModel.saveActivity {
            expectation.fulfill()
        }
        
        waitForExpectations(timeout: 1, handler: nil)
        
        XCTAssertTrue(activityRepository.saveActivityCalled)
        XCTAssertEqual(activityRepository.savedActivity?.id, viewModel.id)
        XCTAssertEqual(activityRepository.savedActivity?.type, viewModel.type)
        XCTAssertEqual(activityRepository.savedActivity?.notes, viewModel.notes)
    }
    
    // 測試轉換為領域實體
    func testToDomain() {
        let activity = viewModel.toDomain()
        
        XCTAssertEqual(activity.id, viewModel.id)
        XCTAssertEqual(activity.babyId, viewModel.babyId)
        XCTAssertEqual(activity.type, viewModel.type)
        XCTAssertEqual(activity.startTime, viewModel.startTime)
        XCTAssertEqual(activity.endTime, viewModel.endTime)
        XCTAssertEqual(activity.duration, viewModel.duration)
        XCTAssertEqual(activity.notes, viewModel.notes)
    }
}

// MockActivityRepository.swift

class MockActivityRepository: ActivityRepository {
    var activities: [Activity] = []
    var saveActivityCalled = false
    var savedActivity: Activity?
    
    func getActivities(babyId: UUID, type: ActivityType?, completion: @escaping (Result<[Activity], Error>) -> Void) {
        let filteredActivities = activities.filter { activity in
            let babyMatch = activity.babyId == babyId
            let typeMatch = type == nil || activity.type == type
            return babyMatch && typeMatch
        }
        completion(.success(filteredActivities))
    }
    
    func getActivity(id: UUID, completion: @escaping (Result<Activity, Error>) -> Void) {
        if let activity = activities.first(where: { $0.id == id }) {
            completion(.success(activity))
        } else {
            completion(.failure(AppError.entityNotFound("找不到ID為\(id)的活動")))
        }
    }
    
    func saveActivity(activity: Activity, completion: @escaping (Result<Activity, Error>) -> Void) {
        saveActivityCalled = true
        savedActivity = activity
        
        if let index = activities.firstIndex(where: { $0.id == activity.id }) {
            activities[index] = activity
        } else {
            activities.append(activity)
        }
        
        completion(.success(activity))
    }
    
    func deleteActivity(id: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
        if let index = activities.firstIndex(where: { $0.id == id }) {
            activities.remove(at: index)
            completion(.success(()))
        } else {
            completion(.failure(AppError.entityNotFound("找不到ID為\(id)的活動")))
        }
    }
}
```

## 5. 總結

通過以上修正，我們解決了第二階段ActivityViewModel未完全映射第一階段定義的Activity實體的問題。具體修正包括：

1. 完善ActivityViewModel，確保完全映射Activity實體的所有屬性
2. 實現ActivityListViewModel，用於管理活動列表
3. 確保ActivityRepository接口完整，並實現所有方法
4. 實現所有必要的ActivityUseCase
5. 實現活動記錄和查看的UI
6. 更新依賴注入，添加Activity相關的依賴
7. 更新主頁面，添加活動記錄入口

這些修正確保了應用能夠完整展示和管理所有類型的活動，而不僅僅是睡眠相關活動。用戶現在可以記錄和查看各種活動，如餵食、換尿布、洗澡、玩耍、用藥、成長記錄、里程碑等。

完善的ActivityViewModel為第三階段的AI分析功能奠定了堅實的基礎，因為AI分析需要基於完整的活動數據才能產生準確的結果和建議。例如，AI可以分析睡眠與餵食的關係，或者識別活動模式與寶寶情緒的關聯。
