# 寶寶生活記錄專業版（Baby Tracker）- 級聯刪除規則實現

## 1. 問題描述

在第一階段與第二階段整合性驗證中，發現第二階段UI未實現第一階段定義的級聯刪除規則。當刪除Baby或SleepRecord實體時，相關的子實體（如SleepRecord、SleepInterruption、EnvironmentFactor等）沒有被自動刪除，可能導致孤立數據的產生。這種數據不一致性會導致以下問題：

1. 數據庫中存在無效引用，佔用存儲空間
2. 查詢結果可能包含孤立數據，影響數據分析準確性
3. 應用可能嘗試訪問不存在的父實體，導致崩潰
4. 數據完整性受損，影響用戶體驗

## 2. 修正方案

### 2.1 Core Data模型級聯刪除規則

首先，需要在Core Data模型中設置正確的級聯刪除規則：

```swift
// 在CoreDataManager中設置實體關係的級聯刪除規則
func setupCoreDataModel() {
    // 獲取實體描述
    guard let babyEntity = NSEntityDescription.entity(forEntityName: "BabyEntity", in: persistentContainer.viewContext),
          let sleepRecordEntity = NSEntityDescription.entity(forEntityName: "SleepRecordEntity", in: persistentContainer.viewContext),
          let sleepInterruptionEntity = NSEntityDescription.entity(forEntityName: "SleepInterruptionEntity", in: persistentContainer.viewContext),
          let environmentFactorEntity = NSEntityDescription.entity(forEntityName: "EnvironmentFactorEntity", in: persistentContainer.viewContext) else {
        fatalError("Failed to get entity descriptions")
    }
    
    // 設置Baby -> SleepRecord的級聯刪除規則
    if let relationship = babyEntity.relationshipsByName["sleepRecords"] {
        relationship.deleteRule = .cascadeDeleteRule
    }
    
    // 設置SleepRecord -> SleepInterruption的級聯刪除規則
    if let relationship = sleepRecordEntity.relationshipsByName["interruptions"] {
        relationship.deleteRule = .cascadeDeleteRule
    }
    
    // 設置SleepRecord -> EnvironmentFactor的級聯刪除規則
    if let relationship = sleepRecordEntity.relationshipsByName["environmentFactors"] {
        relationship.deleteRule = .cascadeDeleteRule
    }
}
```

### 2.2 Repository層級聯刪除實現

除了Core Data模型級聯刪除外，還需要在Repository層確保級聯刪除的正確實現：

```swift
// BabyRepository實現中的刪除方法
func deleteBaby(id: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
    persistentContainer.performBackgroundTask { context in
        do {
            // 查找要刪除的Baby實體
            let fetchRequest: NSFetchRequest<BabyEntity> = BabyEntity.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "id == %@", id as CVarArg)
            
            let results = try context.fetch(fetchRequest)
            
            if let babyEntity = results.first {
                // Core Data會自動處理級聯刪除
                context.delete(babyEntity)
                try context.save()
                
                DispatchQueue.main.async {
                    completion(.success(()))
                }
            } else {
                DispatchQueue.main.async {
                    completion(.failure(RepositoryError.entityNotFound))
                }
            }
        } catch {
            DispatchQueue.main.async {
                completion(.failure(error))
            }
        }
    }
}

// SleepRepository實現中的刪除方法
func deleteSleepRecord(id: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
    persistentContainer.performBackgroundTask { context in
        do {
            // 查找要刪除的SleepRecord實體
            let fetchRequest: NSFetchRequest<SleepRecordEntity> = SleepRecordEntity.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "id == %@", id as CVarArg)
            
            let results = try context.fetch(fetchRequest)
            
            if let sleepRecordEntity = results.first {
                // Core Data會自動處理級聯刪除
                context.delete(sleepRecordEntity)
                try context.save()
                
                DispatchQueue.main.async {
                    completion(.success(()))
                }
            } else {
                DispatchQueue.main.async {
                    completion(.failure(RepositoryError.entityNotFound))
                }
            }
        } catch {
            DispatchQueue.main.async {
                completion(.failure(error))
            }
        }
    }
}
```

### 2.3 UseCase層級聯刪除實現

在UseCase層，需要確保刪除操作正確傳遞到Repository層：

```swift
// DeleteBabyUseCase
class DeleteBabyUseCase {
    private let babyRepository: BabyRepository
    
    init(babyRepository: BabyRepository) {
        self.babyRepository = babyRepository
    }
    
    func execute(babyId: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
        babyRepository.deleteBaby(id: babyId, completion: completion)
    }
}

// DeleteSleepRecordUseCase
class DeleteSleepRecordUseCase {
    private let sleepRepository: SleepRepository
    
    init(sleepRepository: SleepRepository) {
        self.sleepRepository = sleepRepository
    }
    
    func execute(sleepRecordId: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
        sleepRepository.deleteSleepRecord(id: sleepRecordId, completion: completion)
    }
}
```

### 2.4 ViewModel層級聯刪除使用

在ViewModel層，需要使用上述UseCase進行刪除操作：

```swift
// BabyManagementViewModel
class BabyManagementViewModel: ObservableObject {
    @Published var babies: [BabyViewModel] = []
    @Published var isLoading: Bool = false
    @Published var error: Error?
    
    private let getBabiesUseCase: GetBabiesUseCase
    private let deleteBabyUseCase: DeleteBabyUseCase
    
    init(getBabiesUseCase: GetBabiesUseCase, deleteBabyUseCase: DeleteBabyUseCase) {
        self.getBabiesUseCase = getBabiesUseCase
        self.deleteBabyUseCase = deleteBabyUseCase
        loadBabies()
    }
    
    func loadBabies() {
        isLoading = true
        error = nil
        
        getBabiesUseCase.execute { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                switch result {
                case .success(let babies):
                    self?.babies = babies.map { BabyViewModel(baby: $0) }
                case .failure(let error):
                    self?.error = error
                }
            }
        }
    }
    
    func deleteBaby(id: UUID) {
        isLoading = true
        error = nil
        
        deleteBabyUseCase.execute(babyId: id) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                switch result {
                case .success:
                    // 刪除成功後重新加載寶寶列表
                    self?.loadBabies()
                case .failure(let error):
                    self?.error = error
                }
            }
        }
    }
}

// SleepHistoryViewModel
class SleepHistoryViewModel: ObservableObject {
    @Published var sleepRecords: [SleepRecordViewModel] = []
    @Published var isLoading: Bool = false
    @Published var error: Error?
    
    private let getSleepRecordsUseCase: GetSleepRecordsUseCase
    private let deleteSleepRecordUseCase: DeleteSleepRecordUseCase
    
    init(getSleepRecordsUseCase: GetSleepRecordsUseCase, deleteSleepRecordUseCase: DeleteSleepRecordUseCase) {
        self.getSleepRecordsUseCase = getSleepRecordsUseCase
        self.deleteSleepRecordUseCase = deleteSleepRecordUseCase
    }
    
    func loadSleepRecords(babyId: UUID) {
        isLoading = true
        error = nil
        
        getSleepRecordsUseCase.execute(babyId: babyId) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                switch result {
                case .success(let records):
                    self?.sleepRecords = records.map { SleepRecordViewModel(record: $0) }
                case .failure(let error):
                    self?.error = error
                }
            }
        }
    }
    
    func deleteSleepRecord(id: UUID) {
        isLoading = true
        error = nil
        
        deleteSleepRecordUseCase.execute(sleepRecordId: id) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                switch result {
                case .success:
                    // 從本地列表中移除已刪除的記錄
                    self?.sleepRecords.removeAll { $0.id == id }
                case .failure(let error):
                    self?.error = error
                }
            }
        }
    }
}
```

## 3. 具體修正實施

### 3.1 Core Data模型修正

首先，需要修改Core Data模型文件，設置正確的級聯刪除規則：

```swift
// CoreDataManager.swift

class CoreDataManager {
    static let shared = CoreDataManager()
    
    private init() {
        setupCoreDataModel()
    }
    
    // 懶加載持久化容器
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "BabyTracker")
        container.loadPersistentStores { description, error in
            if let error = error {
                fatalError("Failed to load Core Data stack: \(error)")
            }
        }
        return container
    }()
    
    // 設置Core Data模型關係
    private func setupCoreDataModel() {
        let context = persistentContainer.viewContext
        
        // 獲取實體描述
        guard let babyEntity = NSEntityDescription.entity(forEntityName: "BabyEntity", in: context),
              let sleepRecordEntity = NSEntityDescription.entity(forEntityName: "SleepRecordEntity", in: context),
              let sleepInterruptionEntity = NSEntityDescription.entity(forEntityName: "SleepInterruptionEntity", in: context),
              let environmentFactorEntity = NSEntityDescription.entity(forEntityName: "EnvironmentFactorEntity", in: context),
              let activityEntity = NSEntityDescription.entity(forEntityName: "ActivityEntity", in: context) else {
            fatalError("Failed to get entity descriptions")
        }
        
        // 設置Baby -> SleepRecord的級聯刪除規則
        if let relationship = babyEntity.relationshipsByName["sleepRecords"] {
            relationship.deleteRule = .cascadeDeleteRule
        }
        
        // 設置Baby -> Activity的級聯刪除規則
        if let relationship = babyEntity.relationshipsByName["activities"] {
            relationship.deleteRule = .cascadeDeleteRule
        }
        
        // 設置SleepRecord -> SleepInterruption的級聯刪除規則
        if let relationship = sleepRecordEntity.relationshipsByName["interruptions"] {
            relationship.deleteRule = .cascadeDeleteRule
        }
        
        // 設置SleepRecord -> EnvironmentFactor的級聯刪除規則
        if let relationship = sleepRecordEntity.relationshipsByName["environmentFactors"] {
            relationship.deleteRule = .cascadeDeleteRule
        }
    }
    
    // 保存上下文
    func saveContext() {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}
```

### 3.2 Repository實現修正

接下來，修改Repository實現，確保刪除操作正確執行：

```swift
// BabyRepositoryImpl.swift

class BabyRepositoryImpl: BabyRepository {
    private let coreDataManager: CoreDataManager
    
    init(coreDataManager: CoreDataManager) {
        self.coreDataManager = coreDataManager
    }
    
    // 其他方法...
    
    func deleteBaby(id: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
        let context = coreDataManager.persistentContainer.viewContext
        
        let fetchRequest: NSFetchRequest<BabyEntity> = BabyEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        
        do {
            let results = try context.fetch(fetchRequest)
            
            if let babyEntity = results.first {
                // 刪除Baby實體，Core Data會自動處理級聯刪除
                context.delete(babyEntity)
                try context.save()
                completion(.success(()))
            } else {
                completion(.failure(RepositoryError.entityNotFound))
            }
        } catch {
            completion(.failure(error))
        }
    }
}

// SleepRepositoryImpl.swift

class SleepRepositoryImpl: SleepRepository {
    private let coreDataManager: CoreDataManager
    
    init(coreDataManager: CoreDataManager) {
        self.coreDataManager = coreDataManager
    }
    
    // 其他方法...
    
    func deleteSleepRecord(id: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
        let context = coreDataManager.persistentContainer.viewContext
        
        let fetchRequest: NSFetchRequest<SleepRecordEntity> = SleepRecordEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        
        do {
            let results = try context.fetch(fetchRequest)
            
            if let sleepRecordEntity = results.first {
                // 刪除SleepRecord實體，Core Data會自動處理級聯刪除
                context.delete(sleepRecordEntity)
                try context.save()
                completion(.success(()))
            } else {
                completion(.failure(RepositoryError.entityNotFound))
            }
        } catch {
            completion(.failure(error))
        }
    }
}
```

### 3.3 UseCase實現

實現刪除操作的UseCase：

```swift
// DeleteBabyUseCase.swift

class DeleteBabyUseCase {
    private let babyRepository: BabyRepository
    
    init(babyRepository: BabyRepository) {
        self.babyRepository = babyRepository
    }
    
    func execute(babyId: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
        babyRepository.deleteBaby(id: babyId, completion: completion)
    }
}

// DeleteSleepRecordUseCase.swift

class DeleteSleepRecordUseCase {
    private let sleepRepository: SleepRepository
    
    init(sleepRepository: SleepRepository) {
        self.sleepRepository = sleepRepository
    }
    
    func execute(sleepRecordId: UUID, completion: @escaping (Result<Void, Error>) -> Void) {
        sleepRepository.deleteSleepRecord(id: sleepRecordId, completion: completion)
    }
}
```

### 3.4 ViewModel實現

修改ViewModel，使用刪除UseCase：

```swift
// BabyManagementViewModel.swift

class BabyManagementViewModel: ObservableObject {
    @Published var babies: [BabyViewModel] = []
    @Published var isLoading: Bool = false
    @Published var error: Error?
    
    private let getBabiesUseCase: GetBabiesUseCase
    private let deleteBabyUseCase: DeleteBabyUseCase
    
    init(getBabiesUseCase: GetBabiesUseCase, deleteBabyUseCase: DeleteBabyUseCase) {
        self.getBabiesUseCase = getBabiesUseCase
        self.deleteBabyUseCase = deleteBabyUseCase
        loadBabies()
    }
    
    func loadBabies() {
        isLoading = true
        error = nil
        
        getBabiesUseCase.execute { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                switch result {
                case .success(let babies):
                    self?.babies = babies.map { BabyViewModel(baby: $0) }
                case .failure(let error):
                    self?.error = error
                }
            }
        }
    }
    
    func deleteBaby(id: UUID) {
        isLoading = true
        error = nil
        
        deleteBabyUseCase.execute(babyId: id) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                switch result {
                case .success:
                    // 刪除成功後重新加載寶寶列表
                    self?.loadBabies()
                case .failure(let error):
                    self?.error = error
                }
            }
        }
    }
}

// SleepHistoryViewModel.swift

class SleepHistoryViewModel: ObservableObject {
    @Published var sleepRecords: [SleepRecordViewModel] = []
    @Published var isLoading: Bool = false
    @Published var error: Error?
    
    private let getSleepRecordsUseCase: GetSleepRecordsUseCase
    private let deleteSleepRecordUseCase: DeleteSleepRecordUseCase
    
    init(getSleepRecordsUseCase: GetSleepRecordsUseCase, deleteSleepRecordUseCase: DeleteSleepRecordUseCase) {
        self.getSleepRecordsUseCase = getSleepRecordsUseCase
        self.deleteSleepRecordUseCase = deleteSleepRecordUseCase
    }
    
    func loadSleepRecords(babyId: UUID) {
        isLoading = true
        error = nil
        
        getSleepRecordsUseCase.execute(babyId: babyId) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                switch result {
                case .success(let records):
                    self?.sleepRecords = records.map { SleepRecordViewModel(record: $0) }
                case .failure(let error):
                    self?.error = error
                }
            }
        }
    }
    
    func deleteSleepRecord(id: UUID) {
        isLoading = true
        error = nil
        
        deleteSleepRecordUseCase.execute(sleepRecordId: id) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                switch result {
                case .success:
                    // 從本地列表中移除已刪除的記錄
                    self?.sleepRecords.removeAll { $0.id == id }
                case .failure(let error):
                    self?.error = error
                }
            }
        }
    }
}
```

### 3.5 依賴注入更新

更新依賴注入容器，添加新的UseCase：

```swift
// DependencyContainer.swift

class DependencyContainer {
    // 單例模式
    static let shared = DependencyContainer()
    
    // 核心依賴
    private let coreDataManager = CoreDataManager.shared
    
    // Repositories
    lazy var babyRepository: BabyRepository = {
        return BabyRepositoryImpl(coreDataManager: coreDataManager)
    }()
    
    lazy var sleepRepository: SleepRepository = {
        return SleepRepositoryImpl(coreDataManager: coreDataManager)
    }()
    
    // 其他Repository...
    
    // UseCases
    lazy var getBabiesUseCase: GetBabiesUseCase = {
        return GetBabiesUseCase(babyRepository: babyRepository)
    }()
    
    lazy var deleteBabyUseCase: DeleteBabyUseCase = {
        return DeleteBabyUseCase(babyRepository: babyRepository)
    }()
    
    lazy var getSleepRecordsUseCase: GetSleepRecordsUseCase = {
        return GetSleepRecordsUseCase(sleepRepository: sleepRepository)
    }()
    
    lazy var deleteSleepRecordUseCase: DeleteSleepRecordUseCase = {
        return DeleteSleepRecordUseCase(sleepRepository: sleepRepository)
    }()
    
    // 其他UseCase...
    
    // ViewModels
    func makeBabyManagementViewModel() -> BabyManagementViewModel {
        return BabyManagementViewModel(
            getBabiesUseCase: getBabiesUseCase,
            deleteBabyUseCase: deleteBabyUseCase
        )
    }
    
    func makeSleepHistoryViewModel() -> SleepHistoryViewModel {
        return SleepHistoryViewModel(
            getSleepRecordsUseCase: getSleepRecordsUseCase,
            deleteSleepRecordUseCase: deleteSleepRecordUseCase
        )
    }
    
    // 其他ViewModel工廠方法...
}
```

### 3.6 UI實現

最後，在UI層實現刪除功能：

```swift
// BabyManagementView.swift

struct BabyManagementView: View {
    @ObservedObject var viewModel: BabyManagementViewModel
    @State private var showingDeleteAlert = false
    @State private var babyToDelete: UUID?
    
    var body: some View {
        List {
            ForEach(viewModel.babies) { babyVM in
                BabyRow(baby: babyVM)
                    .swipeActions {
                        Button(role: .destructive) {
                            babyToDelete = babyVM.id
                            showingDeleteAlert = true
                        } label: {
                            Label("刪除", systemImage: "trash")
                        }
                    }
            }
        }
        .navigationTitle("寶寶管理")
        .alert("確認刪除", isPresented: $showingDeleteAlert) {
            Button("取消", role: .cancel) {}
            Button("刪除", role: .destructive) {
                if let id = babyToDelete {
                    viewModel.deleteBaby(id: id)
                }
            }
        } message: {
            Text("刪除寶寶將同時刪除所有相關記錄，此操作無法撤銷。")
        }
        .onAppear {
            viewModel.loadBabies()
        }
    }
}

// SleepHistoryView.swift

struct SleepHistoryView: View {
    @ObservedObject var viewModel: SleepHistoryViewModel
    @State private var showingDeleteAlert = false
    @State private var recordToDelete: UUID?
    let babyId: UUID
    
    var body: some View {
        List {
            ForEach(viewModel.sleepRecords) { recordVM in
                SleepRecordRow(record: recordVM)
                    .swipeActions {
                        Button(role: .destructive) {
                            recordToDelete = recordVM.id
                            showingDeleteAlert = true
                        } label: {
                            Label("刪除", systemImage: "trash")
                        }
                    }
            }
        }
        .navigationTitle("睡眠記錄")
        .alert("確認刪除", isPresented: $showingDeleteAlert) {
            Button("取消", role: .cancel) {}
            Button("刪除", role: .destructive) {
                if let id = recordToDelete {
                    viewModel.deleteSleepRecord(id: id)
                }
            }
        } message: {
            Text("刪除睡眠記錄將同時刪除所有相關的中斷和環境因素記錄，此操作無法撤銷。")
        }
        .onAppear {
            viewModel.loadSleepRecords(babyId: babyId)
        }
    }
}
```

## 4. 數據完整性驗證

為確保級聯刪除規則正確實現，需要添加數據完整性驗證機制：

```swift
// DataIntegrityValidator.swift

class DataIntegrityValidator {
    private let coreDataManager: CoreDataManager
    
    init(coreDataManager: CoreDataManager) {
        self.coreDataManager = coreDataManager
    }
    
    // 驗證是否存在孤立的SleepRecord（沒有關聯的Baby）
    func validateSleepRecords(completion: @escaping (Result<Bool, Error>) -> Void) {
        let context = coreDataManager.persistentContainer.viewContext
        
        let fetchRequest: NSFetchRequest<SleepRecordEntity> = SleepRecordEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "baby == nil")
        
        do {
            let orphanedRecords = try context.fetch(fetchRequest)
            let isValid = orphanedRecords.isEmpty
            completion(.success(isValid))
        } catch {
            completion(.failure(error))
        }
    }
    
    // 驗證是否存在孤立的SleepInterruption（沒有關聯的SleepRecord）
    func validateSleepInterruptions(completion: @escaping (Result<Bool, Error>) -> Void) {
        let context = coreDataManager.persistentContainer.viewContext
        
        let fetchRequest: NSFetchRequest<SleepInterruptionEntity> = SleepInterruptionEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "sleepRecord == nil")
        
        do {
            let orphanedInterruptions = try context.fetch(fetchRequest)
            let isValid = orphanedInterruptions.isEmpty
            completion(.success(isValid))
        } catch {
            completion(.failure(error))
        }
    }
    
    // 驗證是否存在孤立的EnvironmentFactor（沒有關聯的SleepRecord）
    func validateEnvironmentFactors(completion: @escaping (Result<Bool, Error>) -> Void) {
        let context = coreDataManager.persistentContainer.viewContext
        
        let fetchRequest: NSFetchRequest<EnvironmentFactorEntity> = EnvironmentFactorEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "sleepRecord == nil")
        
        do {
            let orphanedFactors = try context.fetch(fetchRequest)
            let isValid = orphanedFactors.isEmpty
            completion(.success(isValid))
        } catch {
            completion(.failure(error))
        }
    }
    
    // 驗證是否存在孤立的Activity（沒有關聯的Baby）
    func validateActivities(completion: @escaping (Result<Bool, Error>) -> Void) {
        let context = coreDataManager.persistentContainer.viewContext
        
        let fetchRequest: NSFetchRequest<ActivityEntity> = ActivityEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "baby == nil")
        
        do {
            let orphanedActivities = try context.fetch(fetchRequest)
            let isValid = orphanedActivities.isEmpty
            completion(.success(isValid))
        } catch {
            completion(.failure(error))
        }
    }
    
    // 執行所有驗證
    func validateAllRelationships(completion: @escaping (Result<Bool, Error>) -> Void) {
        var isValid = true
        var validationError: Error?
        let group = DispatchGroup()
        
        group.enter()
        validateSleepRecords { result in
            switch result {
            case .success(let valid):
                if !valid { isValid = false }
            case .failure(let error):
                validationError = error
            }
            group.leave()
        }
        
        group.enter()
        validateSleepInterruptions { result in
            switch result {
            case .success(let valid):
                if !valid { isValid = false }
            case .failure(let error):
                validationError = error
            }
            group.leave()
        }
        
        group.enter()
        validateEnvironmentFactors { result in
            switch result {
            case .success(let valid):
                if !valid { isValid = false }
            case .failure(let error):
                validationError = error
            }
            group.leave()
        }
        
        group.enter()
        validateActivities { result in
            switch result {
            case .success(let valid):
                if !valid { isValid = false }
            case .failure(let error):
                validationError = error
            }
            group.leave()
        }
        
        group.notify(queue: .main) {
            if let error = validationError {
                completion(.failure(error))
            } else {
                completion(.success(isValid))
            }
        }
    }
}
```

## 5. 測試計劃

為確保級聯刪除規則的正確實現，需要進行以下測試：

1. **單元測試**：測試Repository層的刪除方法，確保級聯刪除正確執行
2. **集成測試**：測試刪除操作後的數據完整性，確保沒有孤立數據
3. **UI測試**：測試UI層的刪除功能，確保用戶體驗流暢

```swift
// CascadeDeleteTests.swift

class CascadeDeleteTests: XCTestCase {
    var coreDataManager: CoreDataManager!
    var babyRepository: BabyRepository!
    var sleepRepository: SleepRepository!
    var dataIntegrityValidator: DataIntegrityValidator!
    
    override func setUp() {
        super.setUp()
        coreDataManager = CoreDataManager.shared
        babyRepository = BabyRepositoryImpl(coreDataManager: coreDataManager)
        sleepRepository = SleepRepositoryImpl(coreDataManager: coreDataManager)
        dataIntegrityValidator = DataIntegrityValidator(coreDataManager: coreDataManager)
    }
    
    // 測試刪除Baby時級聯刪除SleepRecord
    func testDeleteBabyCascadeDeletesSleepRecords() {
        // 創建測試數據
        let babyId = UUID()
        let baby = Baby(id: babyId, name: "Test Baby", birthDate: Date(), gender: .male)
        
        let expectation = self.expectation(description: "Delete baby and verify cascade delete")
        
        // 保存Baby
        babyRepository.saveBaby(baby) { result in
            switch result {
            case .success(let savedBaby):
                // 創建並保存SleepRecord
                let sleepRecord = SleepRecord(
                    id: UUID(),
                    babyId: savedBaby.id,
                    startTime: Date(),
                    endTime: Date().addingTimeInterval(3600),
                    quality: 5,
                    notes: "Test sleep"
                )
                
                self.sleepRepository.saveSleepRecord(sleepRecord) { result in
                    switch result {
                    case .success:
                        // 刪除Baby
                        self.babyRepository.deleteBaby(id: savedBaby.id) { result in
                            switch result {
                            case .success:
                                // 驗證數據完整性
                                self.dataIntegrityValidator.validateAllRelationships { result in
                                    switch result {
                                    case .success(let isValid):
                                        XCTAssertTrue(isValid, "Data integrity validation failed after cascade delete")
                                        expectation.fulfill()
                                    case .failure(let error):
                                        XCTFail("Data integrity validation error: \(error)")
                                    }
                                }
                            case .failure(let error):
                                XCTFail("Failed to delete baby: \(error)")
                            }
                        }
                    case .failure(let error):
                        XCTFail("Failed to save sleep record: \(error)")
                    }
                }
            case .failure(let error):
                XCTFail("Failed to save baby: \(error)")
            }
        }
        
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    // 測試刪除SleepRecord時級聯刪除SleepInterruption和EnvironmentFactor
    func testDeleteSleepRecordCascadeDeletesChildEntities() {
        // 創建測試數據
        let babyId = UUID()
        let sleepRecordId = UUID()
        let baby = Baby(id: babyId, name: "Test Baby", birthDate: Date(), gender: .male)
        
        let expectation = self.expectation(description: "Delete sleep record and verify cascade delete")
        
        // 保存Baby
        babyRepository.saveBaby(baby) { result in
            switch result {
            case .success:
                // 創建並保存SleepRecord
                let sleepRecord = SleepRecord(
                    id: sleepRecordId,
                    babyId: babyId,
                    startTime: Date(),
                    endTime: Date().addingTimeInterval(3600),
                    quality: 5,
                    notes: "Test sleep"
                )
                
                self.sleepRepository.saveSleepRecord(sleepRecord) { result in
                    switch result {
                    case .success:
                        // 創建並保存SleepInterruption和EnvironmentFactor
                        // ...
                        
                        // 刪除SleepRecord
                        self.sleepRepository.deleteSleepRecord(id: sleepRecordId) { result in
                            switch result {
                            case .success:
                                // 驗證數據完整性
                                self.dataIntegrityValidator.validateAllRelationships { result in
                                    switch result {
                                    case .success(let isValid):
                                        XCTAssertTrue(isValid, "Data integrity validation failed after cascade delete")
                                        expectation.fulfill()
                                    case .failure(let error):
                                        XCTFail("Data integrity validation error: \(error)")
                                    }
                                }
                            case .failure(let error):
                                XCTFail("Failed to delete sleep record: \(error)")
                            }
                        }
                    case .failure(let error):
                        XCTFail("Failed to save sleep record: \(error)")
                    }
                }
            case .failure(let error):
                XCTFail("Failed to save baby: \(error)")
            }
        }
        
        waitForExpectations(timeout: 5, handler: nil)
    }
}
```

## 6. 總結

通過以上修正，我們解決了第二階段UI未實現級聯刪除規則的問題。具體修正包括：

1. 在Core Data模型中設置正確的級聯刪除規則
2. 在Repository層確保刪除操作正確執行
3. 實現UseCase層的刪除方法
4. 在ViewModel層使用刪除UseCase
5. 在UI層實現刪除功能
6. 添加數據完整性驗證機制
7. 編寫測試確保級聯刪除正確工作

這些修正確保了當刪除父實體（如Baby或SleepRecord）時，相關的子實體（如SleepRecord、SleepInterruption、EnvironmentFactor等）會被自動刪除，避免了孤立數據的產生，保持了數據的完整性和一致性。

這種數據完整性對於第三階段的AI分析功能尤為重要，因為AI分析需要基於完整、一致的數據才能產生準確的結果和建議。
