//
//  ContentView.swift
//  Bt2
//
//  Created by MAX on 5/27/25.
//

import SwiftUI
import UIKit
import Charts

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
