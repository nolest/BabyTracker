//
//  Bt2App.swift
//  Bt2
//
//  Created by MAX on 5/27/25.
//

//import SwiftUI
//
//@main
//struct Bt2App: App {
//    var body: some Scene {
//        WindowGroup {
//            ContentView()
//        }
//    }
//}
